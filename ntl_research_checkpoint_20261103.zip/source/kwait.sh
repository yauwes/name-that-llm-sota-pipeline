#!/bin/bash
# wait for a Kaggle kernel to finish, then download its output. usage: kwait.sh owner/slug outdir
set -a; . ./.env; set +a
while :; do s=$(.venv/bin/kaggle kernels status "$1" 2>&1); case "$s" in *COMPLETE*|*ERROR*|*CANCEL*) break;; esac; sleep 60; done
echo "$s"; mkdir -p "$2"; .venv/bin/kaggle kernels output "$1" -p "$2" --force 2>&1 | tail -1 | cut -c1-200; ls -la "$2" | head -20
