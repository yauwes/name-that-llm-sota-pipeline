cd src; PY=../.venv/bin/python
$PY tfidf.py wcs_p20k word,char,style 20000 0.5
$PY tfidf.py cs_p40k char,style 40000 0.35
echo DONE
