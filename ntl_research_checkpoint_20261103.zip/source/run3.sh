cd src; PY=../.venv/bin/python
nice $PY tfidf.py csh_p100k char,style,shape 100000 0.35
echo DONE
