cd src; PY=../.venv/bin/python
$PY tfidf.py w_o word 0 0
$PY tfidf.py c_o char 0 0
$PY tfidf.py s_o style 0 0
$PY tfidf.py wcs_o word,char,style 0 0
$PY tfidf.py wcs_o_C1 word,char,style 0 0 1
$PY tfidf.py wcs_p20k word,char,style 20000 0.5
$PY tfidf.py cs_p40k char,style 40000 0.35
echo DONE
