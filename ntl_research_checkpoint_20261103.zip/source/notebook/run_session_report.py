"""Execute the aggregate report in-process, without opening Jupyter sockets.

Run from the project root after `python notebook/build.py session_20261103.py
ntl_session_20261103.ipynb`. This executes our own report, not downloaded notebooks.
"""
import time
from pathlib import Path

import nbformat
from IPython.core.interactiveshell import InteractiveShell
from IPython.utils.capture import capture_output

path = Path(__file__).with_name('ntl_session_20261103.ipynb')
nb = nbformat.read(path, as_version=4)
shell = InteractiveShell.instance()
count = 0
for cell in nb.cells:
    if cell.cell_type != 'code':
        continue
    count += 1
    started = time.perf_counter()
    with capture_output() as captured:
        result = shell.run_cell(cell.source)
    cell.outputs = []
    for name in ['stdout', 'stderr']:
        text = getattr(captured, name)
        if text:
            cell.outputs.append(nbformat.v4.new_output('stream', name=name, text=text))
    for output in captured.outputs:
        cell.outputs.append(nbformat.v4.new_output('display_data', data=output.data,
                                                   metadata=output.metadata))
    cell.execution_count = count
    cell.metadata['elapsed_seconds'] = round(time.perf_counter() - started, 4)
    error = result.error_before_exec or result.error_in_exec
    if error:
        raise RuntimeError(f'Report cell {count} failed') from error
    print(f'cell {count} OK {cell.metadata["elapsed_seconds"]}s', flush=True)
nbformat.validate(nb)
nbformat.write(nb, path)
print(f'{count} code cells executed and saved to {path}')
