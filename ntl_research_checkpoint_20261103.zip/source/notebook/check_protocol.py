"""Protocol self-check, no GPU. Random logits must score chance on test even after selection and post-processing; val may inflate, test may not.
Then the real scenario and report cells run on fake members in a folder whose name has a space."""
import json, re, shutil, sys, tempfile, time
from pathlib import Path
here = Path(__file__).parent; sys.path.insert(0, str(here))
import numpy as np, pandas as pd
import lib
t = lib.load_train(here.parent / 'data/train.csv'); S = lib.make_splits(t); y = t.y.values; txt = t.text.tolist(); pr = t.prompt_id.values; rng = np.random.RandomState(0)
def member(signal):
    z = rng.randn(5, len(y), 18); z[:, np.arange(len(y)), y] += signal
    for f in range(5): z[f, S[f] == 0] = np.nan  # same NaN contract as save_unit: any use of a train row would poison the result
    return z.astype(np.float32)

p = pd.DataFrame(dict(text=txt[:50] + ['pool only %d' % i for i in range(50)], max_cos_train=.1, max_sim_train_prompt=.1)); p2, leak = lib.leak_checks(t, S, p)
assert leak['pool_exact_host_removed'] == 50 and len(p2) == 50, leak
assert leak['prompts_train'] == 105 and leak['prompts_val'] == 22 and leak['prompts_test'] == 23, leak
assert leak['val_or_test_rows_covered'] == 1, leak

r = lib.eval_scenario([member(0.) for _ in range(10)], y, txt, pr, S, typo=False, sink=True); print('noise   val %.3f test %.3f mix %.3f' % (r['val'], r['test'], r['test_mix']))
assert r['val'] > r['test'] + .005, 'selection on val should inflate val'
assert abs(r['test'] - 1 / 18) < .025, 'pipeline leaks: noise beat chance on test'
r = lib.eval_scenario([member(1.2), member(1.2), member(0.)], y, txt, pr, S, typo=True, sink=True); print('signal  val %.3f test %.3f ci %s' % (r['val'], r['test'], np.round(r['ci'], 3)))
assert .35 < r['test'] < .95 and r['ci'][0] < r['test_pooled'] < r['ci'][1] and 2 not in r['chosen'], r['chosen']

# metrics and the live monitor
z = np.zeros((36, 18)); yy = np.repeat(np.arange(18), 2); z[np.arange(36), yy] = 5.; m = lib.metrics(yy, z); assert m['bacc'] == 1 and m['macro_f1'] == 1 and m['recall_min'] == 1 and m['family_acc'] == 1 and m['log_loss'] < .3, m
M0 = Path(tempfile.mkdtemp()) / 'mon 2'; M0.mkdir(); os_ = __import__('os'); os_.environ['NTL_LOG'] = str(M0 / 'run.log'); (M0 / 'plan.json').write_text(json.dumps(dict(a=dict(h=1., neural=False), b=dict(h=2., neural=True))))
s0 = S[0]; ho = np.where(s0 != 0)[0]; zz = member(1.)[0][ho]; (M0 / 'members/a').mkdir(parents=True); lib.save_unit(M0 / 'members/a', 0, 'a', y, s0, ho, zz, .9); mon = (M0 / 'MONITOR.md').read_text(); assert '| a | 1/5 |' in mon and '| b | 0/5 |' in mon and 'Progres 6.7%' in mon and 'sisa sekitar' in mon and 'perkiraan selesai' in mon, mon
print(mon[:700]); os_.environ.pop('NTL_LOG'); shutil.rmtree(M0.parent)

# real cells on fake members
src = (here / 'cells.py').read_text(); snap = (here.parent / 'research/lb/snapshot.json').read_text()
cell = lambda a, b: src[src.index('# %% ' + a):src.index('# %% ' + b)].replace('__LB_SNAPSHOT__', snap)
H = Path(tempfile.mkdtemp()) / 'name that llm 2'; H.mkdir(); g = {k: getattr(lib, k) for k in dir(lib) if not k.startswith('__')}
exp = cell('experiments', 'run'); exp = exp[:exp.index('if SMOKE:')] + exp[exp.index('# scenarios are fixed'):exp.index('BS = 64')]
exec(exp, g); EX = g['EXPERIMENTS']
for k, c in EX.items(): c['out'] = str(H / 'members' / k)
with open(H / 'results.jsonl', 'w') as fh:
    for k, c in EX.items():
        D = Path(c['out']); D.mkdir(parents=True); np.save(D / 'oof.npy', member({'sparse': .8, 'lora': 1.2, 'scale': 1.3, 'kd': 1.3, 'atlas': .9}[c['tag']])); (c['tag'] in ('lora', 'scale', 'kd')) and np.save(D / 'twin.npy', member(.8))
        for f in range(5): (D / f'fold{f}.done').write_text(json.dumps(dict(train=.9, val=.5, test=.45)))
        fh.write(json.dumps(dict(name=k, train=.9, val=.5, test=.45, test_sd=.01, minutes=60., resumed=False)) + '\n')
g.update(HOME=str(H), SMOKE=False, t=t, S=S, LEAK=leak, os=__import__('os'), np=np, pd=pd, json=json, glob=__import__('glob'), shutil=shutil, Path=Path, time=time, finished=lambda c: (Path(c['out']) / 'oof.npy').exists())
os = g['os']; os.environ.pop('KAGGLE_API_TOKEN', None); g['RES'] = {r['name']: r for r in map(json.loads, open(H / 'results.jsonl'))}
rn = src[src.index('def member_row'):src.index('def finished')]; exec(rn, g)
exec(cell('scenarios', 'report'), g); rep = cell('report', 'predict').replace('from IPython.display import Markdown, display\ndisplay(Markdown(\'\\n\'.join(L)))\n', ''); exec(rep, g)
text = (H / 'LAPORAN.md').read_text(); rows = pd.read_csv(H / 'scenarios.csv')
assert rows.scenario.tolist() == ['S%d' % i for i in range(1, 12)], rows.scenario.tolist()
assert (rows['rank'] >= rows.rank_best).all() and (rows['rank'] <= rows.rank_worst).all() and (rows.lb_lo < rows.exp_lb).all() and (rows.lb_hi > rows.exp_lb).all()
assert g['rank_of'](.72) == 3 and g['rank_of'](.8) == 1 and all((H / 'stacks' / f'{s}.json').exists() for s in rows.scenario), 'rank table or stack files wrong'
assert 'Recall per kelas' in text and 'Salah tebak' in text and 'Metrik evaluasi' in text and 'test_macro_f1' in rows.columns
print(rows[['scenario', 'val', 'test', 'test_mix', 'exp_lb', 'rank', 'rank_best', 'rank_worst', 'infer_h', 'stable', 'target']].round(3).to_string()); i = text.index('## Metrik evaluasi'); print(text[i:i + 1000])
# calibration: one observed score moves expectations by its gap
(H / 'lb_observed.json').write_text(json.dumps({'S9': float(rows.test_mix[8]) - .03})); exec(cell('scenarios', 'report'), g); r2 = pd.read_csv(H / 'scenarios.csv'); assert abs(r2.exp_lb[8] - rows.exp_lb[8] + .03) < 1e-6
shutil.rmtree(H.parent); print('PROTOCOL OK')
