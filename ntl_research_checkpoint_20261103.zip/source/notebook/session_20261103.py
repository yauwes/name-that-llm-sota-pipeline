# %% md
# # Name That LLM — checkpoint 3 November 2026
#
# Laporan yang dapat dijalankan ulang: EDA, audit validasi/cache, eksperimen CPU,
# ablation, serta ekspektasi versus skor submission resmi. Target riset 0,99 belum
# tercapai. Snapshot skor resmi terbaik akun adalah **0,665**. Notebook ini memakai
# hasil eksperimen yang sudah disimpan; tidak membutuhkan GPU atau membuat submission.
#
# Jalankan dari root snapshot source repo. Raw train tidak didistribusikan lewat GitHub;
# letakkan data yang diunduh secara sah di `data/` atau attach competition di Kaggle.

# %%
import json, time
from contextlib import contextmanager
from pathlib import Path
import numpy as np
import pandas as pd
from IPython.display import display, Markdown

candidates = [Path.cwd(), Path.cwd().parent]
ROOT = next((p for p in candidates if (p/'research/experiments/e15_reader_foldlocal/results.json').exists()), None)
assert ROOT is not None, 'Jalankan dari root source snapshot atau folder notebook di dalamnya.'
@contextmanager
def step(name, eta_seconds):
    begin = time.perf_counter()
    print(f'{name} | estimasi {eta_seconds}s', flush=True)
    yield
    print(f'{name} | selesai {time.perf_counter()-begin:.2f}s', flush=True)

# %% md
# ## 1. EDA: unit observasi dan generalisasi
# Split harus memisahkan prompt. Angka 70/15/15 diterapkan pada prompt dan
# dibulatkan menjadi 105/22/23 dari 150 prompt. Lima blok test mencakup 115 prompt,
# bukan 150; ini lima rotasi holdout, bukan test coverage 100% dari 5-fold biasa.

# %%
with step('EDA', 2):
    local = ROOT/'data/train.csv'
    kaggle = Path('/kaggle/input/competitions/name-that-llm/train.csv')
    path = local if local.exists() else kaggle
    if path.exists():
        train = pd.read_csv(path)
        assert {'id','text','model','prompt_id'}.issubset(train.columns)
        assert train.id.is_unique and train.notna().all().all()
        print('rows',len(train),'prompts',train.prompt_id.nunique(),'labels',train.model.nunique())
        display(train.model.value_counts().rename('support').to_frame())
        print('words:',train.text.str.split().str.len().describe().round(2).to_dict())
        markers = pd.DataFrame({k: train.text.str.contains(v, regex=False)
                                for k,v in {'em_dash':'—','curly_apostrophe':'’','semicolon':';'}.items()})
        markers['model'] = train.model
        display(markers.groupby('model').mean().round(3))
    else:
        print('Raw train belum dipasang. Ringkasan audit:2699 rows,150 prompts,18 labels;149/150 per kelas.')

# %% md
# ## 2. Audit yang mengubah interpretasi skor
#
# - OOF LoRA lama dipindahkan ke rotasi 70/15/15. Setiap baris tetap out-of-prompt,
#   tetapi proses stacking bukan nested training yang sepenuhnya terpisah.
# - Standardisasi/PCA lama dilatih global. E15/E16 melatih transformasi hanya di train.
# - Pool yang direkonstruksi tidak cocok urutan labelnya dengan cache lama (91,33%
#   posisi berbeda). Ini bukan bukti label cache salah. E15/E16 memakai fitur host
#   saja; provenance pool harus dipulihkan sebelum dipakai lagi.
# - Tidak ada hasil hidden per kelas yang tersedia. Diagnostik per kelas di sini
#   berasal dari gold lokal, sedangkan leaderboard hanya metrik agregat.

# %%
with step('muat manifest', 1):
    manifests={}
    for name in ['e15_reader_foldlocal','e16_topic_projection']:
        m=json.loads((ROOT/'research/experiments'/name/'manifest.json').read_text())
        manifests[name]=m
        print(name,'signature',m['signature'],'split',m['split_md5'])
    assert manifests['e15_reader_foldlocal']['split_md5']==manifests['e16_topic_projection']['split_md5']
    print('External pool used in E15: False; alignment audit:',manifests['e15_reader_foldlocal']['reconstructed_pool_alignment'])

# %% md
# ## 3. E15: mengganti scorer pembaca frozen
# Uji Qwen8/Qwen27 layer16/27, train-only scaler/PCA128, LR dua C dan shrinkage-LDA.
# Pilih kandidat hanya pada validation. Anchor fixed:Qwen8-layer16 LR C0,003.
# Ini perbandingan host-only; tidak setara dengan ensemble publik yang memakai pool besar.

# %%
with step('E15 hasil dan log', 1):
    e15=json.loads((ROOT/'research/experiments/e15_reader_foldlocal/results.json').read_text())
    folds=json.loads((ROOT/'research/experiments/e15_reader_foldlocal/folds.json').read_text())
    display(pd.DataFrame([dict(fold=r['fold'],model=r['chosen']['name'],train=r['chosen']['train_ba'],
                              val=r['chosen']['validation_ba'],test=r['selected_test_ba'],
                              anchor=r['anchor_test_ba'],seconds=r['elapsed_s']) for r in folds]).round(4))
    print('mean test',e15['selected_test_ba_mean'],'paired delta CI95',e15['paired_delta_ci95'])
    print('Keputusan:belum terkonfirmasi; tidak memenuhi submission gate.')

# %% md
# ## 4. E16 dan E17: fusion versus proyeksi topik
# E16 mempelajari arah nuisance dari centroid prompt training dalam PCA space,
# kemudian memilih rank/gamma/C dan kekuatan fusion dengan SVC di validation.
# E17 memisahkan manfaat reader fusion dari manfaat proyeksi topik itu sendiri.
# Cached SVC lolos cek shape, finite validation/test dan NaN training mask;
# provenance lengkap cache lama tetap lebih lemah daripada training baru dari manifest.

# %%
with step('E16/E17 ablation', 1):
    e16=json.loads((ROOT/'research/experiments/e16_topic_projection/results.json').read_text())
    e17=json.loads((ROOT/'research/experiments/e17_topic_ablation/results.json').read_text())
    display(pd.DataFrame({'test_mean':e17['test_mean'],'test_pooled':e17['test_pooled']}).round(4))
    display(pd.DataFrame([dict(comparison=k,ci95_low=v[0],ci95_high=v[1])
                          for k,v in e17['paired_ci95'].items()]).round(4))
    print('E16 positive rotations',e16['positive_rotations'],'/5')
    print('CPU seconds:E15',round(e15['elapsed_s'],2),'E16',round(e16['elapsed_s'],2),'E17',round(e17['elapsed_s'],2))
    print('Fusion membantu SVC; efek tambahan proyeksi belum terkonfirmasi jika CI melintasi0.')
    print('Skor cabang ini tidak mengalahkan champion resmi0.665; tidak membuat submission.')

# %% md
# ## 5. Ekspektasi versus leaderboard resmi
# Judul seperti “0.75+” bukan pengukuran. Jangan menghitung gap CV-LB jika CV yang
# sebanding tidak tersedia. Skor private masih tidak diketahui. Data di bawah snapshot,
# bukan polling live; cek ulang API sebelum tindakan baru.

# %%
with step('riwayat resmi', 1):
    history=json.loads((ROOT/'research/live/20261103/submissions.txt').read_text())
    rows=[]
    for r in history:
        rows.append(dict(submission=r['ref'],date=r['date'],status=r['status'].split('.')[-1],
                         public_BA=float(r['publicScore']) if r.get('publicScore') else None,
                         description=r['description']))
    history_table=pd.DataFrame(rows)
    display(history_table)
    print('Official best',history_table.public_BA.max())
    for ref,context in [(57889656,'target judul0.75+, tidak ada CV0.75 terverifikasi'),
                        (57919689,'penambahan komponen:LB0.661'),
                        (57919873,'perubahan multi-komponen:LB0.663')]:
        hit=history_table[history_table.submission==ref]
        if len(hit): print(ref,context,'actual',hit.public_BA.iloc[0])

# %% md
# ## 6. Komputasi, checkpoint, dan keputusan berikut
#
# GPU akun yang sama habis; TPU masih tersedia pada snapshot. Sesi ini melakukan
# eksperimen CPU singkat tanpa membuat runtime GPU/TPU interaktif baru. E14 telah
# berjalan sebelum sesi ini dan belum memiliki output saat snapshot pertama.
# Jangan menggandakan job, menghentikan scoring resmi, atau beralih akun untuk melewati quota.
#
# Berikutnya:replikasi fusion pada cache yang memiliki IDs/revision lengkap, uji pada
# ensemble kuat dengan training nested yang benar, dan peroleh gold bertopik baru
# untuk konfirmasi. Data exact-source bergaya host bernilai lebih daripada menambah
# postprocessing kluster yang sudah gagal. Target0.99 masih belum didukung bukti.

# %%
with step('quota snapshot', 1):
    quota=json.loads((ROOT/'research/live/20261103/quota.txt').read_text())
    display(pd.DataFrame(quota))
    print('Handoff:readme.md; logs:research/experiments/e15_reader_foldlocal.log dan e16/e17.')
    print('Jalankan ulang training eksperimen hanya jika dibutuhkan; hasil selesai sudah disimpan.')
