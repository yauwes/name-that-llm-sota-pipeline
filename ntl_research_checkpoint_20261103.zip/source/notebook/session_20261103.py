# %% md
# # Name That LLM — checkpoint 3–4 November 2026
#
# Laporan yang dapat dijalankan ulang: EDA, audit validasi/cache, eksperimen CPU,
# ablation, serta ekspektasi versus skor submission resmi. Target riset 0,99 belum
# tercapai. Snapshot skor resmi terbaik akun adalah **0,665**. Notebook ini memakai
# hasil eksperimen yang sudah disimpan; tidak membutuhkan GPU atau membuat submission.
#
# Jalankan dari root snapshot source repo. Raw train tidak didistribusikan lewat GitHub;
# letakkan data yang diunduh secara sah di `data/` atau attach competition di Kaggle.

# %%
import json, time
from contextlib import contextmanager
from pathlib import Path
import numpy as np
import pandas as pd
from IPython.display import display, Markdown

candidates = [Path.cwd(), Path.cwd().parent]
ROOT = next((p for p in candidates if (p/'research/experiments/e15_reader_foldlocal/results.json').exists()), None)
assert ROOT is not None, 'Jalankan dari root source snapshot atau folder notebook di dalamnya.'
@contextmanager
def step(name, eta_seconds):
    begin = time.perf_counter()
    print(f'{name} | estimasi {eta_seconds}s', flush=True)
    yield
    print(f'{name} | selesai {time.perf_counter()-begin:.2f}s', flush=True)

# %% md
# ## 1. EDA: unit observasi dan generalisasi
# Split harus memisahkan prompt. Angka 70/15/15 diterapkan pada prompt dan
# dibulatkan menjadi 105/22/23 dari 150 prompt. Lima blok test mencakup 115 prompt,
# bukan 150; ini lima rotasi holdout, bukan test coverage 100% dari 5-fold biasa.

# %%
with step('EDA', 2):
    local = ROOT/'data/train.csv'
    kaggle = Path('/kaggle/input/competitions/name-that-llm/train.csv')
    path = local if local.exists() else kaggle
    if path.exists():
        train = pd.read_csv(path)
        assert {'id','text','model','prompt_id'}.issubset(train.columns)
        assert train.id.is_unique and train.notna().all().all()
        print('rows',len(train),'prompts',train.prompt_id.nunique(),'labels',train.model.nunique())
        display(train.model.value_counts().rename('support').to_frame())
        print('words:',train.text.str.split().str.len().describe().round(2).to_dict())
        markers = pd.DataFrame({k: train.text.str.contains(v, regex=False)
                                for k,v in {'em_dash':'—','curly_apostrophe':'’','semicolon':';'}.items()})
        markers['model'] = train.model
        display(markers.groupby('model').mean().round(3))
    else:
        print('Raw train belum dipasang. Ringkasan audit:2699 rows,150 prompts,18 labels;149/150 per kelas.')

# %% md
# ## 2. Audit yang mengubah interpretasi skor
#
# - OOF LoRA lama dipindahkan ke rotasi 70/15/15. Setiap baris tetap out-of-prompt,
#   tetapi proses stacking bukan nested training yang sepenuhnya terpisah.
# - Standardisasi/PCA lama dilatih global. E15/E16 melatih transformasi hanya di train.
# - Pool yang direkonstruksi tidak cocok urutan labelnya dengan cache lama (91,33%
#   posisi berbeda). Ini bukan bukti label cache salah. E15/E16 memakai fitur host
#   saja; provenance pool harus dipulihkan sebelum dipakai lagi.
# - Tidak ada hasil hidden per kelas yang tersedia. Diagnostik per kelas di sini
#   berasal dari gold lokal, sedangkan leaderboard hanya metrik agregat.

# %%
with step('muat manifest', 1):
    manifests={}
    for name in ['e15_reader_foldlocal','e16_topic_projection']:
        m=json.loads((ROOT/'research/experiments'/name/'manifest.json').read_text())
        manifests[name]=m
        print(name,'signature',m['signature'],'split',m['split_md5'])
    assert manifests['e15_reader_foldlocal']['split_md5']==manifests['e16_topic_projection']['split_md5']
    print('External pool used in E15: False; alignment audit:',manifests['e15_reader_foldlocal']['reconstructed_pool_alignment'])

# %% md
# ## 3. E15: mengganti scorer pembaca frozen
# Uji Qwen8/Qwen27 layer16/27, train-only scaler/PCA128, LR dua C dan shrinkage-LDA.
# Pilih kandidat hanya pada validation. Anchor fixed:Qwen8-layer16 LR C0,003.
# Ini perbandingan host-only; tidak setara dengan ensemble publik yang memakai pool besar.

# %%
with step('E15 hasil dan log', 1):
    e15=json.loads((ROOT/'research/experiments/e15_reader_foldlocal/results.json').read_text())
    folds=json.loads((ROOT/'research/experiments/e15_reader_foldlocal/folds.json').read_text())
    display(pd.DataFrame([dict(fold=r['fold'],model=r['chosen']['name'],train=r['chosen']['train_ba'],
                              val=r['chosen']['validation_ba'],test=r['selected_test_ba'],
                              anchor=r['anchor_test_ba'],seconds=r['elapsed_s']) for r in folds]).round(4))
    print('mean test',e15['selected_test_ba_mean'],'paired delta CI95',e15['paired_delta_ci95'])
    print('Keputusan:belum terkonfirmasi; tidak memenuhi submission gate.')

# %% md
# ## 4. E16 dan E17: fusion versus proyeksi topik
# E16 mempelajari arah nuisance dari centroid prompt training dalam PCA space,
# kemudian memilih rank/gamma/C dan kekuatan fusion dengan SVC di validation.
# E17 memisahkan manfaat reader fusion dari manfaat proyeksi topik itu sendiri.
# Cached SVC lolos cek shape, finite validation/test dan NaN training mask;
# provenance lengkap cache lama tetap lebih lemah daripada training baru dari manifest.

# %%
with step('E16/E17 ablation', 1):
    e16=json.loads((ROOT/'research/experiments/e16_topic_projection/results.json').read_text())
    e17=json.loads((ROOT/'research/experiments/e17_topic_ablation/results.json').read_text())
    display(pd.DataFrame({'test_mean':e17['test_mean'],'test_pooled':e17['test_pooled']}).round(4))
    display(pd.DataFrame([dict(comparison=k,ci95_low=v[0],ci95_high=v[1])
                          for k,v in e17['paired_ci95'].items()]).round(4))
    print('E16 positive rotations',e16['positive_rotations'],'/5')
    print('CPU seconds:E15',round(e15['elapsed_s'],2),'E16',round(e16['elapsed_s'],2),'E17',round(e17['elapsed_s'],2))
    print('Fusion membantu SVC; efek tambahan proyeksi belum terkonfirmasi jika CI melintasi0.')
    print('Skor cabang ini tidak mengalahkan champion resmi0.665; tidak membuat submission.')

# %% md
# ## 5. E14 selesai dan E18 analisis kesalahan
# E14 dibandingkan hanya pada fold0–2 terhadap kontrol yang identik, tanpa
# membandingkan rerata3fold dengan5fold. CI bersyarat pada model historis dan tidak
# mencakup bias seluruh proses research. Hasil E16 adalah cabang SVC+reader.

# %%
with step('audit E14 dan error slices', 1):
    audit=json.loads((ROOT/'research/experiments/e18_closing_audit/results.json').read_text())
    display(pd.DataFrame([dict(model=k,control=v['control_mean'],e14=v['e14_mean'],
                              ci_low=v['paired_prompt_ci95'][0],ci_high=v['paired_prompt_ci95'][1],
                              positive_folds=v['positive_folds']) for k,v in audit['e14'].items()]).round(4))
    print('E14 COMPLETE. OOF/log diunduh; source tidak menyimpan bobot tahap2. Tidak dipromosikan.')
    display(pd.DataFrame(audit['e16']['per_class']).round(4))
    display(pd.DataFrame(audit['e16']['length_slices']).round(4))
    display(pd.DataFrame(audit['e16']['top_confusions'][:6]))
    print('Fixes',audit['e16']['fixes'],'breaks',audit['e16']['breaks'])
    print('Family accuracy',audit['e16']['family_accuracy'],
          'fraction errors within family',audit['e16']['fraction_errors_within_family'])
    print('Slice adalah diagnostik pasca-test; bukan izin menyesuaikan kandidat pada test.')

# %% md
# ## 6. Ekspektasi versus leaderboard resmi
# Judul seperti “0.75+” bukan pengukuran. Jangan menghitung gap CV-LB jika CV yang
# sebanding tidak tersedia. Skor private masih tidak diketahui. Data di bawah snapshot,
# bukan polling live; cek ulang API sebelum tindakan baru.

# %%
with step('riwayat resmi', 1):
    history=json.loads((ROOT/'research/live/20261103/submissions.txt').read_text())
    rows=[]
    for r in history:
        rows.append(dict(submission=r['ref'],date=r['date'],status=r['status'].split('.')[-1],
                         public_BA=float(r['publicScore']) if r.get('publicScore') else None,
                         description=r['description']))
    history_table=pd.DataFrame(rows)
    display(history_table)
    print('Official best',history_table.public_BA.max())
    for ref,context in [(57889656,'target judul0.75+, tidak ada CV0.75 terverifikasi'),
                        (57919689,'penambahan komponen:LB0.661'),
                        (57919873,'perubahan multi-komponen:LB0.663')]:
        hit=history_table[history_table.submission==ref]
        if len(hit): print(ref,context,'actual',hit.public_BA.iloc[0])

# %% md
# ## 7. Komputasi, checkpoint, dan keputusan berikut
#
# GPU akun yang sama habis; TPU masih tersedia pada snapshot. Sesi ini melakukan
# eksperimen CPU singkat tanpa membuat runtime GPU/TPU interaktif baru. E14 telah
# berjalan sebelum sesi ini; kini COMPLETE dan hasil/log sudah diunduh dan diaudit.
# Jangan menggandakan job, menghentikan scoring resmi, atau beralih akun untuk melewati quota.
#
# Berikutnya:replikasi fusion pada cache yang memiliki IDs/revision lengkap, uji pada
# ensemble kuat dengan training nested yang benar, dan peroleh gold bertopik baru
# untuk konfirmasi. Data exact-source bergaya host bernilai lebih daripada menambah
# postprocessing kluster yang sudah gagal. Target0.99 masih belum didukung bukti.

# %%
with step('quota snapshot', 1):
    quota=json.loads((ROOT/'research/live/20261103/quota.txt').read_text())
    display(pd.DataFrame(quota))
    print('Handoff:readme.md; logs:research/experiments/e15_reader_foldlocal.log dan e16/e17.')
    print('Jalankan ulang training eksperimen hanya jika dibutuhkan; hasil selesai sudah disimpan.')

# %% md
# ## 8. E19: fusion pada pembanding external-stage1 + SVC
# Scope adaptasi tidak mencampur stage2 OOF dengan rotasi. Reader/head memakai
# train gold saja, konfigurasi dipilih menurut val logloss, bobot fusion menurut
# val BA. Provenance upstream cache historis tetap tidak lengkap. Ini bukan CV
# champion leaderboard. Run max_iter400 diarsipkan setelah warning; run final
# max_iter2000 mencatat jumlah iterasi dan memverifikasi semua kandidat konvergen.

# %%
with step('E19', 1):
    directory=ROOT/'research/experiments/e19_reader_strong_fusion'
    e19=json.loads((directory/'results.json').read_text())
    records=[json.loads((directory/f'fold{f}.json').read_text()) for f in range(5)]
    display(pd.DataFrame([dict(fold=r['fold'],reader=r['chosen']['name'],C=r['chosen']['C'],
        reader_train_BA=r['chosen']['train_ba'],reader_val_BA=r['chosen']['val_ba'],
        ensemble_val_BA=r['selected_val_ba'],baseline_test_BA=r['baseline_test_ba'],
        fusion_test_BA=r['selected_test_ba'],alpha=r['alpha']) for r in records]).round(4))
    print('Mean test',e19['mean_test'],'paired CI95',e19['paired_prompt_ci95'])
    print('Maximum optimization iterations',max(c['iterations'] for r in records for c in r['candidates']))
    print('Elapsed CPU',e19['elapsed_s'],'seconds; no submission.')

# %% md
# ## 9. E20: spectral reader lokal dengan provenance lengkap
# Raw response saja, Qwen3-0.6B frozen, DC/first-AC length-normalized, layer8/16/28.
# Formula diperiksa terhadap DCT-II scipy; padding tidak masuk trajectory.
# Ini adaptasi K=1 tanpa prompt asli; bukan klaim mereplikasi multi-query READER.
# Semua transformasi/probe dipelajari dari train tiap rotasi.

# %%
with step('E20 spectral', 1):
    directory=ROOT/'research/experiments/e20_spectral_reader'
    e20=json.loads((directory/'results.json').read_text())
    extraction=json.loads((directory/'extraction_status.json').read_text())
    assert extraction['complete']
    feature_manifest=json.loads((directory/'feature_manifest.json').read_text())
    print('Model revision',feature_manifest['model_revision'],'device',feature_manifest['device'])
    print('Extraction',extraction['rows_done'],'rows;',round(extraction['elapsed_s'],2),'seconds')
    print('Truncated rows',feature_manifest['truncated_rows'],'/2699; token cap512')
    records=[json.loads((directory/f'fold{f}.json').read_text()) for f in range(5)]
    display(pd.DataFrame([dict(fold=r['fold'],layer=r['chosen']['DCAC']['layer'],
        C=r['chosen']['DCAC']['C'],reader_train_BA=r['chosen']['DCAC']['train_ba'],
        reader_val_BA=r['chosen']['DCAC']['val_ba'],fusion_val_BA=r['selected_val_ba'],
        **r['test']) for r in records]).round(4))
    print('Mean test',e20['mean_test'],'paired intervals',e20['paired_ci95'])
    print('Head evaluation CPU seconds',e20['elapsed_s'])

# %% md
# ## 10. E21: outer5fold dengan cakupan seluruh150prompt
# Outer train120prompt, test30prompt. C reader dipilih pada96train/24val di dalam
# outer train lalu refit120; alpha0.1 ditetapkan sebelum test. LoRA stage2 memakai
# fold yang sesuai, dan skor inner-val dari outer-LoRA tidak dipakai untuk tuning.
# Ini protokol terpisah dari lima rotasi70/15/15. Semua prompt tetap data historis
# yang sudah pernah ditelaah; tidak berubah menjadi gold eksternal baru.

# %%
with step('E21 scope confirmation', 1):
    directory=ROOT/'research/experiments/e21_nested_reader_confirm'
    e21=json.loads((directory/'results.json').read_text())
    assert e21['test_coverage']==1.
    records=[json.loads((directory/f'fold{f}.json').read_text()) for f in range(5)]
    display(pd.DataFrame([dict(fold=r['fold'],C=r['chosen']['C'],
        inner_train_BA=r['chosen']['train_ba'],inner_val_BA=r['chosen']['val_ba'],
        reader_refit_train_BA=r['train_refit_ba'],**r['test']) for r in records]).round(4))
    print('Mean test',e21['mean_test'],'paired CI95',e21['paired_ci95'])
    print('Coverage',e21['test_prompts'],'prompts',e21['test_rows'],'rows; CPU',e21['elapsed_s'],'seconds')
    print(e21['caveat'])

# %% md
# ## 11. E22: kualifikasi data publik baru dengan jumlah kelas terkontrol
# Tujuh alias sumber sama persis, namun identitas bobot API tidak immutable.
# Max128token menciptakan mismatch dengan paragraf mandiri kompetisi. Sebanyak
# 50prompt eksternal ditahan dari seluruh fitting. Proxy mengganti pool pada
# jumlah dan bobot kelas yang sama; cap500/kelas, bukan full-pool champion.
# Recall eksternal pada tujuh label yang hadir tidak setara dengan BA18kelas.

# %%
with step('E22 external data', 1):
    directory=ROOT/'research/experiments/e22_reader_data'
    audit=json.loads((directory/'audit.json').read_text())
    e22=json.loads((directory/'results.json').read_text())
    display(pd.DataFrame(audit['per_class']).round(3))
    print('Eligible training',audit['eligible_training_rows'],'heldout external',audit['eligible_external_test_rows'])
    print('Exact pool duplicates',audit['exact_pool'],'near-gold',audit['near_gold_char_ge08'],
          'terminal punctuation fraction',audit['terminal_punctuation_fraction'])
    records=[json.loads((directory/f'proxy_fold{f}.json').read_text()) for f in range(5)]
    display(pd.DataFrame([dict(fold=r['fold'],base_val=r['validation_trials'][0]['validation_ba'],
        replacement_val=r['validation_trials'][1]['validation_ba'],chosen=r['chosen'],
        base_test=r['baseline_test_ba'],selected_test=r['selected_test_ba'],
        external_7label_recall=r['external_present_label_macro_recall']) for r in records]).round(4))
    print('Mean test',e22['mean_test'],'paired CI95',e22['paired_ci95'],'CPU seconds',e22['elapsed_s'])
    print(e22['caveat'])
    print('No new competition submission. Official champion remains0.665 at the saved snapshot.')

# %% md
# ## 12. Submission V3 selesai0.055: audit jalur gagal
# Source original memiliki catch-all pada inferensi utama, lalu dapat menulis
# seluruh label sebagai gpt-5.5. Fixture400ID sintetis mereproduksi defect itu
# tanpa menjalankan backbone. Skor1/18 konsisten dengan LB mendekati chance,
# tetapi log hidden tidak tersedia sehingga kejadian dan exception asli belum
# terbukti. Salinan guarded hanya artefak correctness, belum lolos dryrun GPU.

# %%
with step('V3 fallback regression', 1):
    failure=json.loads((ROOT/'research/checkpoints/failed_apex_v3/failure_regression.json').read_text())
    display(pd.DataFrame({'original':failure['original_failure_simulation'],
                          'guarded':failure['guarded_failure_simulation']}))
    print('Official V3',failure['official_public_score'],'champion',failure['champion_public_score'])
    print(failure['conclusion'])
    print('Guarded notebook',failure['guarded_notebook'],'eligible',failure['submission_eligible'])
    print('Required next:',failure['required_next'])

# %% md
# ## 13. E23: depth dan readout checkpoint harus sesuai
# Probe CPU pada Docker V3 yang sama menemukan35target modul hilang per adapter
# Q25-v5 dengan keep27. Referensi inferensi penulis menyatakan keep32 dan readout
# [3,5,8,11,16,21,27,32]. Dimensi delapan readout tetap sama meski indeksnya salah.
# Versi2 memeriksa spesifikasi terkoreksi, tanpa memuat bobot backbone besar.
# Ini bukan uji CUDA atau bukti kualitas; salinan perbaikan tetap UNVALIDATED.

# %%
with step('E23 kontrak checkpoint', 1):
    probe=json.loads((ROOT/'kernels/v3preflight_cpu/out_v2/preflight_report.json').read_text())
    repair=json.loads((ROOT/'research/experiments/e23_checkpoint_preflight/repair_report.json').read_text())
    assert probe['checks']['q25_corrected_contract_passed']
    display(pd.DataFrame([dict(adapter=Path(old['folder']).name,
        submitted_keep=old['source_keep'],missing_submitted=len(old['unresolved_loader_modules']),
        corrected_keep=new['source_keep'],missing_corrected=len(new['unresolved_loader_modules']),
        factor_shape_errors=len(new['shape_mismatches']),head_shape_errors=len(new['head']['format_mismatches']))
        for old,new in zip(probe['checks']['q25'],probe['checks']['q25_corrected_contract'])]))
    print('Author reference',repair['reference']['reference_url'])
    print('Readout',repair['reference']['layers'],'CPU seconds',probe['elapsed_s'])
    print('Fixed notebook',repair['repaired_notebook'],'eligible',repair['submission_eligible'])
    print('Fatal failure simulation',repair['fatal_failure_simulation'])
    print('GPU dryrun',probe['real_gpu_dryrun'],'quality measured: False')

# %% md
# ## 14. E24: prompt-paired column ranking pada frozen head
# Bandingkan row-CE biasa dengan row-CE + column-CE di dalam prompt training.
# Tidak ada assignment constraint pada test. Lambda dipilih menurut val logloss;
# alpha menurut val BA. Gradient/missing-source/offset self-check dan kontrol
# label acak di dalam prompt diperiksa. Hasil negatif tetap disimpan.

# %%
with step('E24 paired head', 1):
    directory=ROOT/'research/experiments/e24_paired_rank'
    e24=json.loads((directory/'results.json').read_text())
    display(pd.DataFrame({'mean_test':e24['mean_test'],'pooled_test':e24['pooled_test']}).round(5))
    display(pd.DataFrame([dict(comparison=k,ci_low=v[0],ci_high=v[1])
                          for k,v in e24['paired_ci95'].items()]).round(5))
    print('Nonzero lambda selected',e24['selected_nonzero_lambda_folds'],'/5; seconds',e24['elapsed_s'])
    print('Ordinary head lebih baik; tidak dipromosikan atau disubmit.')

# %% md
# ## 15. E25: StyleDistance sebagai feature gaya murah
# Referensi primer: https://aclanthology.org/2025.naacl-long.436/ . Model gaya
# bukan detector sumber18LLM. Backbone frozen, official masked-mean pooling,
# revision immutable, tanpa remote custom code. Fitur disimpan perbatch dengan
# ID dan hash teks. Pilih style/hybrid head menurut val logloss, alpha menurut BA.
# Seluruh scaler dilatih hanya pada train. Tidak ada passage terpotong.

# %%
with step('E25 style encoder', 1):
    directory=ROOT/'research/experiments/e25_styledistance'
    e25=json.loads((directory/'results.json').read_text())
    feature=json.loads((directory/'feature_manifest.json').read_text())
    extraction=json.loads((directory/'extraction_status.json').read_text())
    assert extraction['complete'] and extraction['rows_done']==2699
    print('Pinned model',feature['model'],feature['revision'])
    print('Metal extraction seconds',extraction['elapsed_s'],'truncated',feature['truncated_rows'])
    records=[json.loads((directory/f'fold{f}.json').read_text()) for f in range(5)]
    display(pd.DataFrame([dict(fold=r['fold'],head=r['chosen']['name'],C=r['chosen']['C'],
        train=r['chosen']['train_ba'],val=r['chosen']['val_ba'],alpha=r['alpha'],**r['test']) for r in records]).round(5))
    print('Test means',e25['mean_test'],'paired CI95',e25['selected_minus_baseline_ci95'])
    print('CPU seconds',e25['elapsed_s'],'not CV of the LB champion; eligible',e25['submission_eligible'])
    print('Base config and pooling config have separate paths in artifact_hash_addendum.json; original manifest retained.')

# %% md
# ## 16. E26: konfirmasi style pada pembanding LoRA yang lebih kuat
# Pertahankan comparator/split/alpha0,1 dari E21, ganti fitur menjadi StyleDistance.
# Inner96/24 memilih C; refit outer120, test30prompt, semua150prompt tercakup.
# E26 memakai style head saja, bukan hybrid E25. Tidak menguji semua kemungkinan
# fusion, dan tidak membuktikan bahwa fitur gaya tidak bermanfaat secara umum.

# %%
with step('E26 scope confirmation', 1):
    directory=ROOT/'research/experiments/e26_nested_style_confirm'
    e26=json.loads((directory/'results.json').read_text())
    assert e26['test_coverage']==1. and e26['test_rows']==2699
    records=[json.loads((directory/f'fold{f}.json').read_text()) for f in range(5)]
    display(pd.DataFrame([dict(fold=r['fold'],C=r['chosen']['C'],inner_train=r['chosen']['train_ba'],
        inner_val=r['chosen']['val_ba'],refit_train=r['train_refit_ba'],**r['test']) for r in records]).round(5))
    print('Means',e26['mean_test'],'paired CI95',e26['paired_ci95'])
    print('Positive folds',e26['positive_folds'],'/5; CPU seconds',e26['elapsed_s'])
    print('CI melintasi0; tidak dipromosikan. No new competition submission; official best0.665.')

# %% md
# ## 17. E27: isolasi style dari stacking logits
# Outer120/30, inner96/24, alpha0,1 tetap. Kontrol804dimensi mengacak style
# hanya dalam prompt training; validation/test tetap urutan asli. C dipilih di
# inner-validation. Semua150prompt mempunyai prediksi test; bukan gold baru.

# %%
with step('E27 nested hybrid ablation', 1):
    directory=ROOT/'research/experiments/e27_nested_hybrid_style'
    e27=json.loads((directory/'results.json').read_text())
    display(pd.DataFrame({'mean_test':e27['mean_test'],'pooled_test':e27['pooled_test']}).round(5))
    display(pd.DataFrame([dict(comparison=k,low=v[0],high=v[1]) for k,v in e27['paired_ci95'].items()]).round(5))
    print('Hybrid > logits folds',e27['positive_hybrid_vs_logits_folds'],'/5; CPU seconds',e27['elapsed_s'])
    print('Tidak mendukung promosi. Same-dimensional permuted control is not selected from outer test.')

# %% md
# ## 18. E28: predictability trajectories dan pilot biaya
# Qwen pilot tidak menyelesaikan semua baris; source/log/bitmap disimpan.
# DistilGPT2 adalah varian terpisah dengan biaya lebih kecil, bukan pengganti
# yang dianggap sama kualitasnya. Simpan observed/top log-prob, entropy dan
# log-rank untuk semua valid next-token; padding dan token pertama dikeluarkan.
# Summary posisi relatif dan hybrid logits dipilih hanya dengan validation.

# %%
with step('E28 likelihood probe', 1):
    directory=ROOT/'research/experiments/e28_predictability_distilgpt2'
    e28=json.loads((directory/'results.json').read_text())
    m=json.loads((directory/'feature_manifest.json').read_text())
    extraction=json.loads((directory/'extraction_status.json').read_text())
    assert extraction['complete'] and extraction['rows_done']==2699
    print('Pinned model',m['model'],m['revision'],'truncated',m['truncated_rows'])
    print('Metal extraction seconds',extraction['elapsed_s'],'CPU evaluation seconds',e28['elapsed_s'])
    records=[json.loads((directory/f'fold{f}.json').read_text()) for f in range(5)]
    display(pd.DataFrame([dict(fold=r['fold'],head=r['chosen']['name'],C=r['chosen']['C'],
        train=r['chosen']['train_ba'],val=r['chosen']['val_ba'],alpha=r['alpha'],**r['test']) for r in records]).round(5))
    print('Mean test',e28['mean_test'],'paired CI95',e28['paired_ci95'])
    print('No promotion. One proxy and summaries do not reproduce the multi-LM BiLSTM paper.')

# %% md
# ## 19. E29: berapa optimisme dari oracle context?
# GaussianWPCA64 dilatih pada120prompt, lalu30prompt test disubsample1/2/4/18
# jawaban. Oracle prompt-ID/full18context hanya diagnostik non-serving. Threshold
# clustering dipelajari di train. Bandingkan konteks pada baris target yang sama.
# CI sparse bersyarat pada bootstrap yang memuat semua18kelas, bukan unconditional.

# %%
with step('E29 partial-group stress test', 1):
    e29=json.loads((ROOT/'research/experiments/e29_partial_group_audit/results.json').read_text())
    selected=['k1_seed0','k2_seed0','k4_seed0','k18_seed0']
    display(pd.DataFrame([dict(case=k,rows=e29['cases'][k]['rows'],
        grouped=e29['cases'][k]['grouped_rows'],pair_recall=e29['cases'][k]['pair_recall'],
        **e29['cases'][k]['balanced_accuracy18']) for k in selected]).round(5))
    print('k2_seed0 conditional intervals',e29['cases']['k2_seed0']['intervals'])
    print('CPU seconds',e29['elapsed_s'],'Small Gaussian proxy, not CV of the LB champion.')

# %% md
# ## 20. E30: ganti grouping representation saja
# MiniLM official mean+L2, cap256. Gaussian/checkpoint, baris target, seed dan
# temperatur sama persis dengan E29. Threshold similarity tetap train-only.
# Clustering batch30prompt belum merepresentasikan jumlah kandidat4000hidden.

# %%
with step('E30 semantic grouping', 1):
    directory=ROOT/'research/experiments/e30_semantic_groups'
    e30=json.loads((directory/'results.json').read_text())
    m=json.loads((directory/'feature_manifest.json').read_text())
    extraction=json.loads((directory/'extraction_status.json').read_text())
    print('Pinned semantic revision',m['revision'],'truncated',m['truncated_rows'],'/2699')
    print('Extraction seconds',extraction['elapsed_s'],'CPU audit seconds',e30['elapsed_s'])
    display(pd.DataFrame([dict(case=k,rows=e30['cases'][k]['rows'],
        pair_precision=e30['cases'][k]['pair_precision'],pair_recall=e30['cases'][k]['pair_recall'],
        **e30['cases'][k]['balanced_accuracy18']) for k in ['k1_seed0','k2_seed0','k4_seed0','k18_seed0']]).round(5))
    print('k2 conditional interval',e30['cases']['k2_seed0']['semantic_minus_qwen_ci'])
    print('Improvement on this weak proxy is not sufficient to promote a submission.')

# %% md
# ## 21. E31/E32: transfer ke LoRA dan eligibility saat serving
# E31 menambah Gaussian ke semua baris dengan alpha0,1 yang sudah ditetapkan.
# E32 memulihkan syarat produksi terdokumentasi: bukti Gaussian hanya untuk
# inferred group ukuran2–18. Semua parameter dan sampel tetap; hasil historis
# E31 sudah dibaca, sehingga E32 bukan konfirmasi gold baru yang buta.

# %%
with step('E31/E32 stronger-comparator confirmation', 1):
    e31=json.loads((ROOT/'research/experiments/e31_group_fusion_confirm/results.json').read_text())
    e32=json.loads((ROOT/'research/experiments/e32_group_eligibility/results.json').read_text())
    keys=['k1_seed0','k2_seed0','k2_seed1','k2_seed2','k4_seed0','k18_seed0']
    display(pd.DataFrame([dict(case=k,baseline=e32['cases'][k]['balanced_accuracy18']['baseline'],
        semantic_all_rows=e31['cases'][k]['balanced_accuracy18']['semantic_group_fusion'],
        semantic_grouped_only=e32['cases'][k]['balanced_accuracy18']['semantic_grouped_only'],
        eligible_rows=e32['cases'][k]['eligible_rows']['semantic_grouped_only'],
        ci_low=e32['cases'][k]['intervals']['semantic_grouped_only minus baseline']['ci95'][0],
        ci_high=e32['cases'][k]['intervals']['semantic_grouped_only minus baseline']['ci95'][1]) for k in keys]).round(5))
    print('CPU seconds:E31',e31['elapsed_s'],'E32',e32['elapsed_s'])
    print('Dense18context gain does not establish sparse2context gain. No new submission; official best0.665.')

# %% md
# ## 22. E33: pengelompokan3530–4040passage dengan konteks eksternal
# Threshold, alpha0,1 dan eligibility2–18 dibekukan dari E30/E32.3500respons
# Agent500 hanya konteks tanpa source-label untuk inference. Ukur gold-target
# accuracy; Gold–Gold dan eksternal–eksternal punya prompt identity. Cross-origin
# edge mempunyai truth **tidak diketahui**, bukan otomatis falsepositive.
# Pool eksternal yang sama diulang lintas fold; jumlah edge bukan sampel independen.
# Distribusi tujuh model/cap128token bukan replika hidden. Prefix Qwen16layer
# harus lolos parity terhadap hidden[16] model penuh sebelum ekstraksi.

# %%
with step('E33 large-context stress', 1):
    directory=ROOT/'research/experiments/e33_large_context'
    e33=json.loads((directory/'results.json').read_text());assert e33['complete']
    display(pd.DataFrame([dict(case=k,rows=v['rows'],**v['balanced_accuracy18'],
        mixed_origin_gold=v['diagnostics_totals']['gold_rows_in_mixed_origin_groups'],
        known_gold_pair_precision=v['pair_diagnostics']['gold_gold']['pair_precision'],
        known_gold_pair_recall=v['pair_diagnostics']['gold_gold']['pair_recall'],
        ci_low=v['intervals']['context_fusion minus gold_only']['ci95'][0],
        ci_high=v['intervals']['context_fusion minus gold_only']['ci95'][1]) for k,v in e33['cases'].items()]).round(5))
    print('Prefix parity',json.loads((directory/'prefix_parity.json').read_text()))
    for kind in ['semantic','dc16']:
        status=json.loads((directory/f'{kind}_extraction_status.json').read_text())
        print(kind,'rows',status['rows_done'],'elapsed seconds',round(status['elapsed_s'],2),'complete',status['complete'])
    print('Audit seconds',round(e33['elapsed_s'],2),'No champion or hidden-distribution claim; no new submission.')

# %% md
# ## 23. E34: pairwise same-source verifier
# Ini berbeda dari same-prompt clustering E33. Positif same-model/different-prompt;
# negatif same-prompt/sibling-provider/cross-provider. Sepuluh fitur simetris,
# TFIDF train-only dan frozen features dengan provenance. Pilih4head pada24prompt
# inner-val setelah fit96prompt, lalu refit120 dan test30; alpha0,1 fixed.
# Enam referensi per kelas diambil acak dengan seed tetap. Train score mengecualikan
# referensi dari prompt yang sama. Public0,667 memakai anotasi cue tambahan yang
# tidak dipakai di sini; ini adaptasi, bukan replikasi atau janji skor tersebut.

# %%
with step('E34 source-verifier experiment', 1):
    directory=ROOT/'research/experiments/e34_pairwise_identity'
    e34=json.loads((directory/'results.json').read_text())
    folds=[json.loads((directory/f'fold{f}.json').read_text()) for f in range(5)]
    display(pd.DataFrame([dict(fold=r['fold'],chosen=r['chosen']['name'],
        train_verifier=r['refit_train_source_ba_excluding_same_prompt_refs'],
        validation_verifier=r['chosen']['val_source_ba'],**r['test'],seconds=r['elapsed_s']) for r in folds]).round(5))
    print('Mean test',e34['mean_test'],'pooled',e34['pooled_test'])
    print('Fixed-alpha delta interval',e34['fusion_minus_baseline'],'positive folds',e34['positive_folds'])
    print('CPU seconds',round(e34['elapsed_s'],2),'official best remains0.665; target0.99 unachieved.')

# %% md
# ## 24. E35: konteks dari prompt training yang diketahui berbeda
# Mengganti sebagian3500konteks dengan seluruh outertraining passages dan
# seeded external filler, tanpa respons test tambahan dari prompt target.
# Target→trainingprompt link pasti salah; target→eksternal masih unknown.
# Gaussian sudah melihat trainingcontext saatfit: ini reference-context stress,
# bukan4000unseenrows IID. Target dari kasus/seed dapat berulang; jangan menganggap
# setiap error edge di berbagai kasus sebagai peristiwa independen.

# %%
with step('E35 known-different-prompt context', 1):
    e35=json.loads((ROOT/'research/experiments/e35_mixed_context/results.json').read_text())
    display(pd.DataFrame([dict(case=k,rows=v['rows'],**v['balanced_accuracy18'],
        wrong_training_edges=v['diagnostics_totals']['target_training_known_wrong_edges'],
        unknown_external_edges=v['diagnostics_totals']['target_external_unknown_edges']) for k,v in e35['cases'].items()]).round(5))
    print('CPU seconds',round(e35['elapsed_s'],2))
    print('Primary predictions unchanged versus E32/E33; this scale fixture gives no accuracy gain.')
    print('E34 rejected; E33/E35 diagnostics do not establish a better submission. No new submission sent.')
