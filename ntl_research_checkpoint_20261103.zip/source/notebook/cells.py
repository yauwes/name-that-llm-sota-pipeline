# %% md
# # Name That LLM: runner A100, 70/15/15 antileakage
#
# **Sebelum menjalankan**
# 1. Runtime: GPU A100, High RAM.
# 2. Folder Drive `MyDrive/name-that-llm 2/` berisi `train.csv`, `test.csv`, `sample_submission.parquet`. Semua hasil juga tersimpan di sini.
# 3. Colab Secrets (ikon kunci, beri akses ke notebook): `KAGGLE_API_TOKEN` milik akun yang sudah join kompetisi. Token ini wajib karena bobot model dan pool diunduh dari Kaggle. `HF_TOKEN` opsional.
# 4. Runtime > Run all, lalu izinkan akses Drive.
#
# **Perkiraan waktu:** 20 sampai 32 jam total untuk 13 anggota, terbagi dalam beberapa sesi Colab. Angka ini diperbarui otomatis dari kecepatan terukur.
#
# **Kalau koneksi putus:** Run all lagi. Tahap yang selesai dilewati, tahap yang belum selesai lanjut dari checkpoint terakhir, paling jauh mundur 15 menit.
#
# **Pantau kemajuan:** tabel di output sel `run` memperbarui diri setiap rotasi. Dari Drive, buka `MONITOR.md`: persen selesai, sisa jam, perkiraan selesai, langkah yang sedang berjalan, lalu train, val, test, macro-F1, akurasi family, log loss, recall terendah, dan celah overfit per anggota. Riwayatnya ada di `metrics.jsonl` dan `run.log`.
#
# **Hasil akhir di Drive:** `LAPORAN.md`, `scenarios.csv`, `results.jsonl`, `members/`, `stacks/`, dan folder `submission/`.
#
# **Submit manual:** kompetisi ini hanya menerima submission dari Kaggle Notebook (`isKernelsSubmissionsOnly`), dan `test.csv` yang terlihat cuma 3 baris, jadi parquet dari Colab tidak bisa dinilai. Yang tersimpan di `submission/` adalah bahan untuk diunggah: `ntl-artifacts.zip`, `infer_<skenario>.ipynb`, dan langkahnya di `CARA_SUBMIT.md`. Notebook ini tidak mengirim apa pun ke Kaggle. Setelah skor keluar, isi `lb_observed.json`, contoh `{"S11": 0.65}`, lalu jalankan ulang agar ekspektasi terkalibrasi.
# %% setup
import os, sys, subprocess, time
KAGGLE = 'KAGGLE_KERNEL_RUN_TYPE' in os.environ  # not the /kaggle/input folder, which a Colab runtime can have too: that sent Colab down the Kaggle path and glob()[0] raised IndexError
os.environ['TZ'] = 'Asia/Jakarta'; time.tzset()
SMOKE = KAGGLE  # on Kaggle this notebook only checks that the code runs end to end
if not KAGGLE:
    from google.colab import drive, userdata
    drive.mount('/content/drive')
    for k in ('KAGGLE_API_TOKEN', 'HF_TOKEN'):
        try: os.environ[k] = userdata.get(k)
        except Exception: print('secret not set:', k)
    subprocess.run('pip -q install -U kaggle transformers==5.16.1 peft==0.20.0 accelerate==1.14.0 lightgbm==4.6.0', shell=True, check=True)
HOME = '/kaggle/working/name-that-llm 2' if KAGGLE else '/content/drive/MyDrive/name-that-llm 2'  # the space is kept in the smoke run on purpose
MODELS_ON_DRIVE = False  # base weights take about 80 GB and load slowly from Drive; they re-download in minutes after a disconnect
MODELS = f'{HOME}/models' if MODELS_ON_DRIVE else ('/kaggle/working/models' if KAGGLE else '/content/models')
assert KAGGLE or os.path.isdir('/content/drive/MyDrive'), 'Drive belum ter-mount'
os.makedirs(HOME, exist_ok=True); sys.path.insert(0, HOME); os.chdir(HOME); os.environ['NTL_LOG'] = f'{HOME}/run.log'
print('lingkungan', 'Kaggle smoke' if KAGGLE else 'Colab', '| folder', HOME, '| isi', sorted(os.listdir(HOME))[:12])
# %% lib
%%writefile ntl_lib.py
__LIB__
# %% data
import glob, importlib, shutil, ntl_lib
importlib.reload(ntl_lib)
from ntl_lib import *
def sh(*a): subprocess.run(a, check=True)
if KAGGLE:
    TRAIN = glob.glob('/kaggle/input/**/name-that-llm/train.csv', recursive=True)[0]; POOL = glob.glob('/kaggle/input/**/ntl_open_pool.parquet', recursive=True)[0]
    TEST = TRAIN.replace('train.csv', 'test.csv')
else:
    TRAIN, TEST, POOL = f'{HOME}/train.csv', f'{HOME}/test.csv', f'{HOME}/ntl_open_pool.parquet'
    assert os.path.exists(TRAIN), f'train.csv tidak ada di {HOME}'
    assert torch.cuda.is_available(), 'runtime belum memakai GPU'
    assert os.environ.get('KAGGLE_API_TOKEN'), 'isi Colab Secret KAGGLE_API_TOKEN: bobot model dan pool diunduh dari Kaggle'
    if not os.path.exists(POOL):
        sh('kaggle', 'datasets', 'download', 'crtproduction/name-that-llm-open-pool', '-f', 'ntl_open_pool.parquet', '-p', HOME, '--unzip')
t = load_train(TRAIN); p = load_pool(POOL)
if SMOKE: t = t[t.prompt_id.isin(t.prompt_id.unique()[:10])].reset_index(drop=True); p = p.sample(360, random_state=0).reset_index(drop=True)
S = make_splits(t); p, LEAK = leak_checks(t, S, p); atomic(f'{HOME}/leak_checks.json', lambda f: f.write(json.dumps(LEAK, indent=1).encode()))
log('train', t.shape, 'pool', p.shape, 'gpu', torch.cuda.get_device_name(0), 'bf16', BF, 'disk', shutil.disk_usage(HOME).free // 2**30, 'GB free'); log(LEAK)

def model_dir(src):
    if KAGGLE:
        return os.path.dirname(glob.glob(f'/kaggle/input/**/{src}/config.json', recursive=True)[0])
    d = f"{MODELS}/{src.replace('/', '_').replace(':', '_')}"
    if not os.path.exists(d + '/config.json'):
        if src.startswith('hf:'):
            from huggingface_hub import snapshot_download
            snapshot_download(src[3:], local_dir=d)
        else: sh('kaggle', 'models', 'instances', 'versions', 'download', src, '-p', d, '--untar')
    return d
# %% experiments
L24 = [2, 4, 6, 8, 12, 16, 20, 24]; L27 = [2, 4, 8, 12, 16, 20, 24, 27]
Q8, Q14, LL8 = 'qwen-lm/qwen-3/transformers/8b-base/1', 'qwen-lm/qwen-3/transformers/14b-base/1', 'alexchilton/llama-3-1-8b-base/transformers/default/1'
# h: planned hours on A100, used only for the ETA. The ETA rescales itself after the first finished member.
EXPERIMENTS = {
    # sparse and stylometry
    'svc_p190k':    dict(tag='sparse', h=2., kind='svc', cap=20000, w=.35),
    'svc4_p190k':   dict(tag='sparse', h=3., kind='svc', v4=True, ih=.7, cap=20000, w=.35),  # the public 4-view recipe; h is a guess until the CPU run reports
    'lgb_style':    dict(tag='sparse', h=.02, kind='lgb'),
    # two-stage LoRA backbones
    'q8':           dict(tag='lora', h=1.25, kind='lora', src=Q8, keep=24, layers=L24, cap=3000, seed=11),
    'll8':          dict(tag='lora', h=1.25, kind='lora', src=LL8, keep=24, layers=L24, cap=3000, seed=13),
    'q14':          dict(tag='lora', h=2.5, kind='lora', src=Q14, keep=27, layers=L27, cap=3000, seed=12, bt=3),
    'q25_7':        dict(tag='lora', h=1.25, kind='lora', src='qwen-lm/qwen2.5/transformers/7b/1', keep=21, layers=[2, 4, 6, 8, 12, 16, 20, 21], cap=3000, seed=14),
    'deberta':      dict(tag='lora', h=1.25, kind='lora', src='hf:microsoft/deberta-v3-large', lora=False, keep=None, layers=[4, 8, 12, 16, 20, 24], cap=3000, seed=15, lr_s1=2e-5, lr_s2=1e-5),
    # data scale: the whole pool in stage 1
    'q8_full':      dict(tag='scale', h=4., kind='lora', src=Q8, keep=24, layers=L24, cap=20000, seed=21),
    # student-teacher: stage 1 teachers relabel the noisy pool without seeing host rows; the second round uses students as teachers
    'q8_kd':        dict(tag='kd', h=2., kind='lora', src=Q8, keep=24, layers=L24, cap=3000, seed=31, teachers=['q8', 'q14', 'll8']),
    'q14_kd':       dict(tag='kd', h=3.5, kind='lora', src=Q14, keep=27, layers=L27, cap=3000, seed=32, bt=3, teachers=['q8', 'q14', 'll8']),
    'q8_kd2':       dict(tag='kd', h=1.75, kind='lora', src=Q8, keep=24, layers=L24, cap=3000, seed=33, teachers=['q8_kd', 'q14_kd']),
    # source-conditioned likelihood
    'atlas_q8':     dict(tag='atlas', h=2., kind='atlas', src=Q8, cap=1500, seed=41),
}
if SMOKE:
    EXPERIMENTS = {'svc': dict(tag='sparse', h=.01, kind='svc', cap=10, w=.35), 'svc4': dict(tag='sparse', h=.01, kind='svc', v4=True, cap=10, w=.35), 'lgb_style': dict(tag='sparse', h=.01, kind='lgb'), 'q8': dict(tag='lora', h=.3, kind='lora', src=Q8, keep=24, layers=L24, cap=10, seed=11, bt=2),
                   'atlas_q8': dict(tag='atlas', h=.5, kind='atlas', src=Q8, cap=10, seed=41, bt=2, sbs=1, multi=True)}  # the full causal model only fits a T4 split over both GPUs
# scenarios are fixed before any result exists. Each one is a candidate submission.
SCENARIOS = {
    'S1': dict(desc='sparse saja: SVC pool + LightGBM', tags=['sparse']),
    'S2': dict(desc='satu LoRA dua tahap: Qwen3-8B', only=['q8']),
    'S3': dict(desc='blend semua LoRA', tags=['lora']),
    'S4': dict(desc='LoRA + sparse', tags=['lora', 'sparse']),
    'S5': dict(desc='S4 + stage 1 seluruh pool', tags=['lora', 'sparse', 'scale']),
    'S6': dict(desc='S5 + student-teacher', tags=['lora', 'sparse', 'scale', 'kd']),
    'S7': dict(desc='S6 + ATLAS', tags=['lora', 'sparse', 'scale', 'kd', 'atlas']),
    'S8': dict(desc='S7 + bukti tipografi', tags=['lora', 'sparse', 'scale', 'kd', 'atlas'], typo=True),
    'S9': dict(desc='S8 + soft Sinkhorn', tags=['lora', 'sparse', 'scale', 'kd', 'atlas'], typo=True, sink=True),
    'S10': dict(desc='S9 + twin head terpusat', tags=['lora', 'sparse', 'scale', 'kd', 'atlas'], typo=True, sink=True, twin=True),
    'S11': dict(desc='S10 + sibling residual', tags=['lora', 'sparse', 'scale', 'kd', 'atlas'], typo=True, sink=True, twin=True, sib=True),
}
BS = 64 if torch.cuda.get_device_properties(0).total_memory > 30e9 else 8
for k, c in EXPERIMENTS.items(): c['out'] = f'{HOME}/members/{k}'
atomic(f'{HOME}/plan.json', lambda f: f.write(json.dumps({k: dict(h=c['h'], neural=c['kind'] in ('lora', 'atlas')) for k, c in EXPERIMENTS.items()}).encode()))
write_monitor()
# %% run
import traceback
def run(name, c):
    D = Path(c['out'])
    if (D / 'oof.npy').exists() and (c['kind'] in ('svc', 'lgb') or (D / 'foldfinal.done').exists()): return np.load(D / 'oof.npy')
    if 'src' in c: c['dir'] = model_dir(c['src'])
    for te in c.get('teachers', []):
        tc = EXPERIMENTS[te]; tc['dir'] = model_dir(tc['src']); assert (Path(tc['out']) / 'stage1.pt').exists(), f'{te} must run first'
    c = {**c, 'teachers': [EXPERIMENTS[x] for x in c.get('teachers', [])]}
    if c['kind'] == 'svc': return run_svc(name, c, t, p, S)
    if c['kind'] == 'lgb': return run_lgb(name, c, t, S)
    if c['kind'] == 'atlas': return run_atlas(name, c, t, p, S)
    return run_lora(name, c, t, p, S, BS)

def member_row(name, c):
    r = [json.load(open(Path(c['out']) / f'fold{f}.done')) for f in range(5)]; tr = [x['train'] for x in r if x.get('train') is not None]
    return dict(name=name, train=float(np.mean(tr)) if tr else None, val=float(np.mean([x['val'] for x in r])), test=float(np.mean([x['test'] for x in r])), test_sd=float(np.std([x['test'] for x in r])))

def finished(c): return (Path(c['out']) / 'oof.npy').exists()
failed = {}
for name, c in EXPERIMENTS.items():
    was = finished(c); log('==', name); write_monitor(name); t0 = time.time(); partial = (Path(c['out']) / 'stage1.pt').exists() or (Path(c['out']) / 'fold0.done').exists()
    while True:  # retry sits outside the except block, otherwise the live traceback keeps the old model on the GPU
        oom = False
        try:
            run(name, c)
            if not was:
                r = {**member_row(name, c), 'minutes': round((time.time() - t0) / 60, 1), 'resumed': partial}; log(r)
                with open(f'{HOME}/results.jsonl', 'a') as fh: fh.write(json.dumps(r) + '\n')
        except torch.OutOfMemoryError: oom = True
        except Exception: failed[name] = traceback.format_exc(); log(name, 'FAILED', failed[name][-600:])
        gc.collect(); torch.cuda.empty_cache()
        if not oom: break
        if c.get('bt', 6) == 1: failed[name] = 'OOM at bt=1'; log(name, 'FAILED OOM at bt=1'); break
        c['bt'] = max(1, c.get('bt', 8 if c['kind'] == 'atlas' else 6) // 2); c['sbs'] = 1; log(name, 'OOM, retry with bt', c['bt'])
    RES = {r['name']: r for r in map(json.loads, open(f'{HOME}/results.jsonl'))} if os.path.exists(f'{HOME}/results.jsonl') else {}
    write_monitor()
log('failed:', list(failed))
assert not (SMOKE and failed), failed
# %% scenarios
# The leaderboard moves, so a fresh copy wins over the snapshot from 2026-11-01 (4147 teams).
LB_SNAPSHOT = __LB_SNAPSHOT__
LB = np.repeat(*zip(*LB_SNAPSHOT)); LB_DATE = '2026-11-01 (snapshot)'
if os.environ.get('KAGGLE_API_TOKEN') and not SMOKE:
    try:
        d = f'{HOME}/leaderboard'; sh('kaggle', 'competitions', 'leaderboard', 'name-that-llm', '-d', '-p', d); shutil.unpack_archive(f'{d}/name-that-llm.zip', d); f = sorted(glob.glob(f'{d}/*.csv'))[-1]
        LB = pd.read_csv(f).Score.values; LB_DATE = os.path.basename(f)[-24:-4]
    except Exception as e: log('leaderboard refresh failed, using snapshot', e)
def rank_of(x): return int((LB > x).sum()) + 1
OBS = json.load(open(f'{HOME}/lb_observed.json')) if os.path.exists(f'{HOME}/lb_observed.json') else {}
y = t.y.values; txt = t.text.tolist(); prompts = t.prompt_id.values
done_members = [k for k, c in EXPERIMENTS.items() if finished(c)]; OOF = {k: np.load(Path(EXPERIMENTS[k]['out']) / 'oof.npy') for k in done_members}
TWIN = {k: np.load(Path(EXPERIMENTS[k]['out']) / 'twin.npy') if (Path(EXPERIMENTS[k]['out']) / 'twin.npy').exists() else np.zeros_like(OOF[k]) for k in done_members}
SPREAD = .009  # same code moved this much on the public board in a public notebook
INFER_H = dict(svc=.35, lgb=.02, lora=.25, atlas=3.6)  # hours on Kaggle T4x2 for 4000 passages; svc and atlas measured, lora estimated
rows, seen = [], set(); Path(f'{HOME}/stacks').mkdir(exist_ok=True)
for sn, sc in SCENARIOS.items():
    ms = [k for k in done_members if (k in sc['only'] if 'only' in sc else EXPERIMENTS[k]['tag'] in sc['tags'])]; key = (tuple(ms), sc.get('typo', False), sc.get('sink', False), sc.get('twin', False), sc.get('sib', False))
    if not ms or key in seen: continue
    seen.add(key); r = eval_scenario([OOF[k] for k in ms], y, txt, prompts, S, sc.get('typo', False), sc.get('sink', False), [TWIN[k] if sc.get('twin') else np.zeros_like(OOF[k]) for k in ms], sc.get('sib', False)); use = [ms[i] for i in r['chosen']]
    if SMOKE and sn == list(SCENARIOS)[-1]: use = ms; r['weights'] = [1. / len(ms)] * len(ms); r['twin'] = 1.; r['sib'] = .08; r['typo'] = .25  # the smoke run must exercise every inference path
    cfg = dict(members=use, weights=r['weights'], typo=r['typo'], twin=r['twin'], sib=r['sib'], rho=r['rho']); atomic(f'{HOME}/stacks/{sn}.json', lambda f: f.write(json.dumps(cfg, indent=1).encode()))
    tr = [RES[k]['train'] for k in use if k in RES and RES[k]['train'] is not None]
    rows.append(dict(scenario=sn, desc=sc['desc'], members=use, metrics=r['metrics'], recall=r['recall'], confused=r['confused'], train=float(np.mean(tr)) if tr else None, val=r['val'], test=r['test'], test_sd=r['test_sd'], test_worst=r['test_worst'], test_mix=r['test_mix'], ci_lo=r['ci'][0], ci_hi=r['ci'][1], infer_h=sum(EXPERIMENTS[k].get('ih', INFER_H[EXPERIMENTS[k]['kind']]) for k in use), rotations=r['rotations'], typo=r['typo'], twin=r['twin'], sib=r['sib'], rho=r['rho']))
    log(sn, {k: rows[-1][k] for k in ('val', 'test', 'test_sd', 'test_worst', 'test_mix')}, use)
# calibrate on real scores once the user has any
offset = float(np.mean([OBS[r['scenario']] - r['test_mix'] for r in rows if r['scenario'] in OBS])) if any(r['scenario'] in OBS for r in rows) else 0.
for r in rows:
    r['exp_lb'] = r['test_mix'] + offset; r['lb_lo'] = r['exp_lb'] + r['ci_lo'] - r['test'] - SPREAD; r['lb_hi'] = r['exp_lb'] + r['ci_hi'] - r['test'] + SPREAD
    r['rank'] = rank_of(r['exp_lb']); r['rank_best'] = rank_of(r['lb_hi']); r['rank_worst'] = rank_of(r['lb_lo']); r['observed'] = OBS.get(r['scenario'])
    r['stable'] = bool(r['test_worst'] >= r['test'] - .05 and r['val'] - r['test'] <= .05 and r['infer_h'] <= 8); r['target'] = bool(r['exp_lb'] >= .72 and r['stable'])
# the pick looks at validation only, so choosing among scenarios cannot inflate the test score shown for it
pool_ = [r for r in rows if r['stable']] or rows; BEST = max(pool_, key=lambda r: r['val'])
if SMOKE: BEST = rows[-1]
PACK = [BEST['scenario']]  # add scenario names here to package more candidates, for example PACK = ['S11', 'S4']
pd.DataFrame([{**{k: v for k, v in r.items() if k not in ('rotations', 'metrics', 'recall', 'confused')}, **{f'test_{k}': v for k, v in r['metrics'].items()}} for r in rows]).to_csv(f'{HOME}/scenarios.csv', index=False)
atomic(f'{HOME}/scenarios_detail.json', lambda f: f.write(json.dumps(rows, indent=1).encode()))
log('BEST', BEST['scenario'], 'expected LB %.4f [%.4f, %.4f], rank %d [%d, %d]' % (BEST['exp_lb'], BEST['lb_lo'], BEST['lb_hi'], BEST['rank'], BEST['rank_best'], BEST['rank_worst']), 'TARGET 0.72', BEST['target'])
# %% report
def fm(x): return '-' if x is None else '%.4f' % x
L = ['# Laporan Name That LLM', '', f"Dibuat {time.strftime('%Y-%m-%d %H:%M')}. Leaderboard: {LB_DATE}, {len(LB)} tim, teratas {LB.max():.3f}.", '',
     '## Ringkasan', f"Rekomendasi: **{BEST['scenario']}** ({BEST['desc']}). Ekspektasi LB {BEST['exp_lb']:.4f}, rentang {BEST['lb_lo']:.4f} sampai {BEST['lb_hi']:.4f}. Ekspektasi peringkat {BEST['rank']}, rentang {BEST['rank_best']} sampai {BEST['rank_worst']}.",
     f"Target 0.72: **{'tercapai pada ekspektasi lokal' if BEST['target'] else 'belum tercapai'}**. Skor {.72:.2f} setara peringkat {rank_of(.72)} pada leaderboard ini.", f"Kalibrasi: {'offset %+.4f dari %d skor LB asli' % (offset, len([r for r in rows if r['observed'] is not None]))}" if OBS else 'Kalibrasi: belum ada skor LB asli, jadi offset 0. Ekspektasi belum terbukti sampai ada submission pertama.', '',
     '## Skenario dan ranking ekspektasi', 'Setiap baris adalah satu kandidat submission. Rekomendasi dipilih dari skor validation, bukan test.', '',
     '| Skenario | Isi | Train | Val | Test | SD | Fold terburuk | Test mix | LB ekspektasi | Rentang LB | Rank ekspektasi | Rentang rank | Infer (jam) | Stabil | LB asli |', '|---|---|---:|---:|---:|---:|---:|---:|---:|---|---:|---|---:|---|---:|']
for r in rows:
    L.append(f"| {r['scenario']} | {r['desc']} | {fm(r['train'])} | {r['val']:.4f} | {r['test']:.4f} | {r['test_sd']:.4f} | {r['test_worst']:.4f} | {r['test_mix']:.4f} | {r['exp_lb']:.4f} | {r['lb_lo']:.4f} - {r['lb_hi']:.4f} | {r['rank']} | {r['rank_best']} - {r['rank_worst']} | {r['infer_h']:.1f} | {'ya' if r['stable'] else 'tidak'} | {fm(r['observed'])} |")
L += ['', 'Train adalah rata-rata anggota pada 500 baris train, tanpa stack. Val memakai bobot yang dipilih pada baris itu sendiri, jadi cenderung lebih tinggi dari test. Test mix mengulang test pada komposisi kelas acak. Rentang LB adalah interval 90% resampling prompt ditambah pergeseran publik 0.009.']
L += ['', '## Metrik evaluasi per skenario', 'Dihitung pada baris test gabungan. Metrik resmi kompetisi adalah balanced accuracy. Log loss memakai skor yang belum dikalibrasi, jadi hanya untuk membandingkan antar skenario.', '', '| Skenario | Balanced acc | Macro-F1 | Akurasi | Akurasi family | Log loss | Recall terendah | Recall tertinggi | Interval 90% test |', '|---|---:|---:|---:|---:|---:|---:|---:|---|']
for r in rows:
    m = r['metrics']; L.append(f"| {r['scenario']} | {m['bacc']:.4f} | {m['macro_f1']:.4f} | {m['acc']:.4f} | {m['family_acc']:.4f} | {m['log_loss']:.3f} | {m['recall_min']:.3f} | {m['recall_max']:.3f} | {r['ci_lo']:.4f} - {r['ci_hi']:.4f} |")
L += ['', f"## Per rotasi: {BEST['scenario']}", '| Rotasi | Val | Test | Test mix | Jumlah anggota |', '|---:|---:|---:|---:|---:|'] + [f"| {i} | {x['val']:.4f} | {x['test']:.4f} | {x['test_mix']:.4f} | {x['n_members']} |" for i, x in enumerate(BEST['rotations'])]
L += ['', f"## Recall per kelas: {BEST['scenario']}", '| Kelas | Recall test |', '|---|---:|'] + [f'| {k} | {v:.3f} |' for k, v in sorted(BEST['recall'].items(), key=lambda kv: kv[1])]
L += ['', f"## Salah tebak terbanyak: {BEST['scenario']}", '| Asli -> tebakan | Baris |', '|---|---:|'] + [f'| {k} | {v} |' for k, v in BEST['confused'].items()]
L += ['',
      '## Anggota dan waktu', '| Anggota | Train | Val | Test | SD | Rencana (jam) | Terukur (jam) |', '|---|---:|---:|---:|---:|---:|---:|']
for k, c in EXPERIMENTS.items():
    if k in done_members:
        m = member_row(k, c); rr = RES.get(k); L.append(f"| {k} | {fm(m['train'])} | {m['val']:.4f} | {m['test']:.4f} | {m['test_sd']:.4f} | {c['h']:.2f} | {'-' if rr is None or rr['resumed'] else '%.2f' % (rr['minutes'] / 60)} |")
    else: L.append(f"| {k} | belum selesai | | | | {c['h']:.2f} | |")
L += ['', 'Monitor rotasi ada di `MONITOR.md` dan `metrics.jsonl`.']
L += ['', '## Pembanding: resep publik', 'Skor LB publik seperti yang ditulis penulis notebook, tidak dijalankan di protokol lokal karena adapternya dilatih pada seluruh train.', '', '| Notebook | LB publik | Rank setara |', '|---|---:|---:|'] + [f'| {n} | {x:.3f} | {rank_of(x)} |' for n, x in [('synthreaper/ntl-gold-apex-champion-0-670', .670), ('zbigniewkirchner/0-664-one-swap-198k-clean-pool-fully-public', .664), ('omerfarukmerey/0-663-0-660-v31-atlas-20', .663), ('nishantdahal/two-stage-lora-on-the-public-pool', .592)]]
L += ['', '## Antileakage', '- 5 rotasi 70/15/15 berdasarkan prompt. Satu prompt tidak pernah muncul di dua bagian dalam satu rotasi; dicek dengan assert setiap kali notebook jalan.', '- Blok test antar rotasi tidak tumpang tindih, begitu juga blok val.', '- Tahap 1 hanya melihat pool. Vektorizer, pohon, dan tahap 2 hanya melihat baris train rotasi itu.', '- Anggota, bobot, tipografi, twin, sibling, dan Sinkhorn dipilih dari val rotasi itu sendiri, lalu test dinilai sekali.', '- Twin dinilai pada pasangan acak 2 jawaban per prompt, bukan 18 jawaban penuh, karena grup penuh terbukti menipu: nested CV 0.6865 berakhir LB 0.56.', '', '```json', json.dumps(LEAK, indent=1), '```', '', '## Submit', 'Ikuti `submission/CARA_SUBMIT.md`. Setelah skor keluar, tulis ke `lb_observed.json` dan jalankan ulang.']
atomic(f'{HOME}/LAPORAN.md', lambda f: f.write('\n'.join(L).encode())); log('report saved', f'{HOME}/LAPORAN.md')
from IPython.display import Markdown, display
display(Markdown('\n'.join(L)))
# %% predict
# A real pass through the inference code on the 3 visible rows. test.csv on Kaggle is replaced at submission time.
out = f"{HOME}/stacks/{BEST['scenario']}_sample.parquet"
if not os.path.exists(out):
    cfg = json.load(open(f"{HOME}/stacks/{BEST['scenario']}.json")); te = pd.read_csv(TEST); Pr = predict_texts(te.text.tolist() + (t.text.tolist()[:60] if SMOKE else []), cfg, EXPERIMENTS, t, p, BS, lambda k: model_dir(EXPERIMENTS[k]['src']), lambda k: Path(EXPERIMENTS[k]['out']) / 'final.pt')[:len(te)]
    sub = pd.DataFrame({'id': te.id.astype(str), 'model': np.array(LABELS)[Pr.argmax(1)]}); assert sub.id.is_unique and sub.model.isin(LABELS).all() and len(sub) == len(te)
    sub.to_parquet(out, index=False); log(sub)
log('prediksi contoh 3 baris tersimpan', out)
# %% export
# Everything needed for a manual submission goes to HOME/submission. Nothing is sent to Kaggle from here.
INFER = r"""
import glob, json, os, sys
CAND = '__CAND__'
A = os.path.dirname(glob.glob('/kaggle/input/**/ntl_lib.py', recursive=True)[0]); sys.path.insert(0, A)
from ntl_lib import *
data = os.path.dirname(glob.glob('/kaggle/input/**/name-that-llm/test.csv', recursive=True)[0]); te = pd.read_csv(data + '/test.csv')
if len(te) < 50 and not os.environ.get('KAGGLE_IS_COMPETITION_RERUN'):
    # the commit run only needs a valid file; Kaggle reruns this notebook on the hidden test after Submit
    pd.DataFrame({'id': te.id.astype(str), 'model': 'gpt-5.5'}).to_parquet('submission.parquet', index=False)
else:
    cfg = json.load(open(f'{A}/stacks/{CAND}.json')); ex = json.load(open(A + '/members.json')); t = load_train(data + '/train.csv'); p = load_pool(glob.glob('/kaggle/input/**/ntl_open_pool.parquet', recursive=True)[0])
    def dir_of(k):
        s = ex[k]['src']
        return f'{A}/base_{k}' if s.startswith('hf:') else os.path.dirname(glob.glob(f"/kaggle/input/**/{s.split('/', 1)[1]}/config.json", recursive=True)[0])  # the owner may or may not be in the mount path
    Pr = predict_texts(te.text.tolist(), cfg, ex, t, p, 8, dir_of, lambda k: f'{A}/{k}/final.pt')
    sub = pd.DataFrame({'id': te.id.astype(str), 'model': np.array(LABELS)[Pr.argmax(1)]}); assert sub.id.is_unique and sub.model.isin(LABELS).all() and len(sub) == len(te); sub.to_parquet('submission.parquet', index=False)
"""
SUB = Path(f'{HOME}/submission'); shutil.rmtree(SUB, ignore_errors=True); SUB.mkdir()
ex = Path('/tmp/ntl_pkg'); shutil.rmtree(ex, ignore_errors=True); shutil.copytree(f'{HOME}/stacks', ex / 'stacks', ignore=shutil.ignore_patterns('*.parquet')); shutil.copy(f'{HOME}/ntl_lib.py', ex)
use = sorted({k for sn in PACK for k in json.load(open(f'{HOME}/stacks/{sn}.json'))['members']}); srcs = sorted({EXPERIMENTS[k]['src'] for k in use if not EXPERIMENTS[k].get('src', 'hf:').startswith('hf:')})
for k in use:
    c = EXPERIMENTS[k]
    if c['kind'] in ('lora', 'atlas'): (ex / k).mkdir(); shutil.copy(Path(c['out']) / 'final.pt', ex / k)
    if c.get('src', '').startswith('hf:'): shutil.copytree(model_dir(c['src']), ex / f'base_{k}')
json.dump({k: {a: b for a, b in EXPERIMENTS[k].items() if a in ('kind', 'src', 'keep', 'layers', 'cap', 'w', 'lora', 'v4')} for k in use}, open(ex / 'members.json', 'w'))
shutil.copy(shutil.make_archive('/tmp/ntl-artifacts', 'zip', ex), SUB / 'ntl-artifacts.zip')
for sn in PACK:
    json.dump(dict(cells=[dict(cell_type='code', execution_count=None, metadata={}, outputs=[], source=INFER.replace('__CAND__', sn).strip().splitlines(True))], metadata=dict(kernelspec=dict(display_name='Python 3', language='python', name='python3')), nbformat=4, nbformat_minor=5), open(SUB / f'infer_{sn}.ipynb', 'w'))
    shutil.copy(f'{HOME}/stacks/{BEST["scenario"]}_sample.parquet', SUB / 'submission_contoh_3_baris.parquet')
b_h = {r['scenario']: r for r in rows}; N_ = '\n'
md = f"""# Cara submit manual

Kompetisi ini hanya menilai submission dari Kaggle Notebook. `submission_contoh_3_baris.parquet` hanya bukti format; kalau diunggah, Kaggle tidak akan menilainya. Hidden test (sekitar 4.000 baris) baru tersedia saat Kaggle menjalankan ulang notebook.

1. Kaggle > Datasets > New Dataset: unggah `ntl-artifacts.zip`, biarkan private.
2. Kaggle > Code > New Notebook > File > Import Notebook: pilih `infer_{PACK[0]}.ipynb`.
3. Add Input, tambahkan:
   - Competition: name-that-llm
   - Dataset buatan langkah 1
   - Dataset: crtproduction/name-that-llm-open-pool
{N_.join('   - Model: ' + s for s in srcs) or '   - tidak ada model tambahan'}
4. Session options: Accelerator GPU T4 x2, Internet Off.
5. Save Version > Save & Run All. Commit selesai dalam beberapa menit karena hanya menulis placeholder.
6. Buka versi itu > Output > Submit to Competition. Kaggle menjalankan ulang pada hidden test, perkiraan {b_h[PACK[0]]['infer_h']:.1f} jam.
7. Setelah skor keluar, tulis ke `{HOME}/lb_observed.json`, contoh `{{"{PACK[0]}": 0.61}}`, lalu Run all lagi. Tahap yang selesai dilewati, ekspektasi semua skenario terkalibrasi.

Ekspektasi {PACK[0]}: LB {b_h[PACK[0]]['exp_lb']:.4f} ({b_h[PACK[0]]['lb_lo']:.4f} sampai {b_h[PACK[0]]['lb_hi']:.4f}), peringkat {b_h[PACK[0]]['rank']} ({b_h[PACK[0]]['rank_best']} sampai {b_h[PACK[0]]['rank_worst']}).
"""
(SUB / 'CARA_SUBMIT.md').write_text(md); log('submission tersimpan di', SUB, sorted(os.listdir(SUB)))
if KAGGLE: log('SMOKE OK')
else: drive.flush_and_unmount(); print('Drive tersimpan dan dilepas. Selesai.')
