# %% md
# Name That LLM: dari EDA sampai submission terbaik
#
# Klasifikasi 18 LLM dari satu passage, dinilai dengan **balanced accuracy** pada prompt yang tidak pernah terlihat.
# Notebook ini merangkum seluruh iterasi: EDA, protokol validasi, fitur, model tunggal, ensemble, post-processing,
# analisis error, eksperimen remodeling, dan perbandingan ekspektasi lokal lawan leaderboard.
#
# - Berjalan di CPU (Mac atau Kaggle CPU) dalam beberapa menit karena memakai OOF yang sudah dilatih di GPU (`kernels/*/out`).
# - Setiap sel mencetak estimasi waktu, waktu aktual, dan skornya.
# - Inferensi hidden test tidak bisa jalan di sini: ini code competition, jadi submission dibuat oleh kernel GPU (bagian 9).
#
# Status 2026-11-02: skor publik terbaik kita **0.664** (peringkat 179 dari 4.263). Puncak LB **0.744**.
# Target 0.99 tidak didukung bukti apa pun (lihat bagian 8).

# %%
import sys, time, json, re, hashlib
from contextlib import contextmanager
from pathlib import Path
import lightgbm as lgbm  # before torch (via lib): on macOS two OpenMP runtimes otherwise kill the kernel at the first fit
import numpy as np, pandas as pd, matplotlib.pyplot as plt
ROOT = Path.cwd().parent if Path('lib.py').exists() else Path.cwd()
sys.path.insert(0, str(ROOT / 'notebook')); import lib
from sklearn.metrics import balanced_accuracy_score as bas, confusion_matrix
from sklearn.linear_model import LogisticRegression
pd.set_option('display.width', 160); plt.rcParams.update({'figure.dpi': 110, 'axes.spines.top': False, 'axes.spines.right': False})
T0 = time.time()

@contextmanager
def step(name, eta):
    """log the expected and the measured runtime of each stage."""
    t = time.time(); print(f'> {name} | estimasi ~{eta}s', flush=True); yield
    print(f'< {name} selesai {time.time() - t:.1f}s | total notebook {time.time() - T0:.0f}s', flush=True)

# %% md
# ## 1. EDA
# Train: 2.699 passage dari 150 prompt, 18 model per prompt (satu pasangan hilang). Test lokal hanya 3 baris;
# hidden test sekitar 4.000 passage dari prompt baru dan **tidak punya `prompt_id`**.

# %%
with step('muat data', 2):
    t = lib.load_train(ROOT / 'data/train.csv'); y = t.y.values; txt = t.text.tolist(); pr = t.prompt_id.values
    test = pd.read_csv(ROOT / 'data/test.csv')
    t['words'] = t.text.str.split().str.len(); t['fam'] = lib.FAM[y]
    print('train', t.shape, '| prompt', t.prompt_id.nunique(), '| label', t.model.nunique(), '| test lokal', test.shape, list(test.columns))
    print('passage per prompt:', t.groupby('prompt_id').size().value_counts().to_dict())
    print('baris per label (min, max):', t.model.value_counts().min(), t.model.value_counts().max())
    display(t.groupby('model').words.describe()[['mean', '50%', 'min', 'max']].round(1).T)

# %%
with step('panjang dan tipografi per model', 5):
    marks = {'em dash —': '—', 'semicolon ;': ';', 'kutip “': '“', 'kolon :': ':', 'tanda seru !': '!', 'kurung (': '('}
    M = pd.DataFrame({k: t.text.str.contains(re.escape(v)) for k, v in marks.items()}); M['we/our/us'] = t.text.str.contains(r'\b(?:we|our|us)\b', case=False)
    share = M.groupby(t.model).mean()
    fig, ax = plt.subplots(1, 2, figsize=(13, 5.5), gridspec_kw={'width_ratios': [1, 1.3]})
    order = t.groupby('model').words.median().sort_values().index
    ax[0].boxplot([t.words[t.model == m] for m in order], orientation='horizontal', tick_labels=order, showfliers=False); ax[0].set_xlabel('kata per passage'); ax[0].set_title('Panjang')
    im = ax[1].imshow(share.loc[order].values, aspect='auto', cmap='Blues', vmin=0, vmax=1); ax[1].set_yticks(range(18), order); ax[1].set_xticks(range(share.shape[1]), share.columns, rotation=40, ha='right')
    for i in range(18):
        for j in range(share.shape[1]): ax[1].text(j, i, f'{share.loc[order].values[i, j]:.2f}', ha='center', va='center', fontsize=7)
    ax[1].set_title('Proporsi passage yang memuat penanda'); plt.tight_layout(); plt.show()
    print('Em dash dan kutip melengkung memisahkan keluarga (mis. Claude lawan GPT), tidak versi di dalam keluarga.')

# %%
with step('celah gaya train lawan Open Pool', 15):
    pool = pd.read_parquet(ROOT / 'data/pool/ntl_open_pool.parquet', columns=['text', 'model', 'flag_kb_proxy', 'n_words'])
    we = lambda s: s.str.contains(r'\b(?:we|our|us)\b', case=False).mean()
    print(f'pool {len(pool):,} baris | baris proxy Benchmarks {pool.flag_kb_proxy.mean():.1%}')
    print(f'passage memakai we/our/us: train {we(t.text):.1%} | pool {we(pool.text):.1%}')
    print('Prompt host mendorong suara kolektif yang jarang ada di pool. Inilah celah domain yang tidak bisa ditutup dengan membersihkan pool.')

# %% md
# ## 2. Protokol validasi
# Unit generalisasi adalah **prompt**. Lima rotasi 70/15/15 per prompt: bobot dan post-processing dipilih di blok val,
# skor dilaporkan sekali di blok test. Satu kode identik bisa bergeser 0.009 di LB, jadi kenaikan di bawah itu bukan bukti.

# %%
with step('split 70/15/15 x5', 1):
    S = lib.make_splits(t)
    print('MD5 split', hashlib.md5(S.tobytes()).hexdigest(), '(terkunci, sama dengan semua eksperimen)')
    print(pd.DataFrame([{'rotasi': f, 'train': int((S[f] == 0).sum()), 'val': int((S[f] == 1).sum()), 'test': int((S[f] == 2).sum()),
                         'prompt test': len(set(pr[S[f] == 2]))} for f in range(5)]).to_string(index=False))
    print('Cek kebocoran (research/experiments/leak.py): id 0.054, prompt_id 0.055, urutan baris 0.049, panjang 0.096, chance 0.056. Duplikat exact train-pool: 0.')

# %% md
# ## 3. Fitur, seleksi fitur, dan celah train-val-test
# Stilometri (`lib.stylo`, 77 fitur) dengan LightGBM. Seleksi fitur: importance dipilih di blok train setiap rotasi
# (bukan di seluruh data), lalu top-k dibandingkan dengan semua fitur.

# %%
with step('stilometri + seleksi fitur LightGBM', 210):
    X = pd.DataFrame([lib.stylo(s) for s in txt])
    mk = lambda: lgbm.LGBMClassifier(n_estimators=400, learning_rate=.03, num_leaves=15, subsample=.8, subsample_freq=1, colsample_bytree=.4, min_child_samples=10, reg_lambda=2, verbose=-1)
    rows = []
    for f in range(5):
        tr, v, te = S[f] == 0, S[f] == 1, S[f] == 2; m = mk().fit(X[tr], y[tr])
        top = X.columns[np.argsort(-m.feature_importances_)[:30]]; m30 = mk().fit(X.loc[tr, top], y[tr])
        rows.append(dict(rotasi=f, train=bas(y[tr], m.predict(X[tr])), val=bas(y[v], m.predict(X[v])), test=bas(y[te], m.predict(X[te])), test_top30=bas(y[te], m30.predict(X.loc[te, top]))))
    R = pd.DataFrame(rows); display(R.round(4)); print('rata-rata', R.mean().round(4).to_dict())
    imp = pd.Series(mk().fit(X, y).feature_importances_, X.columns).sort_values(ascending=False)
    print('fitur terpenting:', ', '.join(imp.index[:12]))
    print('Train mendekati 1.0, test sekitar 0.30: model menghafal prompt. Gap inilah yang harus diukur di prompt baru, bukan di baris train.')

# %% md
# ## 4. Model tunggal
# Anggota dilatih di GPU pada sesi sebelumnya. OOF disimpan dengan NaN di baris train setiap rotasi.
#
# | Anggota | Isi | Sumber |
# |---|---|---|
# | `svc` | char 2-5 + gaya + bentuk, Open Pool 190k bobot 0.35 | `kernels/sparse7015` |
# | `svc4` | SVC 4-view publik (char, kata, bentuk, kata fungsi) | `kernels/svc4` |
# | `lgb` | LightGBM stilometri | `kernels/sparse7015` |
# | `q8_s1`, `ll8_s1` | LoRA Qwen3-8B / Llama-3.1-8B tahap 1, hanya pool | `kernels/twostage` |
# | `q8`, `ll8` | sama, ditambah tahap 2 pada baris host | `kernels/twostage` |
#
# Catatan: `q8`/`ll8` dilatih dengan 5-fold lama, jadi OOF-nya tetap bebas prompt tetapi modelnya tidak persis per rotasi.

# %%
with step('muat OOF dan skor per anggota', 5):
    def rot(o):
        z = np.stack([o] * 5).astype(np.float32)
        for f in range(5): z[f, S[f] == 0] = np.nan
        return z
    K = ROOT / 'kernels'; TS = K / 'twostage/out_full'
    members = {'svc': np.load(K / 'sparse7015/out/members/svc_p190k/oof.npy'), 'svc4': np.load(K / 'svc4/out/members/svc4_p190k/oof.npy'),
               'lgb': np.load(K / 'sparse7015/out/members/lgb_style/oof.npy'),
               'q8_s1': rot(np.load(TS / 'out_q8/s1_plain.npy')), 'll8_s1': rot(np.load(TS / 'out_ll8/s1_plain.npy')),
               'q8': rot(np.load(TS / 'out_q8/oof_plain.npy')), 'll8': rot(np.load(TS / 'out_ll8/oof_plain.npy'))}
    members = {k: v.astype(np.float32) for k, v in members.items()}
    def per_rot(L):
        return [(bas(y[S[f] == 1], L[f][S[f] == 1].argmax(1)), bas(y[S[f] == 2], L[f][S[f] == 2].argmax(1))) for f in range(5)]
    single = pd.DataFrame({k: dict(val=np.mean([a for a, _ in per_rot(v)]), test=np.mean([b for _, b in per_rot(v)]), test_sd=np.std([b for _, b in per_rot(v)]),
                                   family=float((lib.FAM[np.nanargmax(np.nan_to_num(v[0], nan=-1e9), 1)] == lib.FAM[y])[S[0] == 2].mean())) for k, v in members.items()}).T
    display(single.round(4))
    d1 = single.loc['q8', 'test'] - single.loc['q8_s1', 'test']; d2 = single.loc['ll8', 'test'] - single.loc['ll8_s1', 'test']
    print(f'Tahap 2 (sekitar 2.160 baris host) menambah q8 {d1:+.3f} dan ll8 {d2:+.3f} di atas 190k pool. Data bergaya host adalah tuas terbesar.')

# %% md
# ## 5. Ensemble
# Semua metode memilih anggota atau bobot di blok val, lalu dinilai sekali di blok test setiap rotasi.
# - **mean**: rata-rata skor terstandar per baris.
# - **weighted**: forward selection + bobot L-BFGS pada log loss (`lib.select_stack`).
# - **hill climbing**: Caruana dengan pengulangan, pada balanced accuracy val.
# - **stacking**: regresi logistik di atas probabilitas anggota, dilatih di baris val.
# - **rank**: rata-rata rank per kelas lintas baris.
# - **vote**: mayoritas argmax, seri dipecah rata-rata skor.

# %%
with step('enam metode ensemble x5 rotasi', 30):
    names = ['svc', 'svc4', 'lgb', 'q8', 'll8']; Ls = [members[k] for k in names]
    def hill(Lv, yv, iters=25):
        Z = [lib.N(l) for l in Lv]; cnt = np.zeros(len(Z)); cur = 0; best = -1
        for _ in range(iters):
            sc = [bas(yv, (cur + z).argmax(1)) for z in Z]; i = int(np.argmax(sc))
            if sc[i] <= best: break
            best = sc[i]; cur = cur + Z[i]; cnt[i] += 1
        return cnt / cnt.sum()
    def rank(Lt): return sum(pd.DataFrame(l).rank(pct=True).values for l in Lt)
    def vote(Lt):
        V = np.zeros_like(Lt[0]); [np.add.at(V, (np.arange(len(l)), l.argmax(1)), 1) for l in Lt]; return V + 1e-3 * sum(lib.N(l) for l in Lt)
    res = {k: [] for k in ['best single', 'mean', 'weighted', 'hill climbing', 'stacking', 'rank', 'vote']}; pooled = np.full(len(y), -1); W = []
    for f in range(5):
        v, te = S[f] == 1, S[f] == 2; Lv, Lt = [l[f][v] for l in Ls], [l[f][te] for l in Ls]
        b = int(np.argmax([bas(y[v], l.argmax(1)) for l in Lv])); res['best single'].append(bas(y[te], Lt[b].argmax(1)))
        res['mean'].append(bas(y[te], lib.blend(Lt, np.ones(len(Lt))).argmax(1)))
        ch, w = lib.select_stack(Lv, y[v]); P = lib.blend([Lt[j] for j in ch], w); res['weighted'].append(bas(y[te], P.argmax(1))); pooled[te] = P.argmax(1)
        wh = hill(Lv, y[v]); res['hill climbing'].append(bas(y[te], lib.blend(Lt, wh).argmax(1))); W.append({k: float(x) for k, x in zip(names, wh.round(2)) if x})
        st = LogisticRegression(C=.1, max_iter=500).fit(np.hstack([lib.softmax(l) for l in Lv]), y[v]); res['stacking'].append(bas(y[te], st.predict(np.hstack([lib.softmax(l) for l in Lt]))))
        res['rank'].append(bas(y[te], rank(Lt).argmax(1))); res['vote'].append(bas(y[te], vote(Lt).argmax(1)))
    E = pd.DataFrame({k: dict(test=np.mean(v), sd=np.std(v), worst=np.min(v)) for k, v in res.items()}).T.sort_values('test', ascending=False)
    display(E.round(4)); print('bobot hill climbing per rotasi:', W)
    m = pooled >= 0; ci = lib.prompt_ci(y, pooled, pr, m)
    print(f'weighted, test gabungan {bas(y[m], pooled[m]):.4f}, CI 90% per prompt {ci[0]:.3f}-{ci[1]:.3f}')

# %% md
# ### Post-processing
# Bukti tipografi dan soft Sinkhorn, kekuatannya dipilih di val (`lib.eval_scenario`). Sinkhorn dinilai juga pada campuran
# kelas acak (`test_mix`), karena hidden test tidak seimbang dan fold seimbang menyanjung Sinkhorn.

# %%
with step('post-processing tipografi + Sinkhorn', 60):
    base = lib.eval_scenario([members[k] for k in ('q8', 'll8', 'svc4')], y, txt, pr, S)
    post = lib.eval_scenario([members[k] for k in ('q8', 'll8', 'svc4')], y, txt, pr, S, typo=True, sink=True)
    display(pd.DataFrame({'q8+ll8+svc4': base, '+ tipografi + Sinkhorn': post}).loc[['val', 'test', 'test_sd', 'test_mix', 'test_worst']].astype(float).round(4))
    print('Ronde 2 (research/experiments/round2.json) menguji bias kelas, ahli keluarga, twin, stacking val, head KD: tidak ada yang lolos CI.')

# %% md
# ## 6. Analisis error
# Berdasarkan prediksi test gabungan dari ensemble weighted.

# %%
with step('confusion matrix dan recall', 3):
    C = confusion_matrix(y[m], pooled[m], labels=range(18), normalize='true')
    fam_ok = (lib.FAM[pooled[m]] == lib.FAM[y[m]]); err = pooled[m] != y[m]
    print(f'akurasi keluarga {fam_ok.mean():.3f} | error yang tetap di keluarga yang benar {(fam_ok & err).sum() / err.sum():.1%}')
    fig, ax = plt.subplots(1, 2, figsize=(14, 6), gridspec_kw={'width_ratios': [1.4, 1]})
    ax[0].imshow(C, cmap='Blues', vmin=0, vmax=1); ax[0].set_xticks(range(18), lib.LABELS, rotation=90, fontsize=7); ax[0].set_yticks(range(18), lib.LABELS, fontsize=7)
    for i in range(18):
        for j in range(18):
            if C[i, j] >= .08: ax[0].text(j, i, f'{C[i, j]:.2f}', ha='center', va='center', fontsize=6, color='white' if C[i, j] > .5 else 'black')
    ax[0].set_xlabel('prediksi'); ax[0].set_ylabel('label'); ax[0].set_title('Confusion matrix (dinormalisasi per label)')
    rec = pd.Series(np.diag(C), lib.LABELS).sort_values(); ax[1].barh(rec.index, rec.values, color='#3b6ea5'); ax[1].set_xlim(0, 1); ax[1].set_title('Recall per label'); ax[1].tick_params(labelsize=7)
    plt.tight_layout(); plt.show()
    conf = pd.Series([f'{lib.LABELS[a]} -> {lib.LABELS[b]}' for a, b in zip(y[m], pooled[m]) if a != b]).value_counts().head(8); print(conf.to_string())
    tw = t.words.values[m]; q = pd.qcut(tw, 4)
    print('akurasi per kuartil panjang:', pd.Series(pooled[m] == y[m]).groupby(q, observed=True).mean().round(3).to_dict())

# %% md
# ## 7. Remodeling: berapa nilai satu prompt host lagi?
# **E10** (CPU, `research/experiments/host_value.py`): kurva belajar dengan k prompt host dari blok train setiap rotasi,
# dinilai di blok test. Ditambah augmentasi **crop**: setiap passage host menyumbang dua potongan (60% kalimat awal dan akhir)
# berlabel sama.
#
# **E11** (GPU T4x2, `kernels/s2crops`): tahap 2 LoRA q8 dan ll8 diulang dengan crop, memakai checkpoint tahap 1 yang sama,
# lalu dibandingkan berpasangan per fold dengan OOF asli. Desain: 1 epoch atas asli + 2 crop (sekitar 1,1x komputasi) lawan 2 epoch atas asli.

# %%
with step('kurva belajar data host (E10)', 2):
    hv = json.load(open(ROOT / 'research/experiments/host_value.json'))
    ks = [13, 26, 52, 78, 105]
    fig, ax = plt.subplots(figsize=(7, 4))
    ax.errorbar(ks, [hv[f'svc_k{k}']['mean'] for k in ks], [hv[f'svc_k{k}']['sd'] for k in ks], marker='o', label='SVC host saja')
    ax.errorbar([0] + ks, [hv[f'probe_k{k}']['mean'] for k in [0] + ks], [hv[f'probe_k{k}']['sd'] for k in [0] + ks], marker='s', label='probe 27B beku + 3.600 pool')
    ax.scatter([26, 105], [hv['svc_crop_k26']['mean'], hv['svc_crop_k105']['mean']], marker='*', s=160, color='C3', zorder=5, label='SVC + crop')
    ax.set_xlabel('jumlah prompt host di train'); ax.set_ylabel('balanced acc test'); ax.legend(); ax.set_title('Belum jenuh: tiap 2x prompt host sekitar +0.03'); plt.show()
    lg = open(ROOT / 'research/experiments/host_value.log').read(); rws = [eval(x) for x in re.findall(r'rotation \d done, \d+s (\{.*\})', lg)]
    def unroll(k): c = [r[k] for r in rws]; return np.array([c[0]] + [(i + 1) * c[i] - i * c[i - 1] for i in range(1, len(c))])
    for k in (26, 105):
        d = unroll(f'svc_crop_k{k}') - unroll(f'svc_k{k}'); print(f'crop k={k}: delta per rotasi {np.round(d, 4)}, rata-rata {d.mean():+.4f}, positif {int((d > 0).sum())}/5')

# %%
with step('crop pada LoRA tahap 2 (E11)', 2):
    out = ROOT / 'kernels/s2crops/out'
    fold = t.prompt_id.map({p: i % 5 for i, p in enumerate(pd.Series(t.prompt_id.unique()).sample(frac=1, random_state=42))}).values
    for k in ('q8', 'll8'):
        f_ = list(out.glob(f'**/out_{k}/oof_plain_crop.npy'))
        if not f_: print(k, ': output E11 belum ada'); continue
        a, b = np.load(TS / f'out_{k}/oof_plain.npy'), np.load(f_[0]); ok = np.abs(b).sum(1) > 0
        d = np.array([bas(y[fold == g], b[fold == g].argmax(1)) - bas(y[fold == g], a[fold == g].argmax(1)) for g in range(5) if ok[fold == g].all()])
        print(f'{k}: asli {bas(y[ok], a[ok].argmax(1)):.4f} | crop {bas(y[ok], b[ok].argmax(1)):.4f} | delta per fold {np.round(d, 4)} | positif {int((d > 0).sum())}/{len(d)}')

# %% md
# ## 8. Ekspektasi lokal lawan leaderboard
# Semua submission akun `ajikajadeh`, plus pasangan CV-LB publik yang bisa diverifikasi.

# %%
with step('tabel CV lawan LB', 1):
    sub = pd.DataFrame([
        ('57871600', 'S12 FullGroup k18 "0.72431"', 'judul, tidak terukur', None, 'gagal dinilai'),
        ('57872845', 'S12 Apex "0.72431" fixed', 'judul, tidak terukur', None, 'gagal dinilai'),
        ('57873164', 'S12 Apex "0.72431" v2', 'judul, tidak terukur', 0.330, 'pipeline rusak di hidden rerun'),
        ('57874130', 'SOTA Apex tanpa Llama', 'publik 0.659', 0.659, 'sesuai'),
        ('57876141', 'fork One Swap (publik 0.664)', 'publik 0.664', 0.664, 'sesuai, terbaik'),
        ('57889656', 'Gold Apex "0.75+" + Hungarian', '"0.75+" judul, tidak terukur', 0.639, 'Hungarian penuh: -0.025'),
    ], columns=['id', 'isi', 'ekspektasi', 'public LB', 'catatan'])
    display(sub)
    pairs = pd.DataFrame([('LoRA dua tahap publik, CV per prompt', .593, .592), ('nested CV grup 18 penuh', .6865, .56),
                          ('"0.75+" kita (tanpa CV)', .75, .639), ('q8+ll8+svc4 kita, test 70/15/15', .6147, None)], columns=['skema', 'lokal', 'LB'])
    display(pairs)
    print('Kegagalan nomor 1 bukan overfit model: angka 0.75 tidak pernah diukur di prompt held-out, lalu Hungarian di kluster TF-IDF hidden test')
    print('memaksa satu model per kluster. Kluster itu tidak lengkap dan tidak murni, sehingga LB turun dari 0.664 ke 0.639.')
    print('Aturan: hanya CV per prompt dengan trik grup dinilai pada 2-3 passage per prompt yang boleh dipakai memprediksi LB.')

# %% md
# ## 9. Submission terbaik
# Submission terbaik tetap **fork One Swap** (`kernels/sub/ntl-sub-oneswap`, LB 0.664). Kernel GPU T4x2 itu menjalankan
# ensemble LoRA publik + SVC 4-view + ATLAS + twin + Sinkhorn pada hidden test (sekitar 8 jam). Cara mengulang:
#
# ```bash
# kaggle kernels push -p kernels/sub/ntl-sub-oneswap
# kaggle competitions submit name-that-llm -k ajikajadeh/ntl-sub-oneswap -v <versi> -f submission.parquet -m "..."
# ```
#
# Sel di bawah memeriksa kontrak format pada output 3 baris dari kernel tersebut.

# %%
with step('cek format submission', 1):
    s = pd.read_parquet(ROOT / 'kernels/sub/ntl-sub-oneswap/out/submission.parquet'); ss = pd.read_parquet(ROOT / 'data/sample_submission.parquet')
    assert list(s.columns) == list(ss.columns) == ['id', 'model'] and set(s.id) == set(test.id) and s.model.isin(lib.LABELS).all() and s.id.is_unique
    print(s); print('format sah')

# %% md
# ## 10. Kesimpulan
# 1. Validasi per prompt bisa dipercaya (CV 0.593 lawan LB 0.592). Angka tanpa CV per prompt, termasuk "0.75+", tidak.
# 2. Model ensemble publik mentok di 0.664-0.665; fork-of-fork menambah paling banyak 0.001, di bawah derau 0.009.
# 3. Data bergaya host adalah tuas terukur terbesar: +0.075 dari 2.160 baris host di atas 190k pool, kurva belum jenuh.
#    Host mengizinkan data hasil generate sendiri dengan biaya wajar (di bawah nilai hadiah, sekitar $5k).
# 4. Crop menaikkan SVC +0.017 (5/5 rotasi) tetapi menurunkan LoRA tahap 2 sekitar -0.02 (10/10 fold) bila menggantikan epoch kedua.
#    Augmentasi murah tidak menggantikan data host sungguhan untuk model LoRA.
# 5. Selisih ke 0.99 tidak bisa ditutup: puncak LB 0.744 dan model terbaik masih salah di antar versi dalam satu keluarga.
#
# Rencana lanjut dan log kegagalan lengkap ada di `README.md`.

# %%
print(f'total runtime notebook {time.time() - T0:.0f}s')
