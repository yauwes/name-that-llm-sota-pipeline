"""lib.py + cells.py -> ntl_a100.ipynb, or `build.py report_cells.py ntl_report.ipynb`. A cell starts at a line beginning with '# %%' ('# %% md' = markdown)."""
import hashlib, json, re, sys
from pathlib import Path
here = Path(__file__).parent; cells = []
src, dst = (sys.argv[1:3] + ['cells.py', 'ntl_a100.ipynb'][len(sys.argv[1:3]):])
def add(kind, src):
    src = src.strip('\n')
    if not src: return
    cid = hashlib.sha256(f'{len(cells)}:{kind}:{src}'.encode()).hexdigest()[:12]
    c = dict(id=cid, cell_type=kind, metadata={}, source=src.splitlines(True))
    if kind == 'code': c.update(execution_count=None, outputs=[])
    cells.append(c)
parts = re.split(r'^# %%( md)?[^\n]*\n', (here / src).read_text(), flags=re.M)
for md, body in zip(parts[1::2], parts[2::2]):
    if md: add('markdown', re.sub(r'^# ?', '', body, flags=re.M))
    else: add('code', body.replace('__LIB__', (here / 'lib.py').read_text()).replace('__LB_SNAPSHOT__', (here.parent / 'research/lb/snapshot.json').read_text()))
ks = dict(kernelspec=dict(display_name='Python 3', language='python', name='python3'))
nb = dict(cells=cells, metadata=dict(accelerator='GPU', colab=dict(gpuType='A100', machine_shape='hm'), **ks) if src == 'cells.py' else ks, nbformat=4, nbformat_minor=5)
(here / dst).write_text(json.dumps(nb, indent=1, ensure_ascii=False))
print(len(cells), 'cells')
