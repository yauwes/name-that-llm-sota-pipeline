import json,glob,re
f=glob.glob('notebook/out_smoke/*.log')
t=open(f[0]).read()
try: s=''.join(x['data'] for x in json.loads(t))
except Exception: s=t
lines=[l for l in s.splitlines() if re.search(r'^\d\d:\d\d:\d\d|Error|SMOKE|^  File "/kaggle/working',l)]
print('\n'.join(l[:210] for l in lines[-40:]))
