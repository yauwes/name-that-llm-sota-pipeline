"""Sparse linear baseline. usage: tfidf.py name views pool_n pool_w [C] ; views ⊂ word,char,style."""
import sys; from common import *
from scipy.sparse import vstack, hstack
from sklearn.feature_extraction.text import TfidfVectorizer as V
from sklearn.svm import LinearSVC
name, views, pool_n, pool_w = sys.argv[1], sys.argv[2].split(','), int(sys.argv[3]), float(sys.argv[4])
C = float(sys.argv[5]) if len(sys.argv)>5 else .1
t = train(); p = pool(pool_n) if pool_n else None
A = dict(sublinear_tf=True, min_df=3, max_features=400_000, dtype=np.float32, strip_accents=None, lowercase=False)
def mk(v):
    return {'word': (V(analyzer='word', token_pattern=r"\S+", ngram_range=(1,2), **A), None),
            'char': (V(analyzer='char', ngram_range=(2,5), **A), None),
            'style': (V(analyzer='word', token_pattern=r"\S+", ngram_range=(1,4), **A), style_mask),
            'shape': (V(analyzer='char', ngram_range=(2,6), **{**A, 'max_features': 60_000}), lambda s: re.sub(r"[^\W\d_]+", lambda m: 'X' if m[0].isupper() else 'x', s))}[v]
P = np.zeros((len(t),18), np.float32)
for f in range(5):
    tr = t[t.fold!=f]; va = t[t.fold==f]
    ptxt = p.text.tolist() if p is not None else []
    Xtr, Xva = [], []
    for v in views:
        vec, fn = mk(v); g = fn or (lambda s: s)
        A1 = vec.fit_transform([g(s) for s in tr.text.tolist()+ptxt]); A2 = vec.transform([g(s) for s in va.text])
        Xtr.append(A1); Xva.append(A2)
    Xtr, Xva = hstack(Xtr, format='csr'), hstack(Xva, format='csr')
    y = np.r_[tr.y, p.y] if p is not None else tr.y.values
    w = np.r_[np.ones(len(tr)), np.full(len(p), pool_w)] if p is not None else None
    m = LinearSVC(C=C, class_weight='balanced', dual=True, max_iter=2000).fit(Xtr, y, sample_weight=w)
    P[t.fold==f] = m.decision_function(Xva); print(f, bas(va.y, P[t.fold==f].argmax(1)), flush=True)
report(name, P, t, views=sys.argv[2], pool_n=pool_n, pool_w=pool_w, C=C)
