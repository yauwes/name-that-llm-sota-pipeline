"""How much does each pool source agree with a classifier fit on host rows only? low = suspicious labels/route."""
from common import *
from sklearn.feature_extraction.text import TfidfVectorizer as V
from sklearn.svm import LinearSVC
t = train()
p = pd.read_parquet(ROOT/'data/pool/ntl_open_pool.parquet', columns=['text','model','source_dataset','flag_kb_proxy'])
p['y'] = p.model.map(L2I)
p = p.sample(frac=1, random_state=0).groupby(['source_dataset','model']).head(150).reset_index(drop=True)
print(len(p), flush=True)
vec = V(analyzer='char', ngram_range=(2,5), sublinear_tf=True, min_df=3, max_features=400000, lowercase=False, dtype=np.float32)
m = LinearSVC(C=.1, dual=True, max_iter=2000).fit(vec.fit_transform(t.text), t.y)
pred = m.predict(vec.transform(p.text))
p['hit'] = pred==p.y; p['fam_hit'] = FAM[pred]==FAM[p.y]
g = p.groupby('source_dataset').agg(n=('hit','size'), models=('y','nunique'), acc=('hit','mean'), fam=('fam_hit','mean')).sort_values('fam')
g.round(3).to_csv(ROOT/'research/source_rel.csv'); print(g.round(3).to_string())
g2 = p.groupby(['source_dataset','model']).agg(n=('hit','size'), acc=('hit','mean'), fam=('fam_hit','mean')); g2[(g2.n>=50)&(g2.fam<.45)].round(3).to_csv(ROOT/'research/source_model_bad.csv'); print(g2[(g2.n>=50)&(g2.fam<.45)].round(2).to_string())
print('per-model pooled', p.groupby('model').agg(acc=('hit','mean'),fam=('fam_hit','mean')).round(2).to_string())
