import re, numpy as np, pandas as pd
from pathlib import Path
from sklearn.model_selection import GroupKFold
from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS as SW
from sklearn.metrics import balanced_accuracy_score as bas
ROOT = Path(__file__).resolve().parent.parent
LABELS = sorted("""gpt-5.5 gpt-5.6-luna gpt-5.6-sol gpt-5.6-terra gpt-6-astra gemini-3.1-pro-preview gemini-3.6-flash
gemini-3.7-flash gemini-3.8-flash claude-fable-5 claude-opus-4-6 claude-opus-4-8 claude-opus-5 claude-sonnet-5
qwen3.8-max glm-5.3 glm-5.3-flash kimi-k3""".split())
L2I = {m: i for i, m in enumerate(LABELS)}
FAM = np.array([re.split(r'[-.\d]', m)[0] for m in LABELS])

def train():
    t = pd.read_csv(ROOT/'data/train.csv'); t['y'] = t.model.map(L2I)
    # every prompt lands in one fold; fixed so all experiments are comparable
    pr = pd.Series(t.prompt_id.unique()).sample(frac=1, random_state=42).tolist()
    t['fold'] = t.prompt_id.map({p: i % 5 for i, p in enumerate(pr)})
    return t

def pool(n=None, seed=0, drop_flags=True):
    p = pd.read_parquet(ROOT/'data/pool/ntl_open_pool.parquet', columns=['text','model','prompt_group','flag_kb_proxy','flag_gemini37_routing_risk','style_score','n_words'])
    if drop_flags: p = p[~p.flag_gemini37_routing_risk]
    p['y'] = p.model.map(L2I)
    if n:  # class-balanced subsample
        p = p.sample(frac=1, random_state=seed).groupby('y').head(n//18)
    return p.reset_index(drop=True)

def report(name, P, t, **kw):
    """P = OOF scores (N,18). Plain balanced acc, per fold spread, family acc, and per-class recall extremes."""
    pred = P.argmax(1)
    folds = [bas(t.y[t.fold==f], pred[t.fold==f]) for f in range(5)]
    famacc = (FAM[pred]==FAM[t.y]).mean()
    rec = [(pred[t.y==c]==c).mean() for c in range(18)]
    s = dict(name=name, bacc=round(bas(t.y,pred),4), fold_sd=round(np.std(folds),4), fam=round(famacc,3), rec_min=round(min(rec),2), rec_max=round(max(rec),2), **kw)
    print(s, flush=True); np.save(ROOT/f'oof/{name}.npy', P)
    with open(ROOT/'results.jsonl','a') as f: f.write(pd.Series(s).to_json()+'\n')
    return s

_w = re.compile(r"[A-Za-z]+|\d+|[^\sA-Za-z\d]")
def style_mask(s):
    """topic-blind view: keep stopwords and punctuation, reduce content words to shape + suffix."""
    out = []
    for m in _w.findall(s):
        l = m.lower()
        if not m[0].isalpha() or l in SW: out.append(m if not m[0].isalpha() else l)
        else: out.append(('C' if m[0].isupper() else 'w') + str(min(len(m)//3,4)) + '_' + l[-2:])
    return ' '.join(out)
if __name__ == '__main__':
    t = train(); assert t.groupby('prompt_id').fold.nunique().max()==1 and len(LABELS)==18 and t.y.notna().all()
    assert style_mask('The Cat—ran.').split()[0]=='the'; print('ok', t.fold.value_counts().to_dict(), dict(zip(LABELS,FAM)))
