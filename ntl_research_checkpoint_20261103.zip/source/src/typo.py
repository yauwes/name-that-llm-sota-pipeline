"""Local stylometric-feature + LightGBM and typography gating experiments on host rows (OOF, prompt-grouped)."""
from common import *
import lightgbm as lgb
t = train()
MARK = ['—',' — ','–','-',';',':',',','’','‘','“','”','"',"'",'(',')','*','!','?','…','/','%']
FW = "the of and to a in is that it as for with by on be this are not or from at which but its an can have more than their they we our you your i one these has was were when each while such between into because through only also however thus rather even yet both may might would could should must often still".split()
def F(s):
    n = max(len(s.split()),1); ws = re.findall(r"[A-Za-z']+", s); low = [w.lower() for w in ws]; S = [x for x in re.split(r'(?<=[.!?])\s+', s) if x]
    sl = [len(x.split()) for x in S] or [0]; wl = [len(w) for w in ws] or [0]
    d = {f'm{i}': s.count(m)/n for i,m in enumerate(MARK)}
    d.update({f'f{w}': low.count(w)/n for w in FW})
    d.update(n=n, sents=len(S), sl_m=np.mean(sl), sl_s=np.std(sl), sl_max=max(sl), wl_m=np.mean(wl), wl_s=np.std(wl), ttr=len(set(low))/max(len(low),1), cap=sum(w[0].isupper() for w in ws)/max(len(ws),1),
             first_w=hash(low[0])%50 if low else -1, end_q=s.rstrip()[-1] in '"”', notx=len(re.findall(r"\bnot\b[^.]{0,40}\bbut\b", s.lower()))/n, emd_sp=len(re.findall(r'\s—\s', s))/n, emd_ns=len(re.findall(r'\S—\S', s))/n, dig=sum(c.isdigit() for c in s)/n, ly=sum(w.endswith('ly') for w in low)/n, ing=sum(w.endswith('ing') for w in low)/n)
    return d
X = pd.DataFrame([F(s) for s in t.text])
P = np.zeros((len(t),18))
for f in range(5):
    a, b = t.fold!=f, t.fold==f
    m = lgb.LGBMClassifier(n_estimators=400, learning_rate=.03, num_leaves=15, subsample=.8, subsample_freq=1, colsample_bytree=.4, min_child_samples=10, reg_lambda=2, verbose=-1, n_jobs=4).fit(X[a], t.y[a])
    P[b] = m.predict_proba(X[b])
report('lgb_style', P, t)
