"""Snapshot E37 atomic checkpoints while local training may still be active.

Capture internally consistent last/best pairs per phase, deriving history from
last.pt. A snapshot is not a global transaction across independently advancing
phases. Full pretrained backbone and raw passages are not redistributed.
"""
import hashlib
import argparse
import json
import shutil
import tarfile
import tempfile
from pathlib import Path

import torch

ROOT=Path(__file__).resolve().parents[2]
SOURCE=ROOT/'research/experiments/e37_minilm_adapt'
OUT=ROOT/'data/minilm_checkpoint_20261104'


def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(2**20),b''):h.update(b)
    return h.hexdigest()


def run(out=OUT):
    out.mkdir(exist_ok=True);stage=Path(tempfile.mkdtemp(prefix='ntl_minilm_snapshot_'))
    manifest=json.loads((SOURCE/'manifest.json').read_text());signature=manifest['signature'];phases=[];skipped=[]
    def target(path):
        p=stage/path.relative_to(ROOT);p.parent.mkdir(parents=True,exist_ok=True);return p
    for phase in sorted(SOURCE.iterdir()):
        if not phase.is_dir() or not (phase/'last.pt').exists():continue
        ok=False
        for attempt in range(3):
            last=target(phase/'last.pt');shutil.copyfile(phase/'last.pt',last)
            state=torch.load(last,map_location='cpu',weights_only=True);assert state['signature']==signature
            if phase.name.startswith('inner'):
                best=target(phase/'best.pt');shutil.copyfile(phase/'best.pt',best)
                chosen=torch.load(best,map_location='cpu',weights_only=True);assert chosen['signature']==signature
                if chosen['epoch']!=state['chosen']:continue
            ok=True;break
        if not ok:
            skipped.append(phase.name);shutil.rmtree(last.parent);continue
        target(phase/'history.json').write_text(json.dumps(state['history'],indent=2))
        phases.append(dict(phase=phase.name,epoch=state['epoch'],selected_epoch=state['chosen'],internally_consistent=True))
    assert phases,'No completed epoch checkpoint to preserve yet'
    for p in SOURCE.iterdir():
        if p.is_file() and (p.suffix in {'.json','.pt'} or p.name=='training.log'):
            shutil.copyfile(p,target(p))
    code=ROOT/'research/experiments/minilm_adapt.py';assert sha(code)==manifest['code_sha256'];shutil.copyfile(code,target(code))
    files=[]
    for p in sorted(stage.rglob('*')):
        if p.is_file():files.append(dict(path=str(p.relative_to(stage)),bytes=p.stat().st_size,sha256=sha(p)))
    archive=out/'minilm_adapt_checkpoint_20261104.tar.gz'
    with tarfile.open(archive,'w:gz',compresslevel=3) as tar:
        for row in files:tar.add(stage/row['path'],arcname=row['path'],recursive=False)
    with tarfile.open(archive) as tar:
        for row in files:
            data=tar.extractfile(row['path']).read();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
    result=dict(scope='Private in-progress E37 snapshot, no raw text or upstream backbone. Atomic per-phase checkpoint pairs, not a global training transaction.',
        signature=signature,phases=phases,skipped_inconsistent_phases=skipped,
        completed_folds=[int(p.stem.removeprefix('fold')) for p in stage.glob('research/experiments/e37_minilm_adapt/fold*.json')],
        backbone=dict(repository=manifest['plan']['backbone'],revision=manifest['plan']['revision'],files=manifest['model_files']),
        restore='Latest public source plus base numeric v4 and E33/E35 delta if replaying all research. Overlay this E37 snapshot, attach official train.csv, restore the pinned MiniLM backbone under data/models/MiniLM-L6-v2. Confirm prior run terminal before resume.',
        files=files,archive=dict(path=archive.name,bytes=archive.stat().st_size,sha256=sha(archive)))
    result['recorded_full_fivefold_results']=len(result['completed_folds'])==5 and json.loads((SOURCE/'results.json').read_text()).get('folds_complete')==list(range(5))
    if result['recorded_full_fivefold_results']:result['scope']='Private complete five-fold E37 training checkpoint snapshot, no raw text or upstream backbone. Process termination must still be confirmed through its live handle.'
    (out/'artifact_manifest.json').write_text(json.dumps(result,indent=2))
    description='Private resumable local MiniLM source-attribution experiment. Includes epoch optimizer/RNG snapshots and source/manifest. No raw passages or pretrained backbone. Not a measured leaderboard improvement.'
    if result['recorded_full_fivefold_results']:description+=' This snapshot includes all five completed folds; fixed fusion worsened historical CV and was not promoted.'
    (out/'dataset-metadata.json').write_text(json.dumps(dict(title='NTL E37 MiniLM training checkpoints',id='ajikajadeh/ntl-e37-minilm-checkpoints',licenses=[dict(name='other')],description=description),indent=2))
    print('Snapshot',phases,'files',len(files),'MiB',round(archive.stat().st_size/2**20,2),'completed folds',result['completed_folds'],flush=True)
    shutil.rmtree(stage)  # Only this invocation's verified temporary copies.


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=OUT);a=p.parse_args();run(a.output)
