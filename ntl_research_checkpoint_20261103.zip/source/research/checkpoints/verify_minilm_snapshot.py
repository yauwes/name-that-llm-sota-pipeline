"""Check saved inner0 MiniLM inference on CPU versus its recorded MPS validation.

Only the pinned snapshot is read. Does not interrupt or mutate active training.
This is backend/checkpoint parity, not new generalization or CUDA validation.
"""
import hashlib
import io
import json
import sys
import tarfile
import time
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from sklearn.metrics import balanced_accuracy_score,log_loss
from threadpoolctl import threadpool_limits

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'research/experiments'))
import minilm_adapt as experiment


def run():
    start=time.perf_counter();torch.set_num_threads(2)
    folder=ROOT/'data/minilm_checkpoint_20261104';m=json.loads((folder/'artifact_manifest.json').read_text())
    archive=folder/m['archive']['path'];assert experiment.sha(archive)==m['archive']['sha256']
    with tarfile.open(archive) as tar:
        def read(name):
            data=tar.extractfile(name).read();record=next(r for r in m['files'] if r['path']==name)
            assert len(data)==record['bytes'] and hashlib.sha256(data).hexdigest()==record['sha256'];return data
        prefix='research/experiments/e37_minilm_adapt/inner0/'
        saved=torch.load(io.BytesIO(read(prefix+'best.pt')),map_location='cpu',weights_only=True)
        history=json.loads(read(prefix+'history.json'))
    assert saved['signature']==m['signature'];reference=next(r for r in history if r['epoch']==saved['epoch'])
    t=experiment.lib.load_train(ROOT/'data/train.csv');assert sorted(t.model.unique())==experiment.lib.LABELS
    prompts=pd.Series(t.prompt_id.unique()).sample(frac=1,random_state=42).tolist()
    assignment=t.prompt_id.map({p:i%5 for i,p in enumerate(prompts)}).to_numpy();tr=np.flatnonzero(assignment!=0)
    tp=np.array([p for p in prompts if p in set(t.prompt_id.to_numpy()[tr])]);va=tr[np.isin(t.prompt_id.to_numpy()[tr],tp[::5])]
    tok=experiment.AutoTokenizer.from_pretrained(experiment.MODEL,local_files_only=True,trust_remote_code=False)
    token=tok(t.text.tolist(),max_length=experiment.PLAN['max_tokens'],truncation=True)
    model=experiment.SourceModel('cpu',20263700);model.load_delta(saved['model'])
    score=experiment.predict(model,tok,token,va,'cpu');p=torch.softmax(torch.from_numpy(score),1).numpy()
    ba=float(balanced_accuracy_score(t.y.to_numpy()[va],score.argmax(1)));ce=float(log_loss(t.y.to_numpy()[va],p,labels=np.arange(18)))
    assert abs(ba-reference['val_ba'])<=1/len(va)+1e-12,'CPU/MPS validation recall parity failed'
    assert abs(ce-reference['val_logloss'])<=.005,'CPU/MPS validation logloss parity failed'
    result=dict(snapshot_archive_sha256=m['archive']['sha256'],epoch=saved['epoch'],rows=len(va),
        mps_reference_ba=reference['val_ba'],cpu_ba=ba,mps_reference_logloss=reference['val_logloss'],cpu_logloss=ce,
        ba_delta=ba-reference['val_ba'],logloss_delta=ce-reference['val_logloss'],passed=True,
        elapsed_s=time.perf_counter()-start,labels=experiment.lib.LABELS,code_sha256=experiment.sha(Path(__file__)),
        scope='Pinned inner0 checkpoint reloaded on CPU and validation metrics compared with recorded MPS values. No retraining, full5fold, CUDA, hidden inference or new leaderboard evidence.')
    (ROOT/'research/live/20261104/e37_cpu_snapshot_parity.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))


if __name__=='__main__':
    with threadpool_limits(limits=2):run()
