"""Preserve derived arrays, trained heads and FULL fold-cache JSON privately.

Public source snapshots strip row predictions. Restore the public source FIRST,
then overlay this private archive, then attach official train.csv. This archive
also includes legacy numeric caches so research replay does not depend on an
unrecorded local out_full directory. No upstream backbone weights or raw text.
"""
import hashlib
import json
import re
import subprocess
import tarfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'data/reader_checkpoint_20261103'
SECRET=re.compile(rb'KGAT_[A-Za-z0-9]{20,}|hf_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{25,}|ghp_[A-Za-z0-9]{20,}')


def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(2**20),b''):h.update(b)
    return h.hexdigest()


def run():
    OUT.mkdir(exist_ok=True)
    inventory=OUT/'artifact_manifest.json'
    files={r['path'] for r in json.loads(inventory.read_text())['files']} if inventory.exists() else set()
    # rg includes ignored out directories deliberately; only numeric file types.
    found=subprocess.run(['rg','--files','--hidden','--no-ignore','-g','*.npy','-g','*.npz','-g','*.joblib','kernels','oof'],
        cwd=ROOT,capture_output=True,text=True,check=True).stdout.splitlines()
    files.update(found)
    for p in (ROOT/'data/features').glob('*/*'):
        if p.is_file() and p.suffix in {'.npy','.json'}:files.add(str(p.relative_to(ROOT)))
    for directory in (ROOT/'research/experiments').glob('e*'):
        if directory.is_dir():
            files.update(str(p.relative_to(ROOT)) for p in directory.glob('*') if p.is_file() and p.suffix in {'.json','.joblib','.npy','.npz'})
    records=[]
    for name in sorted(files):
        p=ROOT/name
        assert p.is_file() and p.suffix in {'.npy','.npz','.joblib','.json'},name
        assert name.startswith(('data/features/','research/experiments/','kernels/','oof/')),name
        assert '..' not in Path(name).parts
        if p.suffix=='.json':
            data=p.read_bytes();assert not SECRET.search(data),name
            # Full predictions/configs are intended; raw passage fields are not.
            def check(value):
                if isinstance(value,dict):
                    for k,v in value.items():
                        assert not (k in {'text','raw_text','passage'} and isinstance(v,str) and len(v)>60),name
                        check(v)
                elif isinstance(value,list):
                    for v in value:check(v)
            check(json.loads(data))
        records.append(dict(path=name,bytes=p.stat().st_size,sha256=sha(p)))
    archive=OUT/'reader_features_heads_20261103.tar.gz'
    with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
        for row in records:tar.add(ROOT/row['path'],arcname=row['path'],recursive=False)
    with tarfile.open(archive) as tar:
        assert len(tar.getmembers())==len(records)
        for row in records:
            f=tar.extractfile(row['path']);h=hashlib.sha256();n=0
            for b in iter(lambda:f.read(2**20),b''):h.update(b);n+=len(b)
            assert n==row['bytes'] and h.hexdigest()==row['sha256'],row['path']
    result=dict(scope='Private derived numeric caches, trained head files and full fold JSON, including partial pilot bitmaps. No raw competition passages, credentials or upstream backbone weights.',
        restore_order='Extract public source, overlay this private archive, attach official train.csv. Public fold JSON alone cannot resume training.',
        remote_expected_prefix='reader_features_heads_20261103/',
        checkpoint_files=sum(r['path'].endswith('.joblib') for r in records),
        files=records,archive=dict(path=archive.name,bytes=archive.stat().st_size,sha256=sha(archive)))
    inventory.write_text(json.dumps(result,indent=2))
    print('Private checkpoint',len(records),'files;',result['checkpoint_files'],'joblib files;',round(archive.stat().st_size/2**20,2),'MiB; every tar entry SHA256 verified.',flush=True)


if __name__=='__main__':run()
