"""Download a private Kaggle snapshot and verify every manifest member.

Credentials are supplied through the environment, never through arguments.
Kaggle extracts uploaded tar archives, so match their manifest paths by suffix.
"""
import argparse
import hashlib
import json
import time
import zipfile
from pathlib import Path

from kaggle.api.kaggle_api_extended import KaggleApi, ApiGetDatasetRequest


def run():
    p = argparse.ArgumentParser()
    p.add_argument('dataset')
    p.add_argument('local_folder', type=Path)
    p.add_argument('report', type=Path)
    p.add_argument('--individual', action='store_true', help='Use per-file downloads when the whole-dataset zip endpoint is unavailable')
    a = p.parse_args()
    started = time.monotonic()
    raw = (a.local_folder / 'artifact_manifest.json').read_bytes()
    manifest = json.loads(raw)
    api = KaggleApi(); api.authenticate()
    owner, slug = a.dataset.split('/')
    req = ApiGetDatasetRequest(); req.owner_slug = owner; req.dataset_slug = slug
    with api.build_kaggle_client() as client:
        metadata = client.datasets.dataset_api_client.get_dataset(req)
    assert metadata.is_private is True, 'Snapshot is not private'
    pinned = f'{a.dataset}/{metadata.current_version_number}'
    inventory = {}; token = None
    while True:
        page = api.dataset_list_files(pinned, page_size=200, page_token=token)
        for f in page.files:
            assert f.name not in inventory
            inventory[f.name] = f.total_bytes
        token = page.next_page_token
        if not token: break
    destination = a.local_folder.parent / (a.local_folder.name + '_remote_roundtrip')
    destination.mkdir(exist_ok=True)
    def member(path):
        names = [n for n in inventory if n == path or n.endswith('/' + path)]
        assert len(names) == 1, (path, names)
        return names[0]
    if a.individual:
        def read(path):
            name = member(path); folder = destination / 'individual' / Path(path).parent
            folder.mkdir(parents=True, exist_ok=True)
            api.dataset_download_file(pinned, name, path=str(folder), force=True, quiet=True, unzip=True)
            matches = [f for f in folder.rglob(Path(path).name) if f.is_file()]
            assert len(matches) == 1, (path, matches)
            return matches[0].read_bytes()
        assert read('artifact_manifest.json') == raw
        for row in manifest['files']:
            data = read(row['path'])
            assert len(data) == row['bytes'] == inventory[member(row['path'])]
            assert hashlib.sha256(data).hexdigest() == row['sha256'], row['path']
            print('Verified', row['path'], flush=True)
    else:
        api.dataset_download_files(pinned, path=str(destination), force=True, quiet=True, unzip=False)
        archive = destination / (slug + '.zip')
        with zipfile.ZipFile(archive) as z:
            assert z.read(member('artifact_manifest.json')) == raw
            for row in manifest['files']:
                name = member(row['path']); data = z.read(name)
                assert len(data) == row['bytes'] == inventory[name], name
                assert hashlib.sha256(data).hexdigest() == row['sha256'], name
    result = dict(dataset=a.dataset, version=metadata.current_version_number,
        is_private=True, all_remote_bytes_sha256_verified=len(manifest['files']),
        manifest_byte_identical=True, archive=manifest['archive'], download_mode='individual' if a.individual else 'whole_dataset_zip',
        elapsed_s=time.monotonic()-started,
        scope='All manifest members downloaded and SHA-256 verified; not evidence of model quality, CUDA execution or leaderboard improvement.')
    a.report.parent.mkdir(parents=True, exist_ok=True)
    a.report.write_text(json.dumps(result, indent=2))
    print(json.dumps(result, indent=2), flush=True)


if __name__ == '__main__': run()
