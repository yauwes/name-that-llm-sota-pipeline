"""Replay all2699 heldout predictions from the five final E37 adapters.

Run after the training handle is terminal, to avoid competing for local Metal.
No optimizer step, no new predictions on hidden competition rows.
"""
import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from threadpoolctl import threadpool_limits
from transformers import AutoTokenizer

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'research/experiments'))
import minilm_adapt as experiment
import lib
from verify_score_heads import resolve


def run():
    p=argparse.ArgumentParser();p.add_argument('--snapshot-root',type=Path,default=ROOT)
    p.add_argument('--device',choices=['cpu','mps'],default='cpu');p.add_argument('--report',type=Path,required=True);a=p.parse_args()
    start=time.perf_counter();torch.set_num_threads(2)
    if a.device=='mps':
        assert torch.backends.mps.is_available();torch.mps.set_per_process_memory_fraction(.45)
    directory='research/experiments/e37_minilm_adapt'
    manifest=json.loads(resolve(a.snapshot_root,directory+'/manifest.json').read_text())
    assert experiment.sha(ROOT/'research/experiments/minilm_adapt.py')==manifest['code_sha256']
    assert experiment.sha(ROOT/'data/train.csv')==manifest['train_sha256']
    for name,expected in manifest['model_files'].items():assert experiment.sha(experiment.MODEL/name)==expected
    t=lib.load_train(ROOT/'data/train.csv');groups=t.prompt_id.to_numpy();y=t.y.to_numpy()
    prompts=pd.Series(t.prompt_id.unique()).sample(frac=1,random_state=42).tolist()
    fold=t.prompt_id.map({p:i%5 for i,p in enumerate(prompts)}).to_numpy()
    tok=AutoTokenizer.from_pretrained(experiment.MODEL,local_files_only=True,trust_remote_code=False)
    lengths=np.array(tok(t.text.tolist(),truncation=False,return_length=True)['length'])
    token_contract=dict(rows=len(lengths),minimum=int(lengths.min()),median=float(np.median(lengths)),
        maximum=int(lengths.max()),cap=experiment.PLAN['max_tokens'],rows_exceeding_cap=int((lengths>experiment.PLAN['max_tokens']).sum()))
    token=tok(t.text.tolist(),max_length=experiment.PLAN['max_tokens'],truncation=True)
    paths=[ROOT/f'kernels/twostage/out_full/out_{tag}/oof_plain.npy' for tag in ['q8','ll8']]
    for tag,path in zip(['q8','ll8'],paths):assert experiment.sha(path)==manifest['legacy_logits_sha256'][tag]
    q,l=[np.load(path) for path in paths];base=lib.N((lib.N(q)+lib.N(l))/2);records=[]
    for f in range(5):
        r=json.loads(resolve(a.snapshot_root,directory+f'/fold{f}.json').read_text());ix=np.flatnonzero(fold==f)
        assert r['test_indices']==ix.tolist() and r['signature']==manifest['signature']
        state=torch.load(resolve(a.snapshot_root,directory+f'/adapter_fold{f}.pt'),map_location='cpu',weights_only=True)
        assert state['signature']==manifest['signature'] and state['labels']==lib.LABELS
        assert state['training_indices']==np.flatnonzero(fold!=f).tolist()
        assert state['selected_epochs']==r['inner_validation']['chosen_epoch']
        model=experiment.SourceModel(a.device,20263700+f);model.load_delta(state['model'])
        score=experiment.predict(model,tok,token,ix,a.device)
        pred=dict(baseline=base[ix].argmax(1),adapted=score.argmax(1),fusion=(base[ix]+experiment.PLAN['alpha']*lib.N(score)).argmax(1))
        for key,value in pred.items():assert np.array_equal(value,r['prediction'][key]),(f,key)
        records.append(dict(fold=f,rows=len(ix),all_predictions_identical=True,checkpoint_sha256=experiment.sha(resolve(a.snapshot_root,directory+f'/adapter_fold{f}.pt'))))
        del model,state
        if a.device=='mps':torch.mps.empty_cache()
        elapsed=time.perf_counter()-start;print('Verified fold',f,'rows',len(ix),'elapsed_s',round(elapsed,2),'ETA_s',round(elapsed/(f+1)*(4-f),2),flush=True)
    report=dict(signature=manifest['signature'],folds=records,total_rows=sum(r['rows'] for r in records),device=a.device,token_contract=token_contract,elapsed_s=time.perf_counter()-start,
        snapshot_root=str(a.snapshot_root),scope='Actual full heldout adapter inference reproduces stored predictions. Not an independent training rerun, hidden-test estimate, convergence proof or CUDA-serving validation.')
    assert report['total_rows']==2699
    a.report.write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2),flush=True)


if __name__=='__main__':
    with threadpool_limits(limits=2):run()
