"""Preserve external prompt/hash metadata for raw-text-free E33 audit replay."""
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[2]


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def run():
    raw=ROOT/'data/ext/reader_agent500/audited.parquet';r=pd.read_parquet(raw)
    hashes=[hashlib.sha256(s.encode()).hexdigest() for s in r.text]
    folder=ROOT/'data/features/e33_large_context'
    for kind in ['semantic','dc16']:
        assert np.load(folder/kind/'done.npy').all()
        assert np.array_equal(np.load(folder/kind/'text_sha256.npy'),hashes)
        assert json.loads((folder/kind/'manifest.json').read_text())['data_sha256']==sha(raw)
    result=dict(data_sha256=sha(raw),code_sha256=sha(Path(__file__)),rows=len(r),
        prompt_hash=r.prompt_hash.astype(str).tolist(),text_sha256=hashes,
        scope='Hash identifiers only; no raw prompt/passage or source model labels. Prompt identity is for diagnostic edge metrics, not grouping or classification.')
    (folder/'context_index.json').write_text(json.dumps(result,indent=2))
    print('Preserved',len(r),'external context hash records without raw text or source labels.')


if __name__=='__main__':run()
