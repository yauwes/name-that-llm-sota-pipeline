"""Small private E33/E35 delta; explicitly depends on the immutable v4 base.

Does not re-upload the718MiB base archive. All tar members are verified locally.
Raw external/competition paragraphs and upstream backbone weights are excluded.
"""
import hashlib
import json
import re
import tarfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'data/context_identity_checkpoint_20261104'
SECRET=re.compile(rb'KGAT_[A-Za-z0-9]{20,}|hf_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{25,}|ghp_[A-Za-z0-9]{20,}')


def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(2**20),b''):h.update(b)
    return h.hexdigest()


def run():
    OUT.mkdir(exist_ok=True)
    for name in ['e33_large_context','e34_pairwise_identity','e35_mixed_context']:
        result=json.loads((ROOT/'research/experiments'/name/'results.json').read_text())
        assert result.get('complete',True) and not result['submission_eligible']
        assert all((ROOT/'research/experiments'/name/f'fold{f}.json').exists() for f in range(5))
    files=[]
    for folder in [ROOT/'data/features/e33_large_context',ROOT/'research/experiments/e33_large_context',ROOT/'research/experiments/e34_pairwise_identity',ROOT/'research/experiments/e35_mixed_context']:
        files.extend(p for p in folder.rglob('*') if p.is_file() and p.suffix in {'.npy','.json','.joblib'})
    records=[]
    for p in sorted(files):
        if p.suffix=='.json':assert not SECRET.search(p.read_bytes())
        records.append(dict(path=str(p.relative_to(ROOT)),bytes=p.stat().st_size,sha256=sha(p)))
    archive=OUT/'context_identity_features_heads_20261104.tar.gz'
    with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
        for row in records:tar.add(ROOT/row['path'],arcname=row['path'],recursive=False)
    with tarfile.open(archive) as tar:
        assert len(tar.getmembers())==len(records)
        for row in records:
            data=tar.extractfile(row['path']).read();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
    base=json.loads((ROOT/'data/reader_checkpoint_20261103/artifact_manifest.json').read_text())
    manifest=dict(scope='Private E33/E35 derived-feature and full-fold/head delta. No raw text, credentials or upstream backbone weights.',
        base_dependency=dict(dataset='ajikajadeh/ntl-reader-e19-e22-checkpoint',version=4,archive_sha256=base['archive']['sha256']),
        restore_order='Latest public source, base numeric v4, this delta, official train.csv. External hash-only prompt index allows audit replay without redistributing raw external passages.',
        external_data_sha256=json.loads((ROOT/'research/experiments/e33_large_context/audit_manifest.json').read_text())['data_sha256'],
        files=records,archive=dict(path=archive.name,bytes=archive.stat().st_size,sha256=sha(archive)))
    (OUT/'artifact_manifest.json').write_text(json.dumps(manifest,indent=2))
    (OUT/'dataset-metadata.json').write_text(json.dumps(dict(title='NTL E33 E35 research checkpoint',id='ajikajadeh/ntl-e33-e35-research-checkpoint',
        licenses=[dict(name='other')],description='Private derived E33/E35 large-context stress and E34 source-verifier checkpoints. Depends on ntl-reader-e19-e22-checkpoint version4. No new competition submission; official best0.665.'),indent=2))
    print('Verified',len(records),'private delta members;',round(archive.stat().st_size/2**20,2),'MiB; SHA256',manifest['archive']['sha256'])


if __name__=='__main__':run()
