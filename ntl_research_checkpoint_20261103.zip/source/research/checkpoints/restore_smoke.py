"""Restore public source + private full caches into a clean directory and replay.

This verifies six cached CPU research pipelines, not independent retraining,
CUDA inference, leaderboard quality or a raw-data-free competition submission.
Official train.csv is attached read-only from the authorized local dataset.
"""
import hashlib
import json
import subprocess
import tarfile
import tempfile
import time
import zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
PRIVATE=ROOT/'data/reader_checkpoint_20261103'
PUBLIC=ROOT/'research/checkpoints/20261103_final'
JOBS=[('nested_hybrid_style.py','e27_nested_hybrid_style'),
      ('distilgpt2_predictability.py --evaluate','e28_predictability_distilgpt2'),
      ('partial_group_audit.py','e29_partial_group_audit'),
      ('semantic_group_audit.py','e30_semantic_groups'),
      ('group_fusion_confirm.py','e31_group_fusion_confirm'),
      ('group_eligibility_audit.py','e32_group_eligibility')]


def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(2**20),b''):h.update(b)
    return h.hexdigest()


def without_runtime(value):
    if isinstance(value,dict):return {k:without_runtime(v) for k,v in value.items() if k not in {'elapsed_s'}}
    if isinstance(value,list):return [without_runtime(v) for v in value]
    return value


def run():
    start=time.perf_counter();temp=Path(tempfile.mkdtemp(prefix='ntl_restore_20261104_'));project=temp/'source'
    public_manifest=json.loads((PUBLIC/'checkpoint_manifest_20261103.json').read_text())
    archive=PUBLIC/public_manifest['archive']['path'];assert sha(archive)==public_manifest['archive']['sha256']
    with zipfile.ZipFile(archive) as z:
        for row in public_manifest['files']:
            target=temp/row['path'];assert target.resolve().is_relative_to(temp.resolve())
            data=z.read(row['path']);assert hashlib.sha256(data).hexdigest()==row['sha256']
            target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
    private_manifest=json.loads((PRIVATE/'artifact_manifest.json').read_text());expected={r['path']:r for r in private_manifest['files']}
    archive=PRIVATE/private_manifest['archive']['path'];assert sha(archive)==private_manifest['archive']['sha256']
    restored=set()
    with tarfile.open(archive,'r|gz') as tar:
        for member in tar:
            assert member.isfile() and member.name in expected
            target=project/member.name;assert target.resolve().is_relative_to(project.resolve())
            target.parent.mkdir(parents=True,exist_ok=True);h=hashlib.sha256();count=0
            with tar.extractfile(member) as src,target.open('wb') as dst:
                for b in iter(lambda:src.read(2**20),b''):dst.write(b);h.update(b);count+=len(b)
            row=expected[member.name];assert count==row['bytes'] and h.hexdigest()==row['sha256']
            restored.add(member.name)
    assert restored==set(expected)
    (project/'data/train.csv').symlink_to(ROOT/'data/train.csv')
    interpreter=ROOT/'.venv/bin/python';records=[]
    logs=ROOT/'research/live/20261103/restore_logs';logs.mkdir(exist_ok=True)
    for command,name in JOBS:
        for f in range(5):
            fold=json.loads((project/'research/experiments'/name/f'fold{f}.json').read_text())
            assert 'prediction' in fold and 'test_indices' in fold,'Private fold overlay missing'
        before=json.loads((project/'research/experiments'/name/'results.json').read_text())
        started=time.perf_counter();args=command.split()
        r=subprocess.run([str(interpreter),str(project/'research/experiments'/args[0]),*args[1:]],cwd=project,
            capture_output=True,text=True,timeout=180)
        (logs/(name+'.txt')).write_text(r.stdout+r.stderr)
        assert r.returncode==0,(name,r.stderr[-1500:])
        after=json.loads((project/'research/experiments'/name/'results.json').read_text())
        assert without_runtime(before)==without_runtime(after),(name,'Cached replay metrics changed')
        records.append(dict(experiment=name,returncode=r.returncode,metrics_match=True,
            elapsed_s=time.perf_counter()-started,code_sha256=sha(project/'research/experiments'/args[0])))
        print(name,'restored cached replay OK',round(records[-1]['elapsed_s'],2),'s',flush=True)
    code={str(p.relative_to(project)):sha(p) for p in project.rglob('*.py')}
    report=dict(restored_directory=str(project),private_files_verified=len(restored),
        private_archive_sha256=private_manifest['archive']['sha256'],raw_train_attached_as_read_only_symlink=True,
        jobs=records,verified_code_sha256=code,elapsed_s=time.perf_counter()-start,
        scope='Clean restore + cached CPU replay of six research scripts. Exact code hashes recorded; documentation may be updated after storage verification. Not independent training, CUDA/hidden inference or leaderboard validation.')
    (ROOT/'research/live/20261103/restore_verification_20261104.json').write_text(json.dumps(report,indent=2))
    print('Restore verification complete:',len(records),'scripts;',len(restored),'private files;',round(report['elapsed_s'],2),'seconds')


if __name__=='__main__':run()
