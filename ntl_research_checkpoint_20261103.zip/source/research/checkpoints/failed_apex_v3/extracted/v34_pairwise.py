#!/usr/bin/env python3
"""V34.1: lightweight evidence-aware pairwise identity verifier on top of V31.
No backbone is fine-tuned. Uses official labels, Revision03 A evidence spans and B prompt weak labels.
"""
import argparse, json, hashlib, time, os
from pathlib import Path
import numpy as np
import pandas as pd
from scipy import sparse
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.svm import LinearSVC
from sklearn.model_selection import GroupKFold
from sklearn.preprocessing import normalize
from scipy.special import softmax

LABELS = ['claude-fable-5','claude-opus-4-6','claude-opus-4-8','claude-opus-5','claude-sonnet-5',
 'gemini-3.1-pro-preview','gemini-3.6-flash','gemini-3.7-flash','gemini-3.8-flash','glm-5.3','glm-5.3-flash',
 'gpt-5.5','gpt-5.6-luna','gpt-5.6-sol','gpt-5.6-terra','gpt-6-astra','kimi-k3','qwen3.8-max']
B_COLS=['primary_task','coarse_domain','structure_family','structure_explicitness']

def sha256(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1<<20),b''): h.update(b)
 return h.hexdigest()

def main():
 ap=argparse.ArgumentParser()
 ap.add_argument('--data',required=True); ap.add_argument('--ab-root',required=True); ap.add_argument('--out',required=True); ap.add_argument('--audit',required=True)
 ap.add_argument('--pairs-per-kind',type=int,default=18000); ap.add_argument('--refs-per-class',type=int,default=6); ap.add_argument('--seed',type=int,default=20261101)
 a=ap.parse_args(); t0=time.time(); rng=np.random.default_rng(a.seed)
 data=Path(a.data); root=Path(a.ab_root)
 req=['data_manifest.json','inputs/train.csv','dataset_A_surface_observations.csv','dataset_A_semantic_fingerprint_candidates.csv','dataset_A_cue_spans.csv','dataset_B_prompt_structure.csv']
 missing=[x for x in req if not (root/x).is_file()]
 if missing: raise FileNotFoundError(f'V34 A/B required files missing: {missing}')
 manifest=json.loads((root/'data_manifest.json').read_text(encoding='utf-8'))
 if str(manifest.get('revision'))!='03': raise RuntimeError(f'Expected A/B Revision03, got {manifest.get("revision")}')
 tr=pd.read_csv(data/'train.csv').fillna({'text':''}); te=pd.read_csv(data/'test.csv').fillna({'text':''})
 canon=pd.read_csv(root/'inputs/train.csv').fillna({'text':''})
 if len(canon)!=len(tr) or not canon['id'].astype(str).equals(tr['id'].astype(str)):
  raise RuntimeError('A/B canonical train IDs/order do not match competition train.csv')
 if not canon['text'].astype(str).equals(tr['text'].astype(str)) or not canon['model'].astype(str).equals(tr['model'].astype(str)):
  raise RuntimeError('A/B canonical train text/model mismatch')
 if set(tr.model.unique())!=set(LABELS): raise RuntimeError('Official labels differ from frozen 18-label list')
 n=len(tr); y=pd.Categorical(tr.model,categories=LABELS).codes; groups=tr.prompt_id.astype(str).to_numpy(); texts=tr.text.astype(str).tolist(); test_texts=te.text.astype(str).tolist()
 # A evidence: exact evidence spans only. Build official-row profiles with Prompt-Grouped OOF
 # prototypes so a response's own annotation (and its Prompt group) cannot create its profile.
 surf=pd.read_csv(root/'dataset_A_surface_observations.csv',low_memory=False)
 sem=pd.read_csv(root/'dataset_A_semantic_fingerprint_candidates.csv',low_memory=False)
 cues=pd.concat([surf,sem],ignore_index=True)
 cues=cues.dropna(subset=['cue_id','feature_name_normalized','feature_family'])
 cues['feature_key']=cues['observation_layer'].astype(str)+'|'+cues['feature_family'].astype(str)+'|'+cues['feature_name_normalized'].astype(str)
 spans=pd.read_csv(root/'dataset_A_cue_spans.csv',low_memory=False)
 spans=spans[spans['quote_validation'].astype(str).eq('exact_match')].copy()
 spans=spans.merge(cues[['cue_id','feature_key','prompt_id','observation_confidence']],on='cue_id',how='inner')
 spans=spans[spans['exact_quote'].fillna('').astype(str).str.len().between(5,240)]
 spans=spans.drop_duplicates(['id','feature_key','exact_quote']).reset_index(drop=True)
 if len(spans)==0: raise RuntimeError('No exact A evidence spans survived validation.')
 # Fixed feature-key coordinate system; per-fold prototype support is calculated using train groups only.
 global_support=spans.groupby('feature_key')['id'].nunique()
 keys=sorted(global_support[global_support>=8].index.tolist())
 if len(keys)<20: raise RuntimeError(f'Too few A evidence prototypes after support filter: {len(keys)}')
 key_to_i={k:i for i,k in enumerate(keys)}
 qvec=TfidfVectorizer(analyzer='char_wb',ngram_range=(3,5),min_df=2,max_features=90000,sublinear_tf=True,dtype=np.float32)
 qvec.fit(spans.exact_quote.astype(str).tolist()+texts+test_texts)
 qX=normalize(qvec.transform(spans.exact_quote.astype(str).tolist()),norm='l2')
 textX=normalize(qvec.transform(texts+test_texts),norm='l2')
 spans['_row']=np.arange(len(spans),dtype=np.int32)
 A_tr=np.zeros((n,len(keys)),dtype=np.float32)
 A_te=np.zeros((len(te),len(keys)),dtype=np.float32)
 a_fold_audit=[]
 for fold,(it,iv) in enumerate(GroupKFold(n_splits=5).split(np.zeros(n),y,groups)):
  allowed_ids=set(tr.iloc[it]['id'].astype(str))
  fs=spans[spans['id'].astype(str).isin(allowed_ids)]
  proto_map={}
  for k,g in fs.groupby('feature_key',sort=False):
   if k not in key_to_i or g['id'].astype(str).nunique()<6: continue
   pv=qX[g['_row'].to_numpy()].mean(axis=0)
   pv=sparse.csr_matrix(np.asarray(pv).reshape(1,-1),dtype=np.float32)
   proto_map[k]=normalize(pv,norm='l2')
  if proto_map:
   proto=sparse.vstack([proto_map.get(k,sparse.csr_matrix((1,qX.shape[1]),dtype=np.float32)) for k in keys],format='csr')
   A_tr[iv]=(textX[iv] @ proto.T).toarray().astype(np.float32)
  a_fold_audit.append({'fold':fold,'train_rows':int(len(it)),'valid_rows':int(len(iv)),'prototype_keys':int(len(proto_map)),'heldout_prompt_groups':int(pd.Series(groups[iv]).nunique())})
 # Test profiles use all official training evidence, never external/test annotations.
 full_map={}
 for k,g in spans.groupby('feature_key',sort=False):
  if k not in key_to_i or g['id'].astype(str).nunique()<8: continue
  pv=qX[g['_row'].to_numpy()].mean(axis=0)
  pv=sparse.csr_matrix(np.asarray(pv).reshape(1,-1),dtype=np.float32)
  full_map[k]=normalize(pv,norm='l2')
 if full_map:
  proto_full=sparse.vstack([full_map.get(k,sparse.csr_matrix((1,qX.shape[1]),dtype=np.float32)) for k in keys],format='csr')
  A_te=(textX[n:] @ proto_full.T).toarray().astype(np.float32)
 A_tr=np.clip(A_tr,0,1); A_te=np.clip(A_te,0,1)
 a_prof=np.vstack([A_tr,A_te]).astype(np.float32)
# B: weak prompt-level attributes; infer from answer text using prompt-grouped OOF classifiers.
 bdf=pd.read_csv(root/'dataset_B_prompt_structure.csv',low_memory=False)
 bdf=bdf.drop_duplicates('prompt_id').set_index('prompt_id')
 for c in B_COLS:
  if c not in bdf: raise RuntimeError(f'B target missing: {c}')
 b_targets=[]
 for p in groups:
  if p not in bdf.index: raise RuntimeError(f'No B weak label for official prompt {p}')
  b_targets.append([str(bdf.loc[p,c]) if pd.notna(bdf.loc[p,c]) else '__UNK__' for c in B_COLS])
 b_targets=np.asarray(b_targets,dtype=object)
 # One shared word/char representation; OOF predictions keep each prompt group out of its own B learner.
 bv=TfidfVectorizer(ngram_range=(1,2),min_df=2,max_features=85000,sublinear_tf=True,dtype=np.float32,strip_accents='unicode')
 BX=bv.fit_transform(texts+test_texts); BXtr,BXte=BX[:n],BX[n:]
 b_oof=np.empty((n,len(B_COLS)),dtype=object); b_test=np.empty((len(te),len(B_COLS)),dtype=object)
 gkf=GroupKFold(n_splits=5)
 for j,c in enumerate(B_COLS):
  target=b_targets[:,j]
  for it,iv in gkf.split(BXtr,target,groups):
   clf=LinearSVC(C=0.5,max_iter=3000,class_weight='balanced',random_state=20261101)
   clf.fit(BXtr[it],target[it]); b_oof[iv,j]=clf.predict(BXtr[iv])
  clf=LinearSVC(C=0.5,max_iter=3000,class_weight='balanced',random_state=20261101)
  clf.fit(BXtr,target); b_test[:,j]=clf.predict(BXte)
 # Text similarity spaces for pair features.
 cv=TfidfVectorizer(analyzer='char',ngram_range=(3,5),min_df=2,max_features=120000,sublinear_tf=True,dtype=np.float32)
 wv=TfidfVectorizer(ngram_range=(1,2),min_df=2,max_features=80000,sublinear_tf=True,dtype=np.float32,strip_accents='unicode')
 C=normalize(cv.fit_transform(texts+test_texts),norm='l2'); W=normalize(wv.fit_transform(texts+test_texts),norm='l2')
 Ctr,Cte=C[:n],C[n:]; Wtr,Wte=W[:n],W[n:]
 # Pair feature builder: symmetric, task/domain-aware, and A evidence-aware.
 fam=np.array([('claude' if x.startswith('claude') else 'gpt' if x.startswith('gpt') else 'gemini' if x.startswith('gemini') else 'glm' if x.startswith('glm') else x) for x in tr.model])
 lengths=np.array([max(1,len(x.split())) for x in texts],dtype=np.float32)
 punct=np.array([[x.count(z) for z in ['.',',',';',':','!','?','—','"',"'",'(',')']] for x in texts],dtype=np.float32)
 punct=punct/(punct.sum(1,keepdims=True)+1)
 def feats(i,j, bj1,bj2, samefam):
  cs=np.asarray(Ctr[i].multiply(Ctr[j]).sum(axis=1)).ravel() if len(i) and (j.max()<n) else np.asarray(C[i].multiply(C[j]).sum(axis=1)).ravel()
  ws=np.asarray(W[i].multiply(W[j]).sum(axis=1)).ravel()
  ap=np.sum(A_tr[i]*A_tr[j],axis=1)/(np.linalg.norm(A_tr[i],axis=1)*np.linalg.norm(A_tr[j],axis=1)+1e-6) if (i.max()<n and j.max()<n) else np.sum(a_prof[i]*a_prof[j],axis=1)/(np.linalg.norm(a_prof[i],axis=1)*np.linalg.norm(a_prof[j],axis=1)+1e-6)
  ad=np.mean(np.abs(a_prof[i]-a_prof[j]),axis=1)
  eq=(bj1==bj2).astype(np.float32)
  lr=np.minimum(lengths[i],lengths[j])/(np.maximum(lengths[i],lengths[j])+1e-6)
  ps=1.0-np.minimum(1.0,np.abs(punct[i]-punct[j]).sum(1)*0.5)
  return np.column_stack([cs,ws,ap,ad,eq[:,0],eq[:,1],eq[:,2],eq[:,3],lr,ps]).astype(np.float32)
 # Balanced, deterministic pair construction. Positive pairs always cross Prompt; hard negatives include same Prompt and same family.
 idx_by_model={k:np.where(y==k)[0] for k in range(len(LABELS))}
 pos_i=[];pos_j=[]; neg_i=[];neg_j=[]; neg_f=[]
 P=a.pairs_per_kind
 for k,idx in idx_by_model.items():
  for _ in range(P//len(LABELS)+1):
   ii,jj=rng.choice(idx,2,replace=False)
   tries=0
   while groups[ii]==groups[jj] and tries<20:
    jj=rng.choice(idx); tries+=1
   if groups[ii]!=groups[jj]: pos_i.append(ii);pos_j.append(jj)
 pos_i=np.asarray(pos_i[:P],int);pos_j=np.asarray(pos_j[:P],int)
 # same-prompt different model hard negatives
 prompt_to_idx={g:np.where(groups==g)[0] for g in np.unique(groups)}
 for _ in range(P):
  g=rng.choice(list(prompt_to_idx)); ix=prompt_to_idx[g]
  if len(ix)<2: continue
  ii,jj=rng.choice(ix,2,replace=False)
  if y[ii]!=y[jj]: neg_i.append(ii);neg_j.append(jj);neg_f.append(0)
 # same-family, different model, different prompt negatives
 for _ in range(P):
  ii=int(rng.integers(n)); candidates=np.where((fam==fam[ii])&(y!=y[ii])&(groups!=groups[ii]))[0]
  if len(candidates): neg_i.append(ii);neg_j.append(int(rng.choice(candidates)));neg_f.append(1)
 # cross-family negatives
 for _ in range(P):
  ii=int(rng.integers(n)); candidates=np.where((fam!=fam[ii])&(groups!=groups[ii]))[0]
  if len(candidates): neg_i.append(ii);neg_j.append(int(rng.choice(candidates)));neg_f.append(2)
 ni=np.asarray(neg_i,int); nj=np.asarray(neg_j,int)
 # Pair feature builder for train indices uses precomputed sparse matrices.
 def train_pair_features(i,j):
  cs=np.asarray(Ctr[i].multiply(Ctr[j]).sum(axis=1)).ravel(); ws=np.asarray(Wtr[i].multiply(Wtr[j]).sum(axis=1)).ravel()
  ap=np.sum(A_tr[i]*A_tr[j],axis=1)/(np.linalg.norm(A_tr[i],axis=1)*np.linalg.norm(A_tr[j],axis=1)+1e-6)
  ad=np.mean(np.abs(A_tr[i]-A_tr[j]),axis=1); eq=(b_oof[i]==b_oof[j]).astype(np.float32)
  lr=np.minimum(lengths[i],lengths[j])/(np.maximum(lengths[i],lengths[j])+1e-6)
  ps=1.0-np.minimum(1.0,np.abs(punct[i]-punct[j]).sum(1)*0.5)
  sf=(fam[i]==fam[j]).astype(np.float32)
  return np.column_stack([cs,ws,ap,ad,eq[:,0],eq[:,1],eq[:,2],eq[:,3],lr,ps]).astype(np.float32)
 Xp=train_pair_features(pos_i,pos_j); Xn=train_pair_features(ni,nj)
 Xpair=np.vstack([Xp,Xn]); ypair=np.r_[np.ones(len(Xp),dtype=np.int8),np.zeros(len(Xn),dtype=np.int8)]
 verifier=LogisticRegression(C=0.35,max_iter=1000,class_weight='balanced')
 verifier.fit(Xpair,ypair)
 # Test-to-reference: select top reference rows per class by blended char/word similarity, then verify each pair.
 R=a.refs_per_class; scores=np.zeros((len(te),len(LABELS)),dtype=np.float32)
 for start in range(0,len(te),128):
  stop=min(len(te),start+128); ci=Cte[start:stop] @ Ctr.T; wi=Wte[start:stop] @ Wtr.T
  sim=0.55*ci.toarray()+0.45*wi.toarray()
  for k,idx in idx_by_model.items():
   loc=np.argsort(sim[:,idx],axis=1)[:,-R:]
   ref=idx[loc].reshape(-1); q=np.repeat(np.arange(start,stop),R)
   # feature arrays use combined train+test index space for pairwise lookup
   cs=np.asarray(Cte[q-start].multiply(Ctr[ref]).sum(axis=1)).ravel()
   ws=np.asarray(Wte[q-start].multiply(Wtr[ref]).sum(axis=1)).ravel()
   ap=np.sum(a_prof[n+q]*A_tr[ref],axis=1)/(np.linalg.norm(a_prof[n+q],axis=1)*np.linalg.norm(A_tr[ref],axis=1)+1e-6)
   ad=np.mean(np.abs(a_prof[n+q]-A_tr[ref]),axis=1)
   eq=(b_test[q]==b_oof[ref]).astype(np.float32)
   lr=np.minimum(np.array([max(1,len(test_texts[z-start].split())) for z in q]),lengths[ref])/(np.maximum(np.array([max(1,len(test_texts[z-start].split())) for z in q]),lengths[ref])+1e-6)
   ptest=np.array([[x.count(z) for z in ['.',',',';',':','!','?','—','"',"'",'(',')']] for x in [test_texts[z-start] for z in q]],dtype=np.float32); ptest=ptest/(ptest.sum(1,keepdims=True)+1)
   ps=1.0-np.minimum(1.0,np.abs(ptest-punct[ref]).sum(1)*0.5)
   XF=np.column_stack([cs,ws,ap,ad,eq[:,0],eq[:,1],eq[:,2],eq[:,3],lr,ps]).astype(np.float32)
   pp=verifier.predict_proba(XF)[:,1].reshape(stop-start,R)
   # Robust aggregation: top-3 mean reduces dependence on one unusually similar reference.
   scores[start:stop,k]=np.sort(pp,axis=1)[:,-min(3,R):].mean(axis=1)
 probs=softmax((scores-np.mean(scores,axis=1,keepdims=True))*5.0,axis=1).astype(np.float32)
 np.save(a.out,probs)
 audit={'version':'V34.1','method':'V31 baseline + evidence-quote A prototypes + prompt-weak-label B conditioning + lightweight pairwise same-model verifier',
  'ab_revision':manifest.get('revision'),'official_rows':n,'test_rows':len(te),'official_prompts':int(pd.Series(groups).nunique()),
  'A_surface_rows':len(surf),'A_semantic_candidate_rows':len(sem),'A_evidence_span_rows_used':len(spans),'A_feature_keys':len(keys),'A_oof_fold_audit':a_fold_audit,'A_oof_prompt_grouped':True,
  'B_targets':B_COLS,'B_prompt_rows':len(bdf),'B_oof_group_folds':5,'pair_positive_count':len(Xp),'pair_negative_count':len(Xn),
  'pair_negative_types':{'same_prompt_different_model':int(np.sum(np.array(neg_f)==0)),'same_family_different_model':int(np.sum(np.array(neg_f)==1)),'cross_family':int(np.sum(np.array(neg_f)==2))},
  'pair_features':['char_cosine','word_cosine','A_evidence_profile_cosine','A_profile_mean_abs_diff','same_task','same_domain','same_structure','same_explicitness','length_ratio','punctuation_similarity'],
  'refs_per_class':R,'pairwise_probability_shape':list(probs.shape),'finite':bool(np.isfinite(probs).all()),'row_sum_max_error':float(np.max(np.abs(probs.sum(1)-1))),
  'note':'A uses exact evidence quote prototypes built Prompt-Grouped OOF for official rows; absent cues are not negative labels. B labels are weak prompt attributes and are used only as pairwise nuisance/context agreement features. Pairwise verifier is trained on official labels; no Backbone is fine-tuned.',
  'seconds':round(time.time()-t0,2)}
 Path(a.audit).write_text(json.dumps(audit,indent=2,ensure_ascii=False),encoding='utf-8')
 print('[V34.1 PAIRWISE COMPLETE]',json.dumps(audit,ensure_ascii=False),flush=True)
if __name__=='__main__': main()
