"""Preserve E38 heads AND their original local stage1 adapters privately.

Legacy kernel file-list sizes were inconsistent with local binaries, so no
byte-verification claim is made for that old remote inventory. This new archive
preserves the actual local tensors with SHA-256, without upstream backbone.
"""
import hashlib
import json
import tarfile
from pathlib import Path

import torch

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'data/score_head_checkpoint_20261104'
EXPERIMENT=ROOT/'research/experiments/e38_nonlinear_score_head'


def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(2**20),b''):h.update(b)
    return h.hexdigest()


def run():
    OUT.mkdir(exist_ok=True);files=[p for p in EXPERIMENT.iterdir() if p.is_file() and p.suffix in {'.json','.joblib'}]
    files += [ROOT/'research/experiments/nonlinear_score_head.py',ROOT/'kernels/twostage/out_full/worker.py',ROOT/'kernels/twostage/kernel-metadata.json']
    contracts=[]
    for tag in ['q8','ll8']:
        folder=ROOT/f'kernels/twostage/out_full/out_{tag}';pt=folder/'stage1.pt';s=torch.load(pt,map_location='cpu',weights_only=True)
        assert s['plain']['weight'].shape==s['cent']['weight'].shape==(18,32768)
        assert s['plain']['bias'].shape==(18,)
        tensors=[]
        def visit(value):
            if isinstance(value,dict):
                for v in value.values():visit(v)
            elif torch.is_tensor(value):assert torch.isfinite(value).all();tensors.append(value)
        visit(s)
        contracts.append(dict(tag=tag,checkpoint_sha256=sha(pt),tensor_count=len(tensors),all_finite=True,readout_shape=[18,32768],
            limitation='Local checkpoint header/finite validation only; no new raw-text forward, CUDA or original training provenance guarantee.'))
        files += [pt,folder/'s1_plain.npy',folder/'oof_plain.npy']
        del s,tensors
    records=[dict(path=str(p.relative_to(ROOT)),bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(files)]
    archive=OUT/'score_heads_stage1_20261104.tar.gz'
    with tarfile.open(archive,'w:gz',compresslevel=3) as tar:
        for row in records:tar.add(ROOT/row['path'],arcname=row['path'],recursive=False)
    with tarfile.open(archive) as tar:
        for row in records:
            data=tar.extractfile(row['path']).read();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
    base=json.loads((ROOT/'kernels/twostage/kernel-metadata.json').read_text())
    result=dict(scope='Private E38 full-fold/head caches plus two original local stage1adapters. No raw passages or upstream backbone weights.',
        files=records,local_adapter_contracts=contracts,upstream_backbones=base['model_sources'],
        restore='Latest public source, overlay this archive, official train.csv. Cached replay uses included four score arrays. Raw-text serving also requires pinned upstream backbone attachments and GPU ABI/quality verification.',
        limitation='Old score row/revision provenance is not retroactively repaired by this backup. Do not claim independent LoRA retraining or champion quality.',
        archive=dict(path=archive.name,bytes=archive.stat().st_size,sha256=sha(archive)))
    (OUT/'artifact_manifest.json').write_text(json.dumps(result,indent=2))
    (OUT/'dataset-metadata.json').write_text(json.dumps(dict(title='NTL E38 score heads and stage1 checkpoints',id='ajikajadeh/ntl-e38-score-head-checkpoint',licenses=[dict(name='other')],
        description='Private nonlinear score-head research plus original local stage1LoRA weights. Includes SHA-256 and limited local tensor contracts. No new competition submission or validated gain over0.665champion.'),indent=2))
    print('Preserved',len(records),'files;',round(archive.stat().st_size/2**20,2),'MiB; two stage1adapters + five two-head bundles.',flush=True)


if __name__=='__main__':run()
