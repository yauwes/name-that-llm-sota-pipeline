"""Verify source+v4-base+E33/E35-delta restoration and replay all three scripts.

Use SHA-verified symlinks to local artifacts matching the immutable v4 manifest
to avoid another700MiB copy. No upstream model or external raw passage is needed.
Verify all delta bytes and then actually reload five E34 estimators as well.
"""
import hashlib
import json
import subprocess
import tarfile
import tempfile
import time
import zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'research/live/20261104'


def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(2**20),b''):h.update(b)
    return h.hexdigest()


def without_runtime(v):
    if isinstance(v,dict):return {k:without_runtime(x) for k,x in v.items() if k!='elapsed_s'}
    if isinstance(v,list):return [without_runtime(x) for x in v]
    return v


def run():
    start=time.perf_counter();OUT.mkdir(exist_ok=True)
    old=json.loads((ROOT/'research/live/20261103/restore_verification_20261104.json').read_text())
    base=ROOT;bm=json.loads((ROOT/'data/reader_checkpoint_20261103/artifact_manifest.json').read_text())
    delta_folder=ROOT/'data/context_identity_checkpoint_20261104';dm=json.loads((delta_folder/'artifact_manifest.json').read_text())
    assert dm['base_dependency']['archive_sha256']==bm['archive']['sha256']==old['private_archive_sha256']
    stage=Path(tempfile.mkdtemp(prefix='ntl_context_restore_20261104_'));project=stage/'source'
    pub=ROOT/'research/checkpoints/20261103_final';pm=json.loads((pub/'checkpoint_manifest_20261103.json').read_text())
    archive=pub/pm['archive']['path'];assert sha(archive)==pm['archive']['sha256']
    with zipfile.ZipFile(archive) as z:
        for row in pm['files']:
            target=stage/row['path'];assert target.resolve().is_relative_to(stage.resolve())
            data=z.read(row['path']);assert hashlib.sha256(data).hexdigest()==row['sha256']
            target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
    for row in bm['files']:
        original=base/row['path'];assert original.stat().st_size==row['bytes'] and sha(original)==row['sha256']
        target=project/row['path'];target.parent.mkdir(parents=True,exist_ok=True)
        if target.exists():target.unlink()
        target.symlink_to(original)
    archive=delta_folder/dm['archive']['path'];assert sha(archive)==dm['archive']['sha256']
    with tarfile.open(archive) as tar:
        assert len(tar.getmembers())==len(dm['files'])
        for row in dm['files']:
            target=project/row['path'];assert target.resolve().is_relative_to(project.resolve())
            data=tar.extractfile(row['path']).read();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
            target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
    (project/'data/train.csv').symlink_to(ROOT/'data/train.csv')
    assert not (project/'data/ext/reader_agent500/audited.parquet').exists()
    records=[];logs=OUT/'delta_restore_logs';logs.mkdir(exist_ok=True)
    for command,name in [('large_context_audit.py','e33_large_context'),('pairwise_identity.py','e34_pairwise_identity'),('mixed_context_audit.py','e35_mixed_context')]:
        before=json.loads((project/'research/experiments'/name/'results.json').read_text());begin=time.perf_counter()
        r=subprocess.run([str(ROOT/'.venv/bin/python'),str(project/'research/experiments'/command)],cwd=project,capture_output=True,text=True,timeout=180)
        (logs/f'{name}.txt').write_text(r.stdout+r.stderr);assert r.returncode==0,(name,r.stderr[-1200:])
        after=json.loads((project/'research/experiments'/name/'results.json').read_text());assert without_runtime(before)==without_runtime(after),name
        records.append(dict(experiment=name,metrics_match=True,returncode=r.returncode,elapsed_s=time.perf_counter()-begin))
        print(name,'restored replay matched',flush=True)
    r=subprocess.run([str(ROOT/'.venv/bin/python'),str(project/'research/checkpoints/checkpoint_identity_inference_smoke.py')],cwd=project,capture_output=True,text=True,timeout=180)
    (logs/'actual_checkpoint_inference.txt').write_text(r.stdout+r.stderr);assert r.returncode==0,r.stderr[-1200:]
    proof=json.loads((project/'research/live/20261104/identity_checkpoint_inference_verification.json').read_text())
    (OUT/'identity_checkpoint_inference_verification.json').write_text(json.dumps(proof,indent=2))
    result=dict(restored_directory=str(project),base_files_verified=len(bm['files']),base_files_mode='SHA-verified symlinks to local artifacts matching the immutable v4 manifest',
        delta_files_verified=len(dm['files']),source_archive_sha256=pm['archive']['sha256'],delta_archive_sha256=dm['archive']['sha256'],
        external_raw_text_required=False,jobs=records,actual_identity_heads_replayed=len(proof['checkpoints']),elapsed_s=time.perf_counter()-start,
        verified_source_sha256={str(p.relative_to(project)):sha(p) for p in project.rglob('*.py')},
        scope='Isolated delta restore over hash-verified v4 base. Cached three-script replay plus actual five-head inference. Not independent training, extraction, CUDA or leaderboard validation.')
    (OUT/'context_identity_restore_verification.json').write_text(json.dumps(result,indent=2))
    print('Delta restore verified',len(records),'scripts and',len(proof['checkpoints']),'actual heads in',round(result['elapsed_s'],2),'s',flush=True)


if __name__=='__main__':run()
