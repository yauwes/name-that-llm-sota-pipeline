"""Package an explicit source allowlist, aggregate reports and readable notebooks.

No remote writes. Numerical artifacts are backed up separately in private Kaggle
storage. Preserve this allowlist to reproduce the scope of a published snapshot.
"""
import hashlib
import json
import re
import shutil
import zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'research/checkpoints/20261103_final'
STAGE=Path('/private/tmp/ntl_publish_20261103/source')
UPLOAD=Path('/private/tmp/ntl_browser_upload_20261103')
ALLOW=Path(__file__).with_name('public_source_allowlist_20261103.json')
SECRET=re.compile(rb'KGAT_[A-Za-z0-9]{20,}|hf_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{25,}|ghp_[A-Za-z0-9]{20,}')
PRED_KEYS={'test_indices','prediction','baseline','selected','candidate'}


def sha(b):return hashlib.sha256(b).hexdigest()


def source_bytes(path):
    data=path.read_bytes()
    if path.suffix=='.ipynb' and path.name!='ntl_session_20261103.ipynb':
        nb=json.loads(data)
        for cell in nb['cells']:
            if cell['cell_type']=='code':cell['outputs']=[];cell['execution_count']=None
        data=json.dumps(nb,indent=1,ensure_ascii=False).encode()
    if path.suffix=='.json' and re.search(r'(?:fold\d+|folds)\.json$',path.name):
        obj=json.loads(data)
        def strip(record):return {k:v for k,v in record.items() if k not in PRED_KEYS}
        obj=[strip(r) for r in obj] if isinstance(obj,list) else strip(obj)
        data=json.dumps(obj,indent=2).encode()
    assert not SECRET.search(data),f'Secret pattern in {path}'
    return data


def run():
    OUT.mkdir(parents=True,exist_ok=True);UPLOAD.mkdir(exist_ok=True)
    names=json.loads(ALLOW.read_text())
    assert len(names)==len(set(names))
    records=[]
    for name in names:
        assert not name.startswith(('/', 'data/', '.env', '.git/', '.venv/'))
        p=ROOT/name;assert p.is_file(),name
        assert p.suffix in {'.py','.md','.json','.jsonl','.txt','.log','.ipynb','.sh'},name
        b=source_bytes(p);target=STAGE/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b)
        records.append(dict(path='source/'+name,bytes=len(b),sha256=sha(b)))
    archive=OUT/'ntl_research_checkpoint_20261103.zip'
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for row in records:z.write(STAGE/row['path'].removeprefix('source/'),row['path'])
    with zipfile.ZipFile(archive) as z:
        assert len(z.namelist())==len(records)
        for row in records:assert sha(z.read(row['path']))==row['sha256']
    manifest=dict(scope='Explicit source allowlist; fold predictions stripped; no raw competition passages, numerical model files or credentials.',
        official_best_balanced_accuracy=.665,target=.99,target_achieved=False,new_submission_sent=False,
        files=records,archive=dict(path=archive.name,bytes=archive.stat().st_size,sha256=sha(archive.read_bytes())))
    (OUT/'checkpoint_manifest_20261103.json').write_text(json.dumps(manifest,indent=2))
    for name in ['readme.md','notebook/ntl_session_20261103.ipynb','notebook/ntl_apex_v3_contract_fixed_UNVALIDATED.ipynb']:
        shutil.copy2(ROOT/name,UPLOAD/Path(name).name)
        shutil.copy2(ROOT/name,OUT/Path(name).name)
    for name in ['ntl_research_checkpoint_20261103.zip','checkpoint_manifest_20261103.json']:
        shutil.copy2(OUT/name,UPLOAD/name)
    print('Public snapshot',len(records),'source files;',archive.stat().st_size,'bytes; SHA256',manifest['archive']['sha256'])


if __name__=='__main__':run()
