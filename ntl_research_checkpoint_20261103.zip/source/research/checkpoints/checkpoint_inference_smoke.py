"""Load ten restored self-trained checkpoints and reproduce held-out predictions."""
import hashlib
import json
import sys
import time
from pathlib import Path

import joblib
import numpy as np

ROOT=Path(__file__).resolve().parents[2]


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def run():
    begin=time.perf_counter();live=ROOT/'research/live/20261103'
    restore=json.loads((live/'restore_verification_20261104.json').read_text())
    project=Path(restore['restored_directory'])
    sys.path.insert(0,str(project/'notebook'));sys.path.insert(0,str(project/'research/experiments'))
    import lib
    import partial_group_audit as audit
    from threadpoolctl import threadpool_limits
    records=[]
    with threadpool_limits(limits=2):
        t=lib.load_train(project/'data/train.csv');S=lib.make_splits(t)
        q,l=[np.load(project/f'kernels/twostage/out_full/out_{n}/s1_plain.npy') for n in ['q8','ll8']]
        svc=np.load(project/'kernels/svc4/out/members/svc4_p190k/oof.npy')
        external=np.c_[lib.N(q),lib.N(l)]*3.
        X=np.asarray(np.load(project/'data/features/e28_predictability_distilgpt2/features.npy'),dtype=np.float32)
        dc=np.asarray(np.load(project/'data/features/e20_spectral_reader/features.npy')[:,1,0,:],dtype=np.float32)
        for f in range(5):
            directory=project/'research/experiments/e28_predictability_distilgpt2'
            bundle=joblib.load(directory/f'head_fold{f}.joblib');fold=json.loads((directory/f'fold{f}.json').read_text())
            assert bundle['labels']==lib.LABELS and bundle['signature']==fold['signature']
            te=S[f]==2;A=bundle['scaler'].transform(X[te])
            if bundle['chosen']['name']=='hybrid':A=np.c_[A,external[te]]
            scores=lib.N(bundle['head'].decision_function(A))
            base=lib.N(lib.blend([q[te],l[te],svc[f,te]],bundle['baseline_weights']))
            pred=(base+bundle['alpha']*scores).argmax(1)
            assert np.array_equal(pred,np.asarray(fold['prediction']['fusion']))
            records.append(dict(kind='DistilGPT2-summary LR checkpoint',fold=f,rows=int(te.sum()),predictions_match=True))
            directory=project/'research/experiments/e29_partial_group_audit'
            bundle=joblib.load(directory/f'gaussian_fold{f}.joblib');fold=json.loads((directory/f'fold{f}.json').read_text())
            assert bundle['labels']==lib.LABELS and bundle['signature']==fold['signature']
            ix=np.asarray(fold['test_indices']['k18_seed0']);groups=np.unique(t.prompt_id.to_numpy()[ix],return_inverse=True)[1]
            pred=audit.gauss.scores(dc[ix],groups,bundle['params']).argmax(1)
            assert np.array_equal(pred,np.asarray(fold['prediction']['k18_seed0']['oracle_partial']))
            records.append(dict(kind='Gaussian WPCA64 checkpoint',fold=f,rows=len(ix),predictions_match=True))
    report=dict(checks=records,code_sha256=sha(Path(__file__)),elapsed_s=time.perf_counter()-begin,
        restored_directory=str(project),scope='Ten restored self-trained checkpoint files loaded and held-out predictions reproduced. Not all50joblib files, independent retraining, CUDA inference or leaderboard validation.')
    (live/'checkpoint_inference_verification_20261104.json').write_text(json.dumps(report,indent=2))
    print('Ten restored checkpoints reproduce their held-out predictions; seconds',report['elapsed_s'])


if __name__=='__main__':run()
