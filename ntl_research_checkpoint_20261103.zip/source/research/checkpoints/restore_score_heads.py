"""Check isolated public-source + E38/E39 restoration without upstream LMs."""
import hashlib
import json
import subprocess
import tempfile
import time
import zipfile
from pathlib import Path

from verify_score_heads import resolve

ROOT=Path(__file__).resolve().parents[2]


def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()


def without_runtime(v):
    if isinstance(v,dict):return {k:without_runtime(x) for k,x in v.items() if k!='elapsed_s'}
    if isinstance(v,list):return [without_runtime(x) for x in v]
    return v


def run():
    start=time.perf_counter();stage=Path(tempfile.mkdtemp(prefix='ntl_score_head_restore_')).resolve();project=stage/'source'
    public=ROOT/'research/checkpoints/20261103_final';pm=json.loads((public/'checkpoint_manifest_20261103.json').read_text())
    archive=public/pm['archive']['path'];assert digest(archive)==pm['archive']['sha256']
    with zipfile.ZipFile(archive) as z:
        for row in pm['files']:
            target=stage/row['path'];assert target.resolve().is_relative_to(stage)
            data=z.read(row['path']);assert hashlib.sha256(data).hexdigest()==row['sha256']
            target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
    verified=0
    for folder in ['score_head_checkpoint_20261104','hierarchical_checkpoint_20261104']:
        raw=ROOT/'data'/(folder+'_remote_roundtrip')/'individual'
        manifest=json.loads(resolve(raw,'artifact_manifest.json').read_text())
        for row in manifest['files']:
            original=resolve(raw,row['path']);assert original.stat().st_size==row['bytes'] and digest(original)==row['sha256']
            target=project/row['path'];assert target.resolve().is_relative_to(project)
            target.parent.mkdir(parents=True,exist_ok=True)
            if target.exists():target.unlink()
            # Python resolves a launched script's symlink before setting import
            # paths/__file__. Copy code; link only immutable numeric/metadata files.
            if target.suffix=='.py':target.write_bytes(original.read_bytes())
            else:target.symlink_to(original)
            verified+=1
    (project/'data').mkdir(exist_ok=True);(project/'data/train.csv').symlink_to(ROOT/'data/train.csv')
    assert not (project/'data/models').exists(), 'Unexpected upstream model dependency'
    output=ROOT/'research/live/20261104/score_head_restore_logs';output.mkdir(exist_ok=True);records=[]
    for short,name,script in [('e38','e38_nonlinear_score_head','nonlinear_score_head.py'),('e39','e39_hierarchical_score_head','hierarchical_score_head.py')]:
        result=project/'research/experiments'/name/'results.json';before=json.loads(result.read_text());tick=time.perf_counter()
        r=subprocess.run([str(ROOT/'.venv/bin/python'),str(project/'research/experiments'/script)],cwd=project,capture_output=True,text=True,timeout=120)
        (output/f'{short}_cached_replay.log').write_text(r.stdout+r.stderr);assert r.returncode==0,r.stderr[-1600:]
        assert without_runtime(before)==without_runtime(json.loads(result.read_text()))
        proof=project/f'research/live/20261104/{short}_restored_actual_heads.json'
        r=subprocess.run([str(ROOT/'.venv/bin/python'),str(project/'research/checkpoints/verify_score_heads.py'),short,'--report',str(proof)],cwd=project,capture_output=True,text=True,timeout=120)
        (output/f'{short}_actual_heads.log').write_text(r.stdout+r.stderr);assert r.returncode==0,r.stderr[-1600:]
        p=json.loads(proof.read_text());assert p['model_count']==10 and all(x['prediction_match'] for x in p['heads'])
        records.append(dict(experiment=short,cached_metrics_identical=True,actual_heads_replayed=10,elapsed_s=time.perf_counter()-tick))
        print(short,'isolated replay +10actualheads matched',flush=True)
    report=dict(restored_directory=str(project),source_archive_sha256=pm['archive']['sha256'],source_files_verified=len(pm['files']),
        private_files_verified=verified,private_restore_mode='Code bytes copied; numeric/metadata SHA-verified symlinks to actual downloaded remote members',jobs=records,
        raw_external_passages_required=False,pretrained_backbone_required=False,elapsed_s=time.perf_counter()-start,
        scope='Isolated cached E38/E39 pipeline replay and20actualhead inferences. Not independent training, rawtext backbone/CUDA or hidden leaderboard verification.')
    (ROOT/'research/live/20261104/score_heads_restore_verified.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2),flush=True)


if __name__=='__main__':run()
