"""Replay one saved E37 epoch in an isolated directory on Metal.

The live training process is not changed. Compare resumed epoch metrics with
the already recorded uninterrupted trajectory. Uses private snapshot version1.
"""
import hashlib
import io
import json
import sys
import tarfile
import tempfile
import time
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from threadpoolctl import threadpool_limits

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'research/experiments'))
import minilm_adapt as experiment


def run():
    begin=time.perf_counter();torch.set_num_threads(2);assert torch.backends.mps.is_available()
    torch.mps.set_per_process_memory_fraction(.30)
    folder=ROOT/'data/minilm_checkpoint_20261104';m=json.loads((folder/'artifact_manifest.json').read_text())
    archive=folder/m['archive']['path'];assert experiment.sha(archive)==m['archive']['sha256']
    member='research/experiments/e37_minilm_adapt/refit0/last.pt'
    with tarfile.open(archive) as tar:data=tar.extractfile(member).read()
    row=next(r for r in m['files'] if r['path']==member);assert hashlib.sha256(data).hexdigest()==row['sha256']
    state=torch.load(io.BytesIO(data),map_location='cpu',weights_only=True)
    expected_epoch=state['epoch']+1
    reference=next(r for r in json.loads((experiment.OUT/'refit0/history.json').read_text()) if r['epoch']==expected_epoch)
    assert state['signature']==m['signature']
    probe=Path(tempfile.mkdtemp(prefix='ntl_minilm_resume_20261104_'));(probe/'last.pt').write_bytes(data)
    t=experiment.lib.load_train(ROOT/'data/train.csv')
    prompts=pd.Series(t.prompt_id.unique()).sample(frac=1,random_state=42).tolist();fold=t.prompt_id.map({p:i%5 for i,p in enumerate(prompts)}).to_numpy()
    tr=np.flatnonzero(fold!=0);tok=experiment.AutoTokenizer.from_pretrained(experiment.MODEL,local_files_only=True,trust_remote_code=False)
    token=tok(t.text.tolist(),max_length=experiment.PLAN['max_tokens'],truncation=True)
    model,history,_=experiment.fit(tok,token,t.y.to_numpy(),tr,None,'mps',20263700,probe,m['signature'],expected_epoch,False)
    actual=history[-1];loss_delta=actual['online_train_loss']-reference['online_train_loss'];accuracy_delta=actual['online_train_accuracy']-reference['online_train_accuracy']
    passed=abs(loss_delta)<=1e-3 and abs(accuracy_delta)<=1/len(tr)+1e-12
    result=dict(snapshot_archive_sha256=m['archive']['sha256'],resume_from_epoch=state['epoch'],replayed_epoch=expected_epoch,
        reference=reference,resumed=actual,loss_delta=loss_delta,accuracy_delta=accuracy_delta,passed=passed,
        isolated_directory=str(probe),elapsed_s=time.perf_counter()-begin,code_sha256=experiment.sha(Path(__file__)),
        scope='One actual optimizer/scheduler/CPU+MPS-RNG epoch resume compared with an uninterrupted refit trajectory. Not every checkpoint/device or generalization verification.')
    (ROOT/'research/live/20261104/e37_resume_parity.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2),flush=True)
    assert passed,'Saved-state training resume did not match the recorded trajectory within declared tolerances'
    del model;torch.mps.empty_cache()


if __name__=='__main__':
    with threadpool_limits(limits=2):run()
