"""Actually replay ten saved E38/E39 heads, optionally from remote byte backups."""
import argparse
import json
import sys
import time
from pathlib import Path

import joblib
import numpy as np
from sklearn.preprocessing import normalize
from threadpoolctl import threadpool_limits

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'research/experiments'))
from spectral_reader import sha
import lib
from hierarchical_score_head import probability


def resolve(root,relative):
    direct=root/relative
    if direct.is_file():return direct
    matches=[p for p in root.rglob(Path(relative).name) if p.as_posix().endswith('/'+relative)]
    assert len(matches)==1,(relative,matches)
    return matches[0]


def run():
    p=argparse.ArgumentParser();p.add_argument('experiment',choices=['e38','e39'])
    p.add_argument('--checkpoint-root',type=Path,default=ROOT)
    p.add_argument('--feature-root',type=Path,default=ROOT)
    p.add_argument('--report',type=Path,required=True);a=p.parse_args();started=time.perf_counter()
    directory='research/experiments/'+dict(e38='e38_nonlinear_score_head',e39='e39_hierarchical_score_head')[a.experiment]
    manifest=json.loads(resolve(a.checkpoint_root,directory+'/manifest.json').read_text())
    code=ROOT/'research/experiments'/dict(e38='nonlinear_score_head.py',e39='hierarchical_score_head.py')[a.experiment]
    assert sha(code)==manifest['code_sha256']
    t=lib.load_train(ROOT/'data/train.csv');assert sha(ROOT/'data/train.csv')==manifest['train_sha256']
    arrays=[]
    for name in ['s1_plain','oof_plain']:
        for tag in ['q8','ll8']:
            relative=f'kernels/twostage/out_full/out_{tag}/{name}.npy';path=resolve(a.feature_root,relative)
            assert sha(path)==manifest['inputs'][relative];arrays.append(np.load(path))
    q,l,q2,l2=arrays;X=np.concatenate([lib.N(q),lib.N(l)],1);base=lib.N((lib.N(q2)+lib.N(l2))/2);records=[]
    for f in range(5):
        bundle=joblib.load(resolve(a.checkpoint_root,directory+f'/heads_fold{f}.joblib'))
        fold=json.loads(resolve(a.checkpoint_root,directory+f'/fold{f}.json').read_text());ix=np.array(fold['test_indices'])
        assert bundle['signature']==fold['signature']==manifest['signature'] and bundle['labels']==lib.LABELS
        assert np.array_equal(bundle['all_gold_ids'],t.id.astype(str).to_numpy())
        assert not np.intersect1d(bundle['training_indices'],ix).size
        E=bundle['scaler'].transform(X[ix]);E=normalize(E) if a.experiment=='e38' else E
        for kind,head in bundle['heads'].items():
            if a.experiment=='e38':score=head.decision_function(E);pred=score.argmax(1)
            else:
                prob=probability(head,E);pred=prob.argmax(1);score=np.log(np.clip(prob,1e-12,1))
            fusion=(base[ix]+.1*lib.N(score)).argmax(1)
            assert np.array_equal(pred,fold['prediction'][kind])
            assert np.array_equal(fusion,fold['prediction'][kind+'_fusion'])
            records.append(dict(fold=f,family=kind,prediction_match=True))
    report=dict(experiment=a.experiment,heads=records,model_count=len(records),elapsed_s=time.perf_counter()-started,
        checkpoint_root=str(a.checkpoint_root),feature_root=str(a.feature_root),
        scope='Ten actual reloaded heads/scalers reproduce heldout classifier/fusion predictions. Does not retroactively prove upstream score-row provenance or rawtext/CUDA/hidden-test quality.')
    a.report.write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))


if __name__=='__main__':
    with threadpool_limits(limits=2):run()
