"""Private E39 delta; stage1 score arrays/adapters remain in E38version1."""
import hashlib
import json
import tarfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'data/hierarchical_checkpoint_20261104'


def run():
    OUT.mkdir(exist_ok=True);files=[]
    for name in ['e39_hierarchical_score_head','e39_preflight_probability_roundoff']:
        files.extend(p for p in (ROOT/'research/experiments'/name).iterdir() if p.is_file())
    files.extend([ROOT/'research/experiments/hierarchical_score_head.py',ROOT/'research/experiments/error_breakdown.py',ROOT/'research/checkpoints/verify_score_heads.py'])
    records=[dict(path=str(p.relative_to(ROOT)),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(files)]
    archive=OUT/'hierarchical_heads_20261104.tar.gz'
    with tarfile.open(archive,'w:gz',compresslevel=3) as tar:
        for row in records:tar.add(ROOT/row['path'],arcname=row['path'],recursive=False)
    with tarfile.open(archive) as tar:
        for row in records:
            data=tar.extractfile(row['path']).read();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
    result=dict(scope='Private E39 complete five-fold heads and pre-normalization diagnostic predecessor. No raw text or upstream backbone.',files=records,
        dependency=dict(dataset='ajikajadeh/ntl-e38-score-head-checkpoint',version=1,archive_sha256='44b6045bd57d1fd224de864887c2a0e52aedc74c63278370556008e73f5321ae'),
        restore='Latest public source; overlay E38version1 then this delta; attach official train.csv. Cached head replay only; no rawtext/CUDA or quality guarantee.',
        archive=dict(path=archive.name,bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest()))
    (OUT/'artifact_manifest.json').write_text(json.dumps(result,indent=2))
    (OUT/'dataset-metadata.json').write_text(json.dumps(dict(title='NTL E39 hierarchical score head checkpoints',id='ajikajadeh/ntl-e39-hierarchical-checkpoint',licenses=[dict(name='other')],
        description='Private complete heads, full fold caches and numerical preflight archive. Depends on private E38version1 score arrays; no raw passages or upstream backbone. Not a validated improvement or competition submission.'),indent=2))
    print('E39delta',len(records),'files',round(archive.stat().st_size/2**20,3),'MiB',flush=True)


if __name__=='__main__':run()
