"""Reload all five saved E34 heads/vectorizers and reproduce actual predictions."""
import hashlib
import json
import sys
import time
from pathlib import Path

import joblib
import numpy as np
from threadpoolctl import threadpool_limits

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'research/experiments'))
import pairwise_identity as experiment


def run():
    start=time.perf_counter();t=experiment.lib.load_train(ROOT/'data/train.csv');texts=t.text.tolist();groups=t.prompt_id.to_numpy()
    dense=[]
    for p in [experiment.STYLE,experiment.READER,experiment.SEM]:
        assert np.array_equal(np.load(p/'id.npy'),t.id.astype(str))
        a=np.load(p/'features.npy',mmap_mode='r')
        if p==experiment.READER:a=a[:,experiment.LAYERS.index(16),0,:]
        dense.append(experiment.unit(np.asarray(a,dtype=np.float32)))
    length=np.log1p(t.text.str.split().str.len().to_numpy())
    punct=np.array([[s.count(c)/max(len(s),1)*100 for c in ['—',';',':','!','?','(',')','\n','*','"']] for s in texts],dtype=np.float32)
    q,l=[np.load(ROOT/f'kernels/twostage/out_full/out_{n}/oof_plain.npy') for n in ['q8','ll8']]
    base=experiment.lib.N((experiment.lib.N(q)+experiment.lib.N(l))/2);records=[]
    for f in range(5):
        saved=joblib.load(experiment.OUT/f'verifier_fold{f}.joblib');old=json.loads((experiment.OUT/f'fold{f}.json').read_text())
        assert saved['signature']==old['signature'] and saved['labels']==experiment.lib.LABELS
        space=experiment.PairSpace.__new__(experiment.PairSpace);space.dense=dense;space.length=length;space.punct=punct
        space.vec=saved['vectorizers'];space.sparse=[v.transform(texts) for v in space.vec]
        ix=np.array(old['test_indices']);assert not set(groups[ix])&set(groups[saved['training_indices']])
        score=experiment.source_scores(saved['head'],space,ix,saved['reference_indices'],groups)
        pred=dict(verifier=score.argmax(1),fusion=(base[ix]+saved['feature_plan']['alpha']*experiment.lib.N(score)).argmax(1))
        for key,p in pred.items():assert np.array_equal(p,old['prediction'][key]),(f,key,'checkpoint prediction drift')
        records.append(dict(fold=f,rows=len(ix),head_reloaded=True,vectorizers_reloaded=True,verifier_and_fusion_match=True,
            checkpoint_sha256=experiment.sha(experiment.OUT/f'verifier_fold{f}.joblib')))
        print('Restored E34 head',f,'actual predictions match',flush=True)
    out=ROOT/'research/live/20261104';out.mkdir(parents=True,exist_ok=True)
    result=dict(checkpoints=records,elapsed_s=time.perf_counter()-start,code_sha256=experiment.sha(Path(__file__)),
        scope='Five reloaded E34 estimators/vectorizers reproduce saved held-out classifier and fusion predictions; no retraining or CUDA/leaderboard validation.')
    (out/'identity_checkpoint_inference_verification.json').write_text(json.dumps(result,indent=2))
    print('All five identity checkpoints replayed in',round(result['elapsed_s'],2),'s',flush=True)


if __name__=='__main__':
    with threadpool_limits(limits=2):run()
