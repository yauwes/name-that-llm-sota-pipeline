"""Find external rows that are new against the open pool and train. Reads only parquet and csv, one file at a time."""
import glob, hashlib, re, sys, numpy as np, pandas as pd, pyarrow.parquet as pq
LABELS = set(pd.read_csv('data/train.csv', usecols=['model']).model)
norm = lambda s: re.sub(r'\W+', ' ', s.lower()).strip(); key = lambda s: hashlib.md5(norm(s).encode()).digest()[:8]
TXT = ['text', 'passage', 'response', 'completion', 'generated_text', 'content', 'output', 'answer', 'generation']; MOD = ['model', 'label', 'target_model', 'source_model', 'model_name', 'requested_model', 'target', 'author']
seen = {key(x) for x in pd.read_parquet('data/pool/ntl_open_pool.parquet', columns=['text']).text}; train = {key(x) for x in pd.read_csv('data/train.csv', usecols=['text']).text}; print('open pool keys', len(seen), flush=True); seen |= train
def fix(m):
    m = str(m).strip().lower().split('/')[-1].replace('_', '-')
    m = {'qwen3.8max': 'qwen3.8-max', 'qwen-3.8-max': 'qwen3.8-max', 'kimi-k-3': 'kimi-k3', 'glm5.3': 'glm-5.3', 'glm5.3-flash': 'glm-5.3-flash'}.get(m, m); return m
new, stats = [], []
for f in sorted(glob.glob('data/ext/*/**/*', recursive=True)):
    if not f.endswith(('.parquet', '.csv')): continue
    try: cols = pq.read_schema(f).names if f.endswith('parquet') else pd.read_csv(f, nrows=0).columns.tolist()
    except Exception as e: stats.append(dict(file=f, note=str(e)[:50])); continue
    lc = {c.lower(): c for c in cols}; tc = next((lc[c] for c in TXT if c in lc), None); mc = next((lc[c] for c in MOD if c in lc), None)
    if not tc or not mc: stats.append(dict(file=f[9:], rows=0, note='cols ' + ','.join(cols[:6]))); continue
    d = pd.read_parquet(f, columns=[tc, mc]) if f.endswith('parquet') else pd.read_csv(f, usecols=[tc, mc], on_bad_lines='skip', engine='c'); n = len(d); d.columns = ['text', 'model']; d = d.dropna(); d['model'] = d.model.map(fix); d = d[d.model.isin(LABELS)]; lab = len(d); d['text'] = d.text.astype(str); w = d.text.str.split().str.len(); d = d[w.between(30, 300)]; k = d.text.map(key); dup = k.isin(seen); fresh = d[~dup].copy(); fresh = fresh[~k[~dup].duplicated().values]; seen |= set(k)
    fresh['src'] = f.split('/')[2]; new.append(fresh[['text', 'model', 'src']]); stats.append(dict(file=f[9:], rows=n, labelled=lab, inrange=len(d), new=len(fresh), classes=d.model.nunique()))
s = pd.DataFrame(stats); pd.set_option('display.width', 200, 'display.max_colwidth', 70, 'display.max_rows', 80); print(s.sort_values('new', ascending=False).to_string(index=False))
n = pd.concat(new, ignore_index=True); n.to_parquet('data/ext/new_rows.parquet'); print('NEW total', len(n)); print(n.model.value_counts().to_string()); print(n.src.value_counts().head(15).to_string())
