"""E40: metadata-only source/label confounding audit, not a classifier CV.

Read no external text. Reproduce E36's capped row selection exactly. Never
modify the pool or the TPU job owned by the other chat.
"""
import json
import time
from pathlib import Path

import numpy as np
import pandas as pd

from spectral_reader import ROOT, sha, dump
import lib

OUT=ROOT/'research/experiments/e40_external_origin_audit'


def analyze(pool):
    table=pd.crosstab(pool.source_dataset,pool.model).reindex(columns=lib.LABELS,fill_value=0)
    count=table.to_numpy(dtype=float);conditional=count/count.sum(0,keepdims=True)
    joint=conditional/18;origin=joint.sum(1,keepdims=True)
    mask=joint>0;denominator=np.broadcast_to(origin/18,joint.shape)
    mi=float(np.sum(joint[mask]*np.log(joint[mask]/denominator[mask])))
    by_model=[]
    for label in lib.LABELS:
        values=table[label];fractions=values[values>0]/values.sum();rows=pool[pool.model==label]
        by_model.append(dict(model=label,rows=int(values.sum()),origin_count=int((values>0).sum()),
            dominant_origin=str(values.idxmax()),dominant_origin_fraction=float(values.max()/values.sum()),
            effective_origin_count=float(np.exp(-(fractions*np.log(fractions)).sum())),
            words_p10_median_p90=np.percentile(rows.n_words,[10,50,90]).tolist()))
    by_origin=[]
    for source,values in table.iterrows():
        rest=table.sum()-values
        by_origin.append(dict(origin=source,rows=int(values.sum()),model_count=int((values>0).sum()),
            missing_models_in_origin=[m for m in lib.LABELS if values[m]==0],
            missing_models_if_origin_heldout=[m for m in lib.LABELS if rest[m]==0],
            all18classes_retained_when_origin_heldout=bool((rest>0).all())))
    return dict(rows=len(pool),origins=len(table),per_model=by_model,per_origin=by_origin,
        origin_label_mutual_information_nats_equal_model_prior=mi,
        mutual_information_fraction_of_model_entropy=mi/np.log(18),
        in_sample_origin_only_balanced_oracle=float(conditional.max(1).sum()/18),
        counts={str(source):{m:int(v) for m,v in row.items()} for source,row in table.iterrows()})


def run():
    start=time.perf_counter();OUT.mkdir(exist_ok=True);path=ROOT/'data/e15/ntl_open_pool.parquet'
    raw=pd.read_parquet(path,columns=['id','model','source_dataset','prompt_group','n_words'])
    assert raw.notna().all().all() and set(raw.model)==set(lib.LABELS)
    capped=raw.sample(frac=1,random_state=31).groupby('model').head(8000).reset_index(drop=True)
    prior=json.loads((ROOT/'research/experiments/e36_tpu_contract/results.json').read_text())
    assert sha(path)==prior['pool_sha256'] and len(capped)==prior['capped_rows']
    # source_dataset is only a broad pipeline label. Recover syntactically
    # valid Kaggle owner/dataset prefixes from metadata, without treating them
    # as verified generation provenance or decoding any prompt content.
    prefix=capped.prompt_group.str.extract(r'^([A-Za-z0-9_-]+/[A-Za-z0-9_-]+):',expand=False).str.lower()
    detailed=capped.assign(source_dataset=prefix.fillna('UNRECOVERED_ORIGIN'))
    result=dict(code_sha256=sha(Path(__file__)),pool_sha256=prior['pool_sha256'],raw=analyze(raw),capped=analyze(capped),
        recovered_prefix=analyze(detailed),recovered_prefix_rows=int(prefix.notna().sum()),unrecovered_prefix_rows=int(prefix.isna().sum()),
        prefix_caveat='Syntactic owner/dataset prefix from prompt_group only, not independently verified dataset/endpoint/model-revision provenance. UNRECOVERED_ORIGIN is a missing-metadata bucket, not one real source.',
        cap='Same row order/selection as E36: shuffle seed31 then head8000 per model',
        external_text_loaded=False,job_or_pool_modified=False,elapsed_s=time.perf_counter()-start,
        interpretation='Metadata association is descriptive, not proof of wrong labels, a text shortcut or causal origin effect. The origin-only oracle uses full-pool labels in-sample and cannot serve hidden test (which has no origin metadata). No training, CV or leaderboard gain.',
        next_check='For origins that retain all18classes, design source-heldout validation with prompt identity controlled. Audit model/revision label provenance before balancing or removing data; do not infer correct/incorrect labels from count tables alone.',
        submission_eligible=False)
    dump(OUT/'results.json',result)
    for key in ['raw','capped','recovered_prefix']:
        r=result[key];print(key,{k:r[k] for k in ['rows','origins','mutual_information_fraction_of_model_entropy','in_sample_origin_only_balanced_oracle']},flush=True)
        print('Per-model dominant source share',[(r['model'],round(r['dominant_origin_fraction'],3)) for r in r['per_model']],flush=True)
    print('Seconds',round(result['elapsed_s'],2),flush=True)


if __name__=='__main__':run()
