"""E15: frozen reader scoring; scaler/PCA train-only, selection val-only.

Run from repository root: .venv/bin/python research/experiments/reader_foldlocal.py
Uses existing immutable feature caches; no GPU, network, or submission.
"""
import os
os.environ.setdefault('OMP_NUM_THREADS', '2')
os.environ.setdefault('OPENBLAS_NUM_THREADS', '2')
import hashlib
import json
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import balanced_accuracy_score as ba, confusion_matrix
from sklearn.preprocessing import StandardScaler
from threadpoolctl import threadpool_limits

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'notebook'))
import lib

OUT = ROOT / 'research/experiments/e15_reader_foldlocal'
OUT.mkdir(parents=True, exist_ok=True)
FEATURES = ROOT / 'kernels/reader/out'
PLAN = dict(readers=['q8', 'q27'], layers=[16, 27], pca=128,
            heads=['lr_C0.003', 'lr_C0.03', 'lda_auto'], rotations=5,
            training_scope='host_only; cached external rows excluded because raw pool ordering changed',
            anchor='q8_l16_lr_C0.003', selection='max validation BA; fixed list tie order',
            confidence='95% paired prompt bootstrap, fixed predictions, 2000 draws')


def dump(path, value):
    lib.atomic(path, lambda f: f.write(json.dumps(value, indent=2).encode()))


def fingerprint(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(2 ** 20), b''):
            h.update(chunk)
    return h.hexdigest()


def run():
    start = time.perf_counter()
    t = lib.load_train(ROOT / 'data/train.csv')
    S = lib.make_splits(t)
    y = t.y.to_numpy()
    assert np.array_equal(np.load(FEATURES / 'train_id.npy'), t.id.astype(str))
    pool_y = np.array([lib.L2I[x] for x in np.load(FEATURES / 'pool_model.npy')])
    raw_pool = pd.read_parquet(ROOT / 'data/pool/ntl_open_pool.parquet')
    pool = raw_pool.loc[~raw_pool.flag_gemini37_routing_risk & raw_pool.n_words.between(30, 300)]
    pool = pool.sample(frac=1, random_state=0).groupby('model').head(200).reset_index(drop=True)
    pool_alignment = np.array_equal(pool.model.map(lib.L2I), pool_y)
    # The historical pool input is not versioned in the old cache. Never guess its alignment.
    print('CACHE AUDIT external label-order alignment:', pool_alignment,
          '; excluding all external rows from fitting.', flush=True)
    norm = lambda x: ' '.join(str(x).casefold().split())
    host_texts = set(t.text.map(norm))
    keep_pool = ~pool.text.map(norm).isin(host_texts).to_numpy()
    paths = {f'{r}_l{l}': FEATURES / f'{r}_l{l}.npy'
             for r in PLAN['readers'] for l in PLAN['layers']}
    manifest = dict(plan=PLAN, code_sha256=fingerprint(Path(__file__)),
                    train_sha256=fingerprint(ROOT / 'data/train.csv'),
                    split_md5=hashlib.md5(S.tobytes()).hexdigest(),
                    feature_sha256={k: fingerprint(p) for k, p in paths.items()},
                    pool_text_sha256=hashlib.sha256('\n'.join(pool.text).encode()).hexdigest(),
                    pool_exact_host_removed=int((~keep_pool).sum()),
                    reconstructed_pool_alignment=bool(pool_alignment),
                    note='Cached frozen feature extraction; exact upstream model revision not recorded in old cache.')
    signature = hashlib.sha256(json.dumps(manifest, sort_keys=True).encode()).hexdigest()
    manifest['signature'] = signature
    manifest['labels'] = lib.LABELS
    dump(OUT / 'manifest.json', manifest)
    progress = []
    elapsed_units = []
    selected_predictions = np.full(len(t), -1)
    anchor_predictions = np.full(len(t), -1)
    val_scores, test_scores, anchor_scores = [], [], []
    test_mask = (S == 2).any(0)
    for f in range(5):
        foldpath = OUT / f'fold{f}.json'
        if foldpath.exists():
            saved = json.loads(foldpath.read_text())
            assert saved['signature'] == signature, 'cache stale; use a new output folder'
            print('RESUME completed fold', f, flush=True)
        else:
            tr, va, te = (S[f] == i for i in (0, 1, 2))
            assert set(t.prompt_id[tr]).isdisjoint(t.prompt_id[va])
            assert set(t.prompt_id[tr]).isdisjoint(t.prompt_id[te])
            assert set(t.prompt_id[va]).isdisjoint(t.prompt_id[te])
            fit_idx = np.where(tr)[0]
            fit_y = y[tr]
            candidates = []
            predictions = {}
            fold_started = time.perf_counter()
            for key, path in paths.items():
                unit_started = time.perf_counter()
                X = np.load(path, mmap_mode='r')
                assert len(X) == len(t) + len(pool_y)
                # All learned transforms see only the rotation's gold training rows.
                scaler = StandardScaler().fit(X[fit_idx])
                A = scaler.transform(X[fit_idx]).astype(np.float32)
                pca = PCA(PLAN['pca'], svd_solver='randomized', random_state=42, iterated_power=3)
                A = pca.fit_transform(A)
                V = pca.transform(scaler.transform(X[:len(t)][va]))
                E = pca.transform(scaler.transform(X[:len(t)][te]))
                for head in PLAN['heads']:
                    model = (LinearDiscriminantAnalysis(solver='lsqr', shrinkage='auto')
                             if head == 'lda_auto' else LogisticRegression(
                                 C=float(head.split('C')[1]), max_iter=300, random_state=42))
                    model.fit(A, fit_y)
                    name = key + '_' + head
                    candidates.append(dict(name=name, train_ba=float(ba(fit_y, model.predict(A))),
                                           validation_ba=float(ba(y[va], model.predict(V)))))
                    # Scores on E are held aside. They never select a candidate.
                    predictions[name] = model.predict(E).tolist()
                del X, A, V, E, scaler, pca, model
                duration = time.perf_counter() - unit_started
                elapsed_units.append(duration)
                completed = f * len(paths) + list(paths).index(key) + 1
                eta = np.mean(elapsed_units) * (5 * len(paths) - completed)
                print(f'fold={f} reader={key} unit_s={duration:.1f} '
                      f'elapsed_s={time.perf_counter()-start:.1f} ETA_s={eta:.1f} '
                      f'best_val={max(x["validation_ba"] for x in candidates):.4f}', flush=True)
            chosen = max(candidates, key=lambda r: r['validation_ba'])
            selected = np.array(predictions[chosen['name']])
            anchor = np.array(predictions[PLAN['anchor']])
            saved = dict(signature=signature, fold=f, chosen=chosen,
                         candidates_train_validation=candidates,
                         test_indices=np.where(te)[0].tolist(),
                         selected_test_predictions=selected.tolist(), anchor_test_predictions=anchor.tolist(),
                         selected_test_ba=float(ba(y[te], selected)),
                         anchor_test_ba=float(ba(y[te], anchor)),
                         train_gold_rows=int(tr.sum()), val_rows=int(va.sum()), test_rows=int(te.sum()),
                         elapsed_s=time.perf_counter()-fold_started)
            dump(foldpath, saved)
        ix = saved['test_indices']
        selected_predictions[ix] = saved['selected_test_predictions']
        anchor_predictions[ix] = saved['anchor_test_predictions']
        val_scores.append(saved['chosen']['validation_ba'])
        test_scores.append(saved['selected_test_ba'])
        anchor_scores.append(saved['anchor_test_ba'])
        progress.append(saved)
        print('COMPLETED', f, saved['chosen']['name'], 'val', val_scores[-1],
              'test', test_scores[-1], 'anchor', anchor_scores[-1], flush=True)
    assert (selected_predictions[test_mask] >= 0).all()
    groups = t.prompt_id.to_numpy()
    prompts = np.unique(groups[test_mask])
    rows = {p: np.where(test_mask & (groups == p))[0] for p in prompts}
    rng = np.random.default_rng(20261103)
    deltas = []
    for _ in range(2000):
        ix = np.concatenate([rows[p] for p in rng.choice(prompts, len(prompts))])
        deltas.append(ba(y[ix], selected_predictions[ix]) - ba(y[ix], anchor_predictions[ix]))
    cm = confusion_matrix(y[test_mask], selected_predictions[test_mask], labels=np.arange(18))
    result = dict(signature=signature, validation_ba_mean=float(np.mean(val_scores)),
                  selected_test_ba_mean=float(np.mean(test_scores)),
                  anchor_test_ba_mean=float(np.mean(anchor_scores)),
                  selected_test_ba_pooled=float(ba(y[test_mask], selected_predictions[test_mask])),
                  anchor_test_ba_pooled=float(ba(y[test_mask], anchor_predictions[test_mask])),
                  paired_delta_ci95=np.percentile(deltas, [2.5, 97.5]).tolist(),
                  test_prompt_count=len(prompts), test_row_count=int(test_mask.sum()),
                  test_coverage=float(test_mask.mean()), elapsed_s=time.perf_counter()-start,
                  confusion_matrix=cm.tolist(),
                  class_recall=dict(zip(lib.LABELS, (cm.diagonal()/cm.sum(1)).tolist())),
                  submission_eligible=False,
                  limitation='Reused historical prompt dataset; fold-local transforms improve protocol but do not create unseen external gold.')
    dump(OUT / 'results.json', result)
    pd.DataFrame(dict(id=t.id, prompt_id=t.prompt_id, true=t.model, test_evaluated=test_mask,
                      selected_pred=selected_predictions, anchor_pred=anchor_predictions)).to_csv(OUT/'oof.csv', index=False)
    dump(OUT / 'folds.json', progress)
    print(json.dumps({k: v for k, v in result.items() if k not in ['confusion_matrix', 'class_recall']}, indent=2))


if __name__ == '__main__':
    with threadpool_limits(limits=2):
        run()
