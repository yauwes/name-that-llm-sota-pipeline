# E14b (CPU): does the regen gain survive when the SVC also trains on a large pool, as in the public ensemble? 4-view SVC, pool 2,000 per class at w .35.
import sys, json, numpy as np, pandas as pd
sys.path.insert(0, 'notebook'); import lib
from sklearn.metrics import balanced_accuracy_score as bas
t = lib.load_train('data/train.csv'); S = lib.make_splits(t); y = t.y.values; txt = np.array(t.text.tolist(), object); pr = t.prompt_id.values
p = lib.cap_pool(lib.load_pool('data/pool/ntl_open_pool.parquet'), 2000, 0)
r = pd.read_parquet('data/e14/regen.parquet'); r['y'] = r.model.map(lib.L2I)
out = {}
for f in range(5):
    tr, te = S[f] == 0, S[f] == 2; ok = r.pid.isin(set(pr[tr])).values
    for name, extra in (('host + pool', None), ('host + pool + regen', ok)):
        X = txt[tr].tolist() + p.text.tolist(); Y = np.r_[y[tr], p.y]; W = np.r_[np.ones(tr.sum()), np.full(len(p), .35)]
        if extra is not None: X += r.text[extra].tolist(); Y = np.r_[Y, r.y[extra]]; W = np.r_[W, np.ones(extra.sum())]
        out.setdefault(name, []).append(bas(y[te], lib.svc4_fit_predict(X, Y, W, txt[te].tolist()).argmax(1)))
    lib.log(f'rotation {f}', {k: round(v[-1], 4) for k, v in out.items()})
d = np.array(out['host + pool + regen']) - np.array(out['host + pool'])
res = {k: dict(mean=round(float(np.mean(v)), 4), per_rot=np.round(v, 4).tolist()) for k, v in out.items()}; res['delta'] = dict(mean=round(float(d.mean()), 4), positive=int((d > 0).sum()))
print(json.dumps(res, indent=1)); json.dump(res, open('research/experiments/regen_pool.json', 'w'), indent=1)
