# E14 (CPU proxy): community regenerations of host train prompts (data/ext rows whose topic matches a train prompt, sim >= .35),
# added to host-only SVC. Each rotation adds only rows matched to its own train prompts, so test prompts never leak.
import sys, json, numpy as np, pandas as pd
sys.path.insert(0, 'notebook'); import lib
from sklearn.feature_extraction.text import TfidfVectorizer as V
from sklearn.metrics import balanced_accuracy_score as bas

t = lib.load_train('data/train.csv'); S = lib.make_splits(t); y = t.y.values; txt = np.array(t.text.tolist(), object); pr = t.prompt_id.values
r = pd.read_parquet('data/ext/regen_candidates.parquet'); r['y'] = r.model.map(lib.L2I)
# near copies of a host passage are not new data: drop rows whose char 5-gram cosine to any train passage is >= .8
v = V(analyzer='char_wb', ngram_range=(5, 5), min_df=2, sublinear_tf=True); Xt = v.fit_transform(t.text); Xr = v.transform(r.text)
cmax = np.asarray((Xr @ Xt.T).max(1).todense()).ravel(); near = cmax >= .8
print('regen rows', len(r), '| near copies of train', int(near.sum()), '| char cos quantiles', np.round(np.quantile(cmax, [.5, .9, .99]), 3).tolist())
r = r[~near].reset_index(drop=True)
out = {}
for f in range(5):
    tr, te = S[f] == 0, S[f] == 2; ok = r.pid.isin(set(pr[tr])).values; assert not r.pid[ok].isin(set(pr[te])).any()
    base = lib.svc_fit_predict(txt[tr].tolist(), y[tr], np.ones(tr.sum()), txt[te].tolist())
    out.setdefault('host only', []).append(bas(y[te], base.argmax(1)))
    for w in (.5, 1.):
        o = lib.svc_fit_predict(txt[tr].tolist() + r.text[ok].tolist(), np.r_[y[tr], r.y[ok]], np.r_[np.ones(tr.sum()), np.full(ok.sum(), w)], txt[te].tolist())
        out.setdefault(f'host + regen w{w}', []).append(bas(y[te], o.argmax(1)))
    lib.log(f'rotation {f}: regen rows used {int(ok.sum())}', {k: round(v_[-1], 4) for k, v_ in out.items()})
res = {k: dict(mean=round(float(np.mean(v_)), 4), per_rot=np.round(v_, 4).tolist()) for k, v_ in out.items()}
for k in res:
    if k != 'host only': d = np.array(res[k]['per_rot']) - np.array(res['host only']['per_rot']); res[k]['delta'] = round(float(d.mean()), 4); res[k]['positive'] = int((d > 0).sum())
print(json.dumps(res, indent=1)); json.dump(res, open('research/experiments/regen_value.json', 'w'), indent=1)
