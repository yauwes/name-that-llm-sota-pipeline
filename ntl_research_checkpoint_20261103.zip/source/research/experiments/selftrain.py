"""iterative self-training, strict: unlabelled rows are val rows only, scored rows are test rows, never pseudo-labelled themselves. Teacher trained without test labels where possible."""
import sys,numpy as np,pandas as pd; sys.path.insert(0,'notebook'); import lib
from sklearn.decomposition import PCA
from sklearn.linear_model import LogisticRegression as LR
from sklearn.metrics import balanced_accuracy_score as bas
t=lib.load_train('data/train.csv'); S=lib.make_splits(t); y=t.y.values; N=lib.N; R='kernels/twostage/out_full/'
svc=np.load('kernels/svc4/out/members/svc4_p190k/oof.npy'); q,l=[np.load(R+f'out_{k}/oof_plain.npy') for k in ('q8','ll8')]
pl=pd.Series(t.prompt_id.unique()).sample(frac=1,random_state=42).tolist(); fold=t.prompt_id.map({p:i%5 for i,p in enumerate(pl)}).values
Z=np.zeros((len(t),32768),np.float32)
for f in range(5): Z[fold==f]=np.load(R+f'out_q8/z_fold{f}.npy').astype(np.float32)
Zp=PCA(256,random_state=0).fit_transform(Z); Zp=(Zp-Zp.mean(0))/Zp.std(0); del Z
head=lambda A,ya,w,B: LR(C=.02,max_iter=400,class_weight='balanced').fit(Zp[A],ya,sample_weight=w).decision_function(Zp[B])
R_={}
def add(k,v): R_.setdefault(k,[]).append(v)
for f in range(5):
    tr,v,te=[np.where(S[f]==i)[0] for i in (0,1,2)]; T=N(q)+N(l)+.5*N(svc[f]); add('teacher',bas(y[te],T[te].argmax(1)))
    base_te=head(tr,y[tr],np.ones(len(tr)),te); add('head host only',bas(y[te],base_te.argmax(1))); add('T+head',bas(y[te],(N(T[te])+.5*N(base_te)).argmax(1)))
    Tv=T[v]
    for it in range(3):
        P=lib.softmax(N(Tv)*1.5); k=np.argsort(-P.max(1))[:int(len(v)*.5)]; A=np.r_[tr,v[k]]; ya=np.r_[y[tr],P[k].argmax(1)]; w=np.r_[np.ones(len(tr)),np.full(len(k),.5)]
        s_te=head(A,ya,w,te); s_v=head(A,ya,w,v); add(f'it{it} student',bas(y[te],s_te.argmax(1))); add(f'it{it} T+student',bas(y[te],(N(T[te])+.5*N(s_te)).argmax(1)))
        Tv=N(T[v])+.5*N(s_v)
for k,v in R_.items(): print(f'{k:20s} {np.mean(v):.4f} sd {np.std(v):.4f}')
