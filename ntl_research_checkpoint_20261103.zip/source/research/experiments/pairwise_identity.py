"""E34: same-SOURCE verifier, distinct from E30/E33 same-PROMPT grouping.

Inspired by the author-reported public0.667 pairwise recipe, not a reproduction:
no external cue annotations, only provenanced frozen features and gold text.
Fit96prompts, select head by24prompt source logloss, refit120, test30. Fusion
alpha0.1 fixed beforehand; legacy outer-LoRA logits never select inner settings.
"""
import os
os.environ.setdefault('OMP_NUM_THREADS','2')
os.environ.setdefault('OPENBLAS_NUM_THREADS','2')
import hashlib
import json
import re
import time
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from scipy.special import softmax
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import balanced_accuracy_score as ba,log_loss
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from threadpoolctl import threadpool_limits

from spectral_reader import ROOT,FEATURE as READER,LAYERS,sha,dump
from partial_group_audit import paired_interval
import lib

OUT=ROOT/'research/experiments/e34_pairwise_identity'
STYLE=ROOT/'data/features/e25_styledistance'
SEM=ROOT/'data/features/e30_semantic_groups'
PLAN=dict(outer='seed42fivefold120train/30testprompts',inner='96fit/24select, prompt-disjoint',
    pairs_positive=18000,pairs_negative=18000,negative_mixture='equal same-prompt, within-provider, cross-provider',
    positive='same model, different prompt',refs_per_class=6,reference='fixedseed random train rows; no source-logit ranking',
    candidates=['LR_C.035','LR_C.35','LR_C3.5','HGB200leaf15'],selection='inner source-class logloss, no outer-label or outer-LoRA tuning',
    alpha=.1,refit='Refit pair head and train-only TFIDF on all120outertrain prompts; no inner head reuse',
    features=['StyleDistance_cos','Qwen_DC16_cos','MiniLM_semantic_cos','char_TFIDF_cos','word_TFIDF_cos',
        'StyleDistance_mean_absdiff','Qwen_DC16_mean_absdiff','abs_log_wordcount_ratio','punct_L1','punct_Linf'],
    source='https://www.kaggle.com/code/alexchilton/name-that-llm-0-667-all-public-what-failed',
    limitation='Adaptation without public annotation dataset; historical inspected gold, old LoRA OOF provenance; not champion CV')


def unit(x):return x/np.maximum(np.linalg.norm(x,axis=1,keepdims=True),1e-12)


def pairs(ix,y,groups,seed):
    rng=np.random.default_rng(seed);P=PLAN['pairs_positive'];n=P//3
    byclass=[ix[y[ix]==k] for k in range(18)];gp=np.unique(groups[ix]);bygroup=[ix[groups[ix]==g] for g in gp]
    positives=[]
    for k in rng.integers(0,18,P):
        a,b=rng.choice(byclass[k],2,replace=False);assert groups[a]!=groups[b];positives.append((a,b))
    negatives=[]
    for g in rng.integers(0,len(gp),n):
        a,b=rng.choice(bygroup[g],2,replace=False);assert y[a]!=y[b];negatives.append((a,b))
    while len(negatives)<2*n:
        a,b=rng.choice(ix,2,replace=False)
        if y[a]!=y[b] and lib.FAM[y[a]]==lib.FAM[y[b]]:negatives.append((a,b))
    while len(negatives)<3*n:
        a,b=rng.choice(ix,2,replace=False)
        if lib.FAM[y[a]]!=lib.FAM[y[b]]:negatives.append((a,b))
    p=np.array(positives+negatives);target=np.r_[np.ones(P),np.zeros(3*n)].astype(np.int8)
    assert np.array_equal(y[p[:,0]]==y[p[:,1]],target.astype(bool))
    return p[:,0],p[:,1],target


def references(ix,y,seed):
    rng=np.random.default_rng(seed)
    return np.stack([rng.choice(ix[y[ix]==k],PLAN['refs_per_class'],replace=False) for k in range(18)])


class PairSpace:
    def __init__(self,texts,dense,length,punct,ix):
        self.dense=dense;self.length=length;self.punct=punct;self.vec=[];self.sparse=[]
        for kw in [dict(analyzer='char_wb',ngram_range=(3,5),max_features=40000),
                   dict(analyzer='word',ngram_range=(1,2),max_features=30000)]:
            v=TfidfVectorizer(min_df=2,sublinear_tf=True,dtype=np.float32,**kw).fit([texts[i] for i in ix])
            self.vec.append(v);self.sparse.append(v.transform(texts))

    def features(self,a,b):
        result=[]
        for start in range(0,len(a),2048):
            i,j=a[start:start+2048],b[start:start+2048]
            columns=[np.einsum('ij,ij->i',x[i],x[j]) for x in self.dense]
            columns += [np.asarray(x[i].multiply(x[j]).sum(axis=1)).ravel() for x in self.sparse]
            columns += [np.abs(x[i]-x[j]).mean(1) for x in self.dense[:2]]
            pdiff=np.abs(self.punct[i]-self.punct[j])
            columns += [np.abs(self.length[i]-self.length[j]),pdiff.sum(1),pdiff.max(1)]
            result.append(np.column_stack(columns).astype(np.float32))
        X=np.concatenate(result);assert X.shape==(len(a),10) and np.isfinite(X).all();return X


def source_scores(head,space,targets,refs,groups,exclude_same_prompt=False):
    flat=refs.ravel();a=np.repeat(targets,len(flat));b=np.tile(flat,len(targets))
    features=space.features(a,b)
    if hasattr(head,'decision_function'):raw=head.decision_function(features)
    else:
        p=np.clip(head.predict_proba(features)[:,1],1e-6,1-1e-6);raw=np.log(p/(1-p))
    score=raw.reshape(len(targets),18,PLAN['refs_per_class'])
    if exclude_same_prompt:
        mask=groups[targets,None,None]!=groups[refs][None,:,:]
        assert mask.sum(2).min()>0;score=(score*mask).sum(2)/mask.sum(2)
    else:score=score.mean(2)
    return score


def candidates():
    return {**{f'LR_C{c}':make_pipeline(StandardScaler(),LogisticRegression(C=c,max_iter=2000,random_state=42)) for c in [.035,.35,3.5]},
        'HGB200leaf15':HistGradientBoostingClassifier(max_iter=200,max_leaf_nodes=15,learning_rate=.05,l2_regularization=1.,early_stopping=False,random_state=42)}


def run():
    begin=time.perf_counter();OUT.mkdir(exist_ok=True);t=lib.load_train(ROOT/'data/train.csv')
    texts=t.text.tolist();y=t.y.to_numpy();groups=t.prompt_id.to_numpy()
    dense=[]
    for p in [STYLE,READER,SEM]:
        assert np.load(p/'done.npy').all() and np.array_equal(np.load(p/'id.npy'),t.id.astype(str))
        assert np.array_equal(np.load(p/'text_sha256.npy'),[hashlib.sha256(s.encode()).hexdigest() for s in texts])
        a=np.load(p/'features.npy',mmap_mode='r')
        if p==READER:a=a[:,LAYERS.index(16),0,:]
        dense.append(unit(np.asarray(a,dtype=np.float32)))
    length=np.log1p(t.text.str.split().str.len().to_numpy())
    punct=np.array([[s.count(c)/max(len(s),1)*100 for c in ['—',';',':','!','?','(',')','\n','*','"']] for s in texts],dtype=np.float32)
    q,l=[np.load(ROOT/f'kernels/twostage/out_full/out_{n}/oof_plain.npy') for n in ['q8','ll8']];base=lib.N((lib.N(q)+lib.N(l))/2)
    prompts=pd.Series(t.prompt_id.unique()).sample(frac=1,random_state=42).tolist();fold=t.prompt_id.map({p:i%5 for i,p in enumerate(prompts)}).to_numpy()
    manifest=dict(plan=PLAN,code_sha256=sha(Path(__file__)),train_sha256=sha(ROOT/'data/train.csv'),
        features={str(p.relative_to(ROOT)):dict(manifest_sha256=sha(p/'manifest.json'),feature_sha256=sha(p/'features.npy')) for p in [STYLE,READER,SEM]},
        logits={n:sha(ROOT/f'kernels/twostage/out_full/out_{n}/oof_plain.npy') for n in ['q8','ll8']})
    signature=hashlib.sha256(json.dumps(manifest,sort_keys=True).encode()).hexdigest();mf=OUT/'manifest.json'
    if mf.exists():assert json.loads(mf.read_text())['signature']==signature,'Stale E34 cache'
    else:dump(mf,dict(manifest,signature=signature))
    prediction={k:np.full(len(t),-1) for k in ['baseline','verifier','fusion']};folds=[]
    for f in range(5):
        fp=OUT/f'fold{f}.json'
        if fp.exists():r=json.loads(fp.read_text());assert r['signature']==signature
        else:
            start=time.perf_counter();tr=np.flatnonzero(fold!=f);te=np.flatnonzero(fold==f)
            train_prompts=np.array([p for p in prompts if p in set(groups[tr])]);val_prompts=train_prompts[::5]
            fit=tr[~np.isin(groups[tr],val_prompts)];va=tr[np.isin(groups[tr],val_prompts)]
            assert len(np.unique(groups[fit]))==96 and len(np.unique(groups[va]))==24
            space=PairSpace(texts,dense,length,punct,fit);a,b,target=pairs(fit,y,groups,20263400+f)
            F=space.features(a,b);refs=references(fit,y,20263410+f);trials=[];models=candidates()
            # Cache validation pair features once: all candidates use identical references.
            flat=refs.ravel();V=space.features(np.repeat(va,len(flat)),np.tile(flat,len(va)))
            best=None
            for name,head in models.items():
                head.fit(F,target)
                if hasattr(head,'decision_function'):
                    if name!='HGB200leaf15':assert head[-1].n_iter_.max()<2000
                    raw=head.decision_function(V)
                else:
                    p=np.clip(head.predict_proba(V)[:,1],1e-6,1-1e-6);raw=np.log(p/(1-p))
                score=raw.reshape(len(va),18,PLAN['refs_per_class']).mean(2)
                trial=dict(name=name,val_source_ba=float(ba(y[va],score.argmax(1))),val_source_logloss=float(log_loss(y[va],softmax(score,axis=1),labels=np.arange(18))),
                    train_pair_logloss=float(log_loss(target,head.predict_proba(F))))
                trials.append(trial)
                if best is None or trial['val_source_logloss']<best['val_source_logloss']:best=trial
            del space,F,V,models
            space=PairSpace(texts,dense,length,punct,tr);a,b,target=pairs(tr,y,groups,20263420+f)
            head=candidates()[best['name']].fit(space.features(a,b),target)
            if best['name']!='HGB200leaf15':assert head[-1].n_iter_.max()<2000
            refs=references(tr,y,20263430+f)
            test_scores=source_scores(head,space,te,refs,groups)
            train_scores=source_scores(head,space,tr,refs,groups,exclude_same_prompt=True)
            pred=dict(baseline=base[te].argmax(1),verifier=test_scores.argmax(1),fusion=(base[te]+PLAN['alpha']*lib.N(test_scores)).argmax(1))
            r=dict(signature=signature,fold=f,chosen=best,trials=trials,train_prompts=120,fit_prompts=96,val_prompts=24,test_prompts=30,
                refit_train_source_ba_excluding_same_prompt_refs=float(ba(y[tr],train_scores.argmax(1))),
                test={k:float(ba(y[te],p)) for k,p in pred.items()},test_indices=te.tolist(),prediction={k:p.tolist() for k,p in pred.items()},elapsed_s=time.perf_counter()-start)
            lib.atomic(OUT/f'verifier_fold{f}.joblib',lambda h:joblib.dump(dict(signature=signature,head=head,vectorizers=space.vec,reference_indices=refs,
                labels=lib.LABELS,feature_plan=PLAN,training_indices=tr),h));dump(fp,r)
        for k in prediction:prediction[k][r['test_indices']]=r['prediction'][k]
        folds.append(r);elapsed=time.perf_counter()-begin
        print(f'fold={f} chosen={r["chosen"]["name"]} val={r["chosen"]["val_source_ba"]:.5f} test={r["test"]} elapsed_s={elapsed:.1f} ETA_s={elapsed/(f+1)*(4-f):.1f}',flush=True)
    assert all((p>=0).all() for p in prediction.values())
    result=dict(signature=signature,mean_test={k:float(np.mean([r['test'][k] for r in folds])) for k in prediction},
        pooled_test={k:float(ba(y,p)) for k,p in prediction.items()},
        fusion_minus_baseline=paired_interval(y,prediction['baseline'],prediction['fusion'],groups),
        positive_folds=sum(r['test']['fusion']>r['test']['baseline'] for r in folds),
        elapsed_s=time.perf_counter()-begin,submission_eligible=False,
        conclusion='Source-verifier adaptation on historical gold; no measured improvement over the official0.665 champion.')
    dump(OUT/'results.json',result);print(json.dumps(result,indent=2),flush=True)


if __name__=='__main__':
    with threadpool_limits(limits=2):run()
