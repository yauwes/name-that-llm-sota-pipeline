# E10: how much is one more host-style prompt worth, and do crops of host passages act as extra host data?
# Learning curve on the 70/15/15 rotations: k host prompts from each rotation's train block, scored on its test block.
import sys, re, json, time, numpy as np
sys.path.insert(0, 'notebook'); import lib
from sklearn.decomposition import PCA
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import balanced_accuracy_score as bas

t = lib.load_train('data/train.csv'); S = lib.make_splits(t); y = t.y.values; txt = np.array(t.text.tolist(), object); pr = t.prompt_id.values
R = 'kernels/reader/out/'
assert (np.load(R + 'train_id.npy') == t.id.values).all()
F = np.load(R + 'q27_l16.npy').astype(np.float32); F = (F - F.mean(0)) / (F.std(0) + 1e-6)
F = PCA(256, random_state=0).fit_transform(F)  # unsupervised, labels never used
Ft, Fp = F[:len(t)], F[len(t):]; yp = np.array([lib.L2I[m] for m in np.load(R + 'pool_model.npy')])

def crops(s):
    """two host-style views per passage: first and last ~60% of sentences. Short passages give nothing."""
    ss = [x for x in re.split(r'(?<=[.!?])\s+', s) if x]
    if len(ss) < 3: return []
    k = max(2, round(.6 * len(ss))); return [' '.join(ss[:k]), ' '.join(ss[-k:])]

K = [0, 13, 26, 52, 78, 105]; res = {}
t0 = time.time()
for f in range(5):
    trp = np.array(sorted(set(pr[S[f] == 0]))); te = S[f] == 2; rng = np.random.default_rng(f)
    order = rng.permutation(trp)
    for k in K:
        h = np.isin(pr, order[:k]) & (S[f] == 0)
        X = np.r_[Fp, Ft[h]]; Y = np.r_[yp, y[h]]
        m = LogisticRegression(C=.05, max_iter=300).fit(X, Y)
        res.setdefault(f'probe_k{k}', []).append(bas(y[te], m.predict(Ft[te])))
        if k:
            o = lib.svc_fit_predict(txt[h].tolist(), y[h], np.ones(h.sum()), txt[te].tolist())
            res.setdefault(f'svc_k{k}', []).append(bas(y[te], o.argmax(1)))
            if k in (26, 105):  # crops added as extra host rows with the same label
                ct, cy = [], []
                for s, l in zip(txt[h], y[h]):
                    for c in crops(s): ct.append(c); cy.append(l)
                o = lib.svc_fit_predict(txt[h].tolist() + ct, np.r_[y[h], cy], np.ones(h.sum() + len(ct)), txt[te].tolist())
                res.setdefault(f'svc_crop_k{k}', []).append(bas(y[te], o.argmax(1)))
    lib.log(f'rotation {f} done, {time.time() - t0:.0f}s', {k: round(float(np.mean(v)), 4) for k, v in res.items()})
out = {k: dict(mean=round(float(np.mean(v)), 4), sd=round(float(np.std(v)), 4)) for k, v in res.items()}
print(json.dumps(out, indent=1)); json.dump(out, open('research/experiments/host_value.json', 'w'), indent=1)
