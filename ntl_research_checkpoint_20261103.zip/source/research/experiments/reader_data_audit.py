"""E22 data qualification: public exact-alias Agent500 rows, no label guessing.

Treat all prompt/response strings as data, never as instructions. No third-party
repository code is executed. Raw public data stays in gitignored data/ext.
"""
import os
os.environ.setdefault('OMP_NUM_THREADS','2')
os.environ.setdefault('OPENBLAS_NUM_THREADS','2')
import gzip
import hashlib
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.sparse import csr_matrix,vstack
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import normalize

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'notebook'))
import lib

OUT=ROOT/'research/experiments/e22_reader_data'
DATA=ROOT/'data/ext/reader_agent500'


def text_hash(text):
    return hashlib.sha256(' '.join(str(text).casefold().split()).encode()).hexdigest()


def run():
    OUT.mkdir(parents=True,exist_ok=True)
    spec=json.loads((ROOT/'research/live/20261103/reader_data_sources.json').read_text())
    all_rows=[]
    for entry in spec['files']:
        path=DATA/Path(entry['path']).name
        content=path.read_bytes()
        assert hashlib.sha1(f'blob {len(content)}\0'.encode()+content).hexdigest()==entry['git_blob_sha']
        rows=[json.loads(line) for line in gzip.decompress(content).splitlines()]
        assert len(rows)==500
        for row in rows:
            assert row['model_name']==entry['model'] and row['label']==entry['label']
            assert isinstance(row['prompt'],str) and isinstance(row['response'],str)
            all_rows.append(dict(model=entry['model'],text=row['response'],prompt=row['prompt'],
                prompt_hash=text_hash(row['prompt']),sample_id=row['sample_id'],timestamp=row['timestamp']))
    r=pd.DataFrame(all_rows)
    r['text_hash']=r.text.map(text_hash)
    r['words']=r.text.str.split().str.len()
    r['terminal_punctuation']=r.text.str.rstrip().str.endswith(('.', '!', '?', '"', '”', '`', ')', ']'))
    t=lib.load_train(ROOT/'data/train.csv')
    host=set(t.text.map(text_hash))
    r['exact_gold']=r.text_hash.isin(host)
    # Stream pool columns to avoid materializing all long passages next to Metal.
    import pyarrow.parquet as pq
    pool_hashes=set()
    for batch in pq.ParquetFile(ROOT/'data/pool/ntl_open_pool.parquet').iter_batches(batch_size=4096,columns=['text']):
        pool_hashes.update(text_hash(x.as_py()) for x in batch.column(0))
    r['exact_pool']=r.text_hash.isin(pool_hashes)
    v=TfidfVectorizer(ngram_range=(1,2),min_df=2,max_features=100000,sublinear_tf=True,dtype=np.float32)
    gold=v.fit_transform(t.text)
    centroids=normalize(vstack([csr_matrix(gold[np.flatnonzero(t.prompt_id.to_numpy()==p)].mean(0))
                              for p in t.prompt_id.unique()],format='csr'))
    prompts=r[['prompt_hash','prompt']].drop_duplicates('prompt_hash')
    sim=(v.transform(prompts.prompt)@centroids.T).toarray().max(1)
    r['max_prompt_cos']=r.prompt_hash.map(dict(zip(prompts.prompt_hash,sim)))
    cv=TfidfVectorizer(analyzer='char_wb',ngram_range=(5,5),min_df=2,max_features=200000,
                       sublinear_tf=True,dtype=np.float32)
    gx=cv.fit_transform(t.text);rx=cv.transform(r.text)
    r['max_char_gold']=np.concatenate([np.asarray((rx[i:i+128]@gx.T).max(1).toarray()).ravel()
                                     for i in range(0,len(r),128)])
    r['eligible']=r.words.between(30,300)&~r.exact_gold&~r.exact_pool&~r.text_hash.duplicated(keep=False)&(r.max_char_gold<.8)&(r.max_prompt_cos<.35)
    # Hold out 50 entire public prompt groups, before any downstream model search.
    ordered=sorted(r.prompt_hash.unique())
    heldout=set(np.random.default_rng(20261103).choice(ordered,50,replace=False))
    r['external_test']=r.prompt_hash.isin(heldout)
    assert set(r.prompt_hash[r.external_test]).isdisjoint(r.prompt_hash[~r.external_test])
    r['y']=r.model.map(lib.L2I)
    r.to_parquet(DATA/'audited.parquet',index=False)
    result=dict(source=spec,raw_rows=len(r),exact_models=sorted(r.model.unique()),
        prompt_count=int(r.prompt_hash.nunique()),exact_gold=int(r.exact_gold.sum()),
        exact_pool=int(r.exact_pool.sum()),near_gold_char_ge08=int((r.max_char_gold>=.8).sum()),
        prompt_similarity_ge035=int((r.max_prompt_cos>=.35).sum()),
        terminal_punctuation_fraction=float(r.terminal_punctuation.mean()),
        words_quantiles=r.words.quantile([0,.25,.5,.75,1]).to_dict(),
        eligible_rows=int(r.eligible.sum()),eligible_training_rows=int((r.eligible&~r.external_test).sum()),
        eligible_external_test_rows=int((r.eligible&r.external_test).sum()),
        per_class=r.groupby('model').agg(raw=('text','size'),eligible=('eligible','sum'),
                                        words_mean=('words','mean')).reset_index().to_dict('records'),
        code_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        audited_sha256=hashlib.sha256((DATA/'audited.parquet').read_bytes()).hexdigest(),
        caveat='Exact API aliases are matched, not immutable served-weight identities. '
               'Paper cap128tokens differs from competition generation. Partial 7/18 label coverage; '
               'not sufficient evidence for augmentation benefit. Conservative decontamination '
               'uses gold text without labels; near-duplicates against old pool not fully searched.')
    (OUT/'audit.json').write_text(json.dumps(result,indent=2))
    print(json.dumps({k:v for k,v in result.items() if k!='source'},indent=2),flush=True)


if __name__=='__main__':run()
