# E13: soft label repulsion inside recovered prompt clusters, a soft Hungarian. Passages of one prompt come from different models,
# so each passage's logit for class c drops by lam * sum over its cluster mates of -log(1 - p_mate(c)).
# Simulated like the hidden test: k passages per prompt, clusters recovered by TF-IDF over the sampled rows, lam chosen on val sims.
import sys, json, numpy as np, pandas as pd
sys.path.insert(0, 'notebook'); import lib
from sklearn.metrics import balanced_accuracy_score as bas

t = lib.load_train('data/train.csv'); S = lib.make_splits(t); y = t.y.values; txt = t.text.values; pr = t.prompt_id.values
def rot(o):
    z = np.stack([o] * 5).astype(np.float32)
    for f in range(5): z[f, S[f] == 0] = np.nan
    return z
R = 'kernels/twostage/out_full/'
Ls = [rot(np.load(R + 'out_q8/oof_plain.npy')), rot(np.load(R + 'out_ll8/oof_plain.npy')), np.load('kernels/svc4/out/members/svc4_p190k/oof.npy').astype(np.float32)]

def repel(L, groups, lam, it=3):
    X = L.copy()
    for _ in range(it):
        P = lib.softmax(X); pen = np.zeros_like(X); lg = -np.log(np.clip(1 - P, 1e-6, 1))
        for g in np.unique(groups):
            i = np.where(groups == g)[0]
            if len(i) > 1: pen[i] = lg[i].sum(0) - lg[i]
        X = L - lam * pen
    return X

def sims(mask, k, seed):
    """k random passages per prompt among mask rows, then clusters recovered from text alone."""
    rng = np.random.RandomState(seed); rows = []
    for _, ix in pd.Series(np.where(mask)[0]).groupby(pr[mask]): rows += list(rng.choice(ix.values, min(k, len(ix)), replace=False))
    rows = np.array(sorted(rows)); return rows, lib.test_groups(txt[rows].tolist())

LAMS = (0., .25, .5, 1., 2.); out = {}
for k in (2, 3):
    for f in range(5):
        v, te = S[f] == 1, S[f] == 2; ch, w = lib.select_stack([l[f][v] for l in Ls], y[v])
        B = np.zeros((len(y), 18)); B[v] = lib.blend([Ls[j][f][v] for j in ch], w); B[te] = lib.blend([Ls[j][f][te] for j in ch], w)
        sv = [sims(v, k, s) for s in range(4)]; st = [sims(te, k, 10 + s) for s in range(4)]
        val = {lam: np.mean([bas(y[r], repel(B[r], g, lam).argmax(1)) for r, g in sv]) for lam in LAMS}; lam = max(val, key=val.get)
        for name, l_ in (('base', 0.), ('chosen', lam), ('lam0.5', .5)):
            out.setdefault(f'k{k} {name}', []).append(np.mean([bas(y[r], repel(B[r], g, l_).argmax(1)) for r, g in st]))
        out.setdefault(f'k{k} lam', []).append(lam)
    lib.log(f'k={k}', {n: np.round(v_, 4).tolist() for n, v_ in out.items() if n.startswith(f'k{k}')})
res = {n: dict(mean=round(float(np.mean(v_)), 4), per_rot=np.round(v_, 4).tolist()) for n, v_ in out.items()}
print(json.dumps(res, indent=1)); json.dump(res, open('research/experiments/repulsion.json', 'w'), indent=1)
