"""E38: nonlinear class-confusion patterns in external-only stage1 scores.

Same prompt outer/inner folds as E27/E37; no outer-LoRA scores used for fitting
or inner selection. Compare matched linear/RBF SVC, then fixed-alpha0.1 fusion
with heldout outer-stage2 LoRA comparator. Old score-cache provenance caveat
remains; this is a head experiment, not newly trained/verified stage1 backbones.
"""
import os
os.environ.setdefault('OMP_NUM_THREADS','2')
os.environ.setdefault('OPENBLAS_NUM_THREADS','2')
import hashlib
import json
import time
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from scipy.special import softmax
from sklearn.metrics import balanced_accuracy_score as ba,log_loss
from sklearn.preprocessing import StandardScaler,normalize
from sklearn.svm import SVC
from threadpoolctl import threadpool_limits

from spectral_reader import ROOT,sha,dump
from partial_group_audit import paired_interval
import lib

OUT=ROOT/'research/experiments/e38_nonlinear_score_head'
PLAN=dict(feature='Concatenated per-row-normalized external-only stage1q8+ll8 scores,36dimensions',
    outer='seed42fivefold120train/30test prompts',inner='96fit/24select',
    transform='train-only StandardScaler then rowL2, refit on120 after selection',
    C=[.3,3.,30.],gamma=[.1,1.,10.],families=['linear','rbf'],
    selection='highest inner balanced accuracy, normalized-score logloss for ties; choose family there too',
    class_weight='balanced',decision='18class OVR scores with break_ties=True, probability=False',
    alpha=.1,negative_control='One fixed RBF_C3_gamma1 with fit labels permuted within TRAINING prompt; not selected',
    scope='Historical gold and legacy external-stage1 caches; source/OOF scope follows archivedworker, incomplete original row/revision manifests',
    deployment='Need original stage1backbone/adapters and score-ABI parity before serving. No direct notebook submission.')


def make_head(kernel,C,gamma='scale'):
    return SVC(kernel=kernel,C=C,gamma=gamma,class_weight='balanced',break_ties=True,decision_function_shape='ovr',cache_size=128)


def run():
    start=time.perf_counter();OUT.mkdir(exist_ok=True);t=lib.load_train(ROOT/'data/train.csv');y=t.y.to_numpy();groups=t.prompt_id.to_numpy()
    p1=[ROOT/f'kernels/twostage/out_full/out_{n}/s1_plain.npy' for n in ['q8','ll8']]
    p2=[ROOT/f'kernels/twostage/out_full/out_{n}/oof_plain.npy' for n in ['q8','ll8']]
    q,l,q2,l2=[np.load(p) for p in p1+p2]
    assert all(a.shape==(len(t),18) and np.isfinite(a).all() for a in [q,l,q2,l2])
    X=np.concatenate([lib.N(q),lib.N(l)],axis=1);base=lib.N((lib.N(q2)+lib.N(l2))/2)
    external=lib.N((lib.N(q)+lib.N(l))/2)
    prompts=pd.Series(t.prompt_id.unique()).sample(frac=1,random_state=42).tolist();fold=t.prompt_id.map({p:i%5 for i,p in enumerate(prompts)}).to_numpy()
    worker=ROOT/'kernels/twostage/out_full/worker.py'
    manifest=dict(plan=PLAN,code_sha256=sha(Path(__file__)),train_sha256=sha(ROOT/'data/train.csv'),
        worker_sha256=sha(worker),inputs={str(p.relative_to(ROOT)):sha(p) for p in p1+p2},labels=lib.LABELS)
    signature=hashlib.sha256(json.dumps(manifest,sort_keys=True).encode()).hexdigest();mf=OUT/'manifest.json'
    if mf.exists():assert json.loads(mf.read_text())['signature']==signature,'Stale E38 cache'
    else:dump(mf,dict(manifest,signature=signature))
    records=[]
    for f in range(5):
        fp=OUT/f'fold{f}.json'
        if fp.exists():r=json.loads(fp.read_text());assert r['signature']==signature
        else:
            began=time.perf_counter();tr=np.flatnonzero(fold!=f);te=np.flatnonzero(fold==f)
            tp=np.array([p for p in prompts if p in set(groups[tr])]);vp=tp[::5]
            fit=tr[~np.isin(groups[tr],vp)];va=tr[np.isin(groups[tr],vp)]
            scaler=StandardScaler().fit(X[fit]);A,V=[normalize(scaler.transform(X[ix])) for ix in [fit,va]]
            trials=[];best={}
            for kernel in PLAN['families']:
                for C in PLAN['C']:
                    for gamma in PLAN['gamma'] if kernel=='rbf' else ['scale']:
                        head=make_head(kernel,C,gamma).fit(A,y[fit]);assert head.fit_status_==0
                        score=head.decision_function(V)
                        trial=dict(kernel=kernel,C=C,gamma=gamma,val_ba=float(ba(y[va],score.argmax(1))),
                            val_normalized_logloss=float(log_loss(y[va],softmax(lib.N(score),axis=1),labels=np.arange(18))))
                        trials.append(trial)
                        key=lambda z:(-z['val_ba'],z['val_normalized_logloss'])
                        if kernel not in best or key(trial)<key(best[kernel]):best[kernel]=trial
            chosen=min(best,key=lambda k:(-best[k]['val_ba'],best[k]['val_normalized_logloss']))
            scaler=StandardScaler().fit(X[tr]);A,E=[normalize(scaler.transform(X[ix])) for ix in [tr,te]]
            pred=dict(baseline=base[te].argmax(1),external_mean=external[te].argmax(1));heads={};train_scores={}
            for name,cfg in best.items():
                head=make_head(cfg['kernel'],cfg['C'],cfg['gamma']).fit(A,y[tr]);assert head.fit_status_==0
                score=head.decision_function(E);pred[name]=score.argmax(1);pred[name+'_fusion']=(base[te]+PLAN['alpha']*lib.N(score)).argmax(1)
                train_scores[name]=float(ba(y[tr],head.decision_function(A).argmax(1)));heads[name]=head
            pred['selected']=pred[chosen];pred['selected_fusion']=pred[chosen+'_fusion']
            random_y=y[tr].copy();rng=np.random.default_rng(20263800+f)
            for p in np.unique(groups[tr]):
                ii=np.flatnonzero(groups[tr]==p);random_y[ii]=rng.permutation(random_y[ii])
            control=make_head('rbf',3.,1.).fit(A,random_y);pred['label_permutation_control']=control.decision_function(E).argmax(1)
            r=dict(signature=signature,fold=f,chosen=chosen,best=best,trials=trials,train_ba=train_scores,
                test={k:float(ba(y[te],p)) for k,p in pred.items()},test_indices=te.tolist(),prediction={k:p.tolist() for k,p in pred.items()},elapsed_s=time.perf_counter()-began)
            lib.atomic(OUT/f'heads_fold{f}.joblib',lambda h:joblib.dump(dict(signature=signature,scaler=scaler,heads=heads,chosen=chosen,
                labels=lib.LABELS,training_indices=tr,all_gold_ids=t.id.astype(str).to_numpy()),h));dump(fp,r)
        records.append(r);elapsed=time.perf_counter()-start
        print('fold',f,'chosen',r['chosen'],'test',r['test'],'elapsed_s',round(elapsed,1),'ETA_s',round(elapsed/(f+1)*(4-f),1),flush=True)
    ix=np.concatenate([r['test_indices'] for r in records]);p={k:np.concatenate([r['prediction'][k] for r in records]) for k in records[0]['prediction']}
    result=dict(signature=signature,mean_test={k:float(np.mean([r['test'][k] for r in records])) for k in p},
        pooled_test={k:float(ba(y[ix],v)) for k,v in p.items()},
        intervals={b+' minus '+a:paired_interval(y[ix],p[a],p[b],groups[ix]) for a,b in [('baseline','selected_fusion'),('linear_fusion','rbf_fusion')]},
        positive_folds=sum(r['test']['selected_fusion']>r['test']['baseline'] for r in records),elapsed_s=time.perf_counter()-start,
        submission_eligible=False,conclusion='Head-only nonlinear ablation on historical caches, not champion CV or a validated new leaderboard gain.')
    dump(OUT/'results.json',result);print(json.dumps(result,indent=2),flush=True)


if __name__=='__main__':
    with threadpool_limits(limits=2):run()
