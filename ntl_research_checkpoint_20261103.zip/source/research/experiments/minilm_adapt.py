"""E37: local source-class adaptation of MiniLM's final two encoder layers.

No external pool or pseudo-labels. Prompt-disjoint inner epoch selection, then
refit outer train from the same pretrained initialization. Alpha0.1 fixed before
test. First run --smoke; it discards training weights and reports no accuracy.
"""
import os
os.environ.setdefault('TOKENIZERS_PARALLELISM','false')
os.environ.setdefault('OMP_NUM_THREADS','2')
os.environ.setdefault('OPENBLAS_NUM_THREADS','2')
import argparse
import hashlib
import json
import math
import time
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from torch import nn
from sklearn.metrics import balanced_accuracy_score as ba,log_loss
from transformers import AutoModel,AutoTokenizer
from threadpoolctl import threadpool_limits

from spectral_reader import ROOT,sha,dump
from partial_group_audit import paired_interval
import lib

OUT=ROOT/'research/experiments/e37_minilm_adapt'
MODEL=ROOT/'data/models/MiniLM-L6-v2'
PLAN=dict(backbone='sentence-transformers/all-MiniLM-L6-v2',revision='1110a243fdf4706b3f48f1d95db1a4f5529b4d41',
    train_layers=[4,5],indexing='zero-based last2of6',max_tokens=384,batch=8,accumulate=4,epochs=8,
    patience=3,min_epochs=4,lr_encoder=3e-5,lr_head=5e-4,weight_decay=.01,warmup_fraction=.1,
    dropout_head=.1,encoder_dropout='eval mode even during training; gradients still enabled',
    selection='inner96fit/24val by source logloss; refit all120 for selected epochs, scheduler keeps8epoch horizon',
    alpha=.1,precision='float32 model/training, no autocast',
    data='Gold only; no external raw data/pseudo labels; no prompt IDs at inference',
    note='Historical inspected gold, legacy LoRA comparator provenance. Local experiment, not guaranteed champion gain.')


def checkpoint(path,obj):lib.atomic(path,lambda h:torch.save(obj,h))


class SourceModel(nn.Module):
    def __init__(self,device,seed):
        super().__init__();torch.manual_seed(seed)
        if device=='mps':torch.mps.manual_seed(seed)
        self.encoder=AutoModel.from_pretrained(MODEL,local_files_only=True,trust_remote_code=False,
            dtype=torch.float32,attn_implementation='sdpa')
        assert len(self.encoder.encoder.layer)==6
        self.encoder.requires_grad_(False)
        for i in PLAN['train_layers']:self.encoder.encoder.layer[i].requires_grad_(True)
        self.head=nn.Sequential(nn.Dropout(PLAN['dropout_head']),nn.Linear(384,18))
        self.to(device);self.encoder.eval()

    def forward(self,batch):
        h=self.encoder(**batch).last_hidden_state.float();mask=batch['attention_mask'].unsqueeze(-1)
        z=(h*mask).sum(1)/mask.sum(1)
        return self.head(z)

    def delta(self):
        return dict(encoder={k:v.detach().cpu().clone() for k,v in self.encoder.named_parameters() if v.requires_grad},
            head={k:v.detach().cpu().clone() for k,v in self.head.state_dict().items()})

    def load_delta(self,state):
        p=dict(self.encoder.named_parameters())
        assert set(state['encoder'])=={k for k,v in p.items() if v.requires_grad}
        with torch.no_grad():
            for k,v in state['encoder'].items():p[k].copy_(v.to(p[k].device))
        self.head.load_state_dict(state['head'])


def batch(tok,token,ix,device):
    return tok.pad({k:[v[i] for i in ix] for k,v in token.items()},return_tensors='pt').to(device)


@torch.no_grad()
def predict(model,tok,token,ix,device):
    model.encoder.eval();model.head.eval();out=[]
    for s in range(0,len(ix),PLAN['batch']):out.append(model(batch(tok,token,ix[s:s+PLAN['batch']],device)).cpu().numpy())
    a=np.concatenate(out);assert np.isfinite(a).all();return a


def fit(tok,token,y,ix,va,device,seed,folder,signature,epochs,select):
    folder.mkdir(exist_ok=True);model=SourceModel(device,seed)
    trainable=[p for p in model.encoder.parameters() if p.requires_grad]
    opt=torch.optim.AdamW([dict(params=trainable,lr=PLAN['lr_encoder']),dict(params=model.head.parameters(),lr=PLAN['lr_head'])],weight_decay=PLAN['weight_decay'])
    n_batches=math.ceil(len(ix)/PLAN['batch']);steps_per_epoch=math.ceil(n_batches/PLAN['accumulate'])
    horizon=steps_per_epoch*PLAN['epochs'];warm=max(1,round(horizon*PLAN['warmup_fraction']))
    sch=torch.optim.lr_scheduler.LambdaLR(opt,lambda k:(k+1)/warm if k<warm else .5*(1+math.cos(math.pi*min(k-warm,horizon-warm)/max(horizon-warm,1))))
    count=np.bincount(y[ix],minlength=18);assert (count>0).all()
    weights=torch.tensor(len(ix)/(18*count),dtype=torch.float32,device=device)
    last=folder/'last.pt';history=[];best_loss=math.inf;chosen=0;start_epoch=0;stale=0
    if last.exists():
        state=torch.load(last,map_location='cpu',weights_only=True);assert state['signature']==signature
        model.load_delta(state['model']);opt.load_state_dict(state['optimizer']);sch.load_state_dict(state['scheduler'])
        history=state['history'];best_loss=state['best_loss'];chosen=state['chosen'];start_epoch=state['epoch'];stale=state['stale']
        torch.set_rng_state(state['cpu_rng'])
        if device=='mps':torch.mps.set_rng_state(state['mps_rng'])
    started=time.perf_counter()
    for ep in range(start_epoch,epochs):
        if select and ep>=PLAN['min_epochs'] and stale>=PLAN['patience']:break
        model.encoder.eval();model.head.train();order=np.random.default_rng(seed+ep).permutation(ix)
        opt.zero_grad(set_to_none=True);loss_sum=correct=seen=0;epoch_start=time.perf_counter()
        for j,s in enumerate(range(0,len(order),PLAN['batch'])):
            ids=order[s:s+PLAN['batch']];yy=torch.tensor(y[ids],dtype=torch.long,device=device)
            logits=model(batch(tok,token,ids,device));loss=nn.functional.cross_entropy(logits,yy,weight=weights)
            value=float(loss.detach().cpu());assert math.isfinite(value),'Nonfinite training loss'
            group_start=(j//PLAN['accumulate'])*PLAN['accumulate'];accum=min(PLAN['accumulate'],n_batches-group_start)
            (loss/accum).backward()
            loss_sum+=value*len(ids);correct+=int((logits.argmax(1)==yy).sum().detach().cpu());seen+=len(ids)
            if (j+1)%PLAN['accumulate']==0 or j+1==n_batches:
                norm=nn.utils.clip_grad_norm_([*trainable,*model.head.parameters()],1.);assert torch.isfinite(norm).item()
                opt.step();opt.zero_grad(set_to_none=True);sch.step()
            if (j+1)%80==0:
                elapsed=time.perf_counter()-epoch_start
                print(f'{folder.name} epoch={ep+1} batch={j+1}/{n_batches} seconds={elapsed:.1f} epoch_ETA_s={elapsed/(j+1)*(n_batches-j-1):.1f}',flush=True)
        record=dict(epoch=ep+1,online_train_loss=loss_sum/seen,online_train_accuracy=correct/seen,elapsed_s=time.perf_counter()-epoch_start)
        if select:
            score=predict(model,tok,token,va,device)
            record.update(val_logloss=float(log_loss(y[va],torch.softmax(torch.from_numpy(score),1).numpy(),labels=np.arange(18))),val_ba=float(ba(y[va],score.argmax(1))))
            if record['val_logloss']<best_loss-1e-5:
                best_loss=record['val_logloss'];chosen=ep+1;stale=0
                checkpoint(folder/'best.pt',dict(signature=signature,model=model.delta(),epoch=chosen))
            else:stale+=1
        else:chosen=ep+1
        history.append(record)
        checkpoint(last,dict(signature=signature,model=model.delta(),optimizer=opt.state_dict(),scheduler=sch.state_dict(),epoch=ep+1,
            history=history,best_loss=best_loss,chosen=chosen,stale=stale,cpu_rng=torch.get_rng_state(),
            mps_rng=torch.mps.get_rng_state() if device=='mps' else None))
        dump(folder/'history.json',history)
        print(folder.name,record,'selected_epoch',chosen,'phase_elapsed_s',round(time.perf_counter()-started,1),flush=True)
    if select:
        state=torch.load(folder/'best.pt',map_location='cpu',weights_only=True);model.load_delta(state['model'])
    return model,history,chosen


def run(smoke,folds):
    begin=time.perf_counter();OUT.mkdir(exist_ok=True);torch.set_num_threads(2)
    device='mps' if torch.backends.mps.is_available() else 'cpu'
    if device=='mps':torch.mps.set_per_process_memory_fraction(.45)
    t=lib.load_train(ROOT/'data/train.csv');y=t.y.to_numpy();groups=t.prompt_id.to_numpy()
    tok=AutoTokenizer.from_pretrained(MODEL,local_files_only=True,trust_remote_code=False)
    token=tok(t.text.tolist(),max_length=PLAN['max_tokens'],truncation=True)
    prompts=pd.Series(t.prompt_id.unique()).sample(frac=1,random_state=42).tolist();assignment=t.prompt_id.map({p:i%5 for i,p in enumerate(prompts)}).to_numpy()
    manifest=dict(plan=PLAN,code_sha256=sha(Path(__file__)),train_sha256=sha(ROOT/'data/train.csv'),device=device,
        model_files={n:sha(MODEL/n) for n in ['model.safetensors','config.json','tokenizer.json']},
        legacy_logits_sha256={n:sha(ROOT/f'kernels/twostage/out_full/out_{n}/oof_plain.npy') for n in ['q8','ll8']})
    signature=hashlib.sha256(json.dumps(manifest,sort_keys=True).encode()).hexdigest()
    mf=OUT/'manifest.json'
    if mf.exists():assert json.loads(mf.read_text())['signature']==signature,'Stale E37 contract'
    else:dump(mf,dict(manifest,signature=signature))
    if smoke:
        model=SourceModel(device,20263700);fit_ix=np.flatnonzero(assignment!=0)
        order=sorted(fit_ix,key=lambda i:-len(token['input_ids'][i]));params=[p for p in model.parameters() if p.requires_grad]
        opt=torch.optim.AdamW(params,lr=3e-5);timings=[]
        for k in range(8):
            ids=np.array(order[k*8:(k+1)*8]);b=batch(tok,token,ids,device);tick=time.perf_counter()
            logits=model(b);loss=nn.functional.cross_entropy(logits,torch.tensor(y[ids],device=device));loss.backward()
            norm=nn.utils.clip_grad_norm_(params,1.);assert torch.isfinite(norm).item() and math.isfinite(float(loss.detach().cpu()))
            opt.step();opt.zero_grad(set_to_none=True)
            if device=='mps':torch.mps.synchronize()
            timings.append(time.perf_counter()-tick)
            print('SMOKE step',k+1,'shape',list(b['input_ids'].shape),'loss',round(float(loss.detach().cpu()),4),'seconds',round(timings[-1],3),flush=True)
        score=predict(model,tok,token,np.array(order[:16]),device);assert score.shape==(16,18)
        result=dict(signature=signature,steps=8,complete=True,device=device,trainable_params=sum(p.numel() for p in params),
            step_seconds=timings,median_warm_step_s=float(np.median(timings[2:])),elapsed_s=time.perf_counter()-begin,
            allocated_MB_after_smoke=torch.mps.current_allocated_memory()/2**20 if device=='mps' else None,
            scope='Operational longest-train-row gradient/inference smoke only. Discarded model; no accuracy estimate or full fold run.')
        dump(OUT/'smoke.json',result);print(json.dumps(result,indent=2),flush=True)
        return
    paths=[ROOT/f'kernels/twostage/out_full/out_{n}/oof_plain.npy' for n in ['q8','ll8']]
    q,l=[np.load(p) for p in paths];base=lib.N((lib.N(q)+lib.N(l))/2)
    completed=[]
    for f in folds:
        fp=OUT/f'fold{f}.json'
        if fp.exists():record=json.loads(fp.read_text());assert record['signature']==signature
        else:
            tr=np.flatnonzero(assignment!=f);te=np.flatnonzero(assignment==f)
            tp=np.array([p for p in prompts if p in set(groups[tr])]);vp=tp[::5]
            fit_ix=tr[~np.isin(groups[tr],vp)];va=tr[np.isin(groups[tr],vp)]
            model,h,chosen=fit(tok,token,y,fit_ix,va,device,20263700+f,OUT/f'inner{f}',signature,PLAN['epochs'],True)
            v=predict(model,tok,token,va,device);val=dict(ba=float(ba(y[va],v.argmax(1))),chosen_epoch=chosen)
            del model
            if device=='mps':torch.mps.empty_cache()
            model,rh,_=fit(tok,token,y,tr,None,device,20263700+f,OUT/f'refit{f}',signature,chosen,False)
            score=predict(model,tok,token,te,device);train_score=predict(model,tok,token,tr,device)
            pred=dict(baseline=base[te].argmax(1),adapted=score.argmax(1),fusion=(base[te]+PLAN['alpha']*lib.N(score)).argmax(1))
            checkpoint(OUT/f'adapter_fold{f}.pt',dict(signature=signature,model=model.delta(),labels=lib.LABELS,selected_epochs=chosen,training_indices=tr.tolist()))
            record=dict(signature=signature,fold=f,inner_validation=val,refit_train_ba=float(ba(y[tr],train_score.argmax(1))),
                inner_history=h,refit_history=rh,test={k:float(ba(y[te],p)) for k,p in pred.items()},
                test_indices=te.tolist(),prediction={k:p.tolist() for k,p in pred.items()},
                epoch_budget_exhausted_without_early_stop=len(h)==PLAN['epochs'] and chosen==PLAN['epochs'])
            dump(fp,record);del model
            if device=='mps':torch.mps.empty_cache()
        completed.append(record);print('FOLD',f,record['test'],flush=True)
    all_records=[json.loads((OUT/f'fold{f}.json').read_text()) for f in range(5) if (OUT/f'fold{f}.json').exists()]
    result=dict(signature=signature,folds_complete=[r['fold'] for r in all_records],elapsed_s=time.perf_counter()-begin,submission_eligible=False)
    if len(all_records)==5:
        ix=np.concatenate([r['test_indices'] for r in all_records]);p={k:np.concatenate([r['prediction'][k] for r in all_records]) for k in ['baseline','adapted','fusion']}
        result.update(mean_test={k:float(np.mean([r['test'][k] for r in all_records])) for k in p},pooled_test={k:float(ba(y[ix],v)) for k,v in p.items()},
            fusion_minus_baseline=paired_interval(y[ix],p['baseline'],p['fusion'],groups[ix]))
    dump(OUT/'results.json',result)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--smoke',action='store_true');p.add_argument('--folds',type=int,nargs='+',default=list(range(5)));a=p.parse_args()
    assert all(f in range(5) for f in a.folds)
    with threadpool_limits(limits=2):run(a.smoke,a.folds)
