"""E17 ablation: reader fusion without topic projection vs E16's selected projection.
Hyperparameters for the no-projection arm come exclusively from saved val scores.
"""
import json
import sys
import time
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import balanced_accuracy_score as ba
from sklearn.preprocessing import StandardScaler
from threadpoolctl import threadpool_limits

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT/'notebook'))
import lib
OUT = ROOT/'research/experiments/e17_topic_ablation'
OUT.mkdir(parents=True, exist_ok=True)


def run():
    start = time.perf_counter()
    t = lib.load_train(ROOT/'data/train.csv')
    S, y, groups = lib.make_splits(t), t.y.to_numpy(), t.prompt_id.to_numpy()
    X = np.array(np.load(ROOT/'kernels/reader/out/q27_l16.npy', mmap_mode='r')[:len(t)], dtype=np.float32)
    assert np.array_equal(np.load(ROOT/'kernels/reader/out/train_id.npy'), t.id.astype(str))
    svc = np.load(ROOT/'kernels/svc4/out/members/svc4_p190k/oof.npy')
    pred = {k: np.full(len(t), -1) for k in ['svc', 'fusion_only', 'e16_selected']}
    folds = []
    for f in range(5):
        previous = json.loads((ROOT/f'research/experiments/e16_topic_projection/fold{f}.json').read_text())
        tr, va, te = (S[f] == i for i in (0, 1, 2))
        options = [q for q in previous['trials'] if q['rank'] == 0]
        chosen = max(options, key=lambda q: q['validation_ba'])
        scaler = StandardScaler().fit(X[tr])
        pca = PCA(128, svd_solver='randomized', iterated_power=3, random_state=42)
        A = pca.fit_transform(scaler.transform(X[tr]))
        E = pca.transform(scaler.transform(X[te]))
        model = LogisticRegression(C=chosen['C'], max_iter=300, random_state=42).fit(A, y[tr])
        mixed = lib.N(svc[f, te]) + chosen['alpha'] * lib.N(model.decision_function(E))
        ii = np.where(te)[0]
        assert previous['test_indices'] == ii.tolist()
        pred['svc'][ii] = svc[f, te].argmax(1)
        pred['fusion_only'][ii] = mixed.argmax(1)
        pred['e16_selected'][ii] = previous['prediction']
        row = dict(fold=f, fusion_val_choice=chosen,
                   **{k: float(ba(y[ii], v[ii])) for k, v in pred.items()})
        folds.append(row)
        print(row, flush=True)
    mask = pred['svc'] >= 0
    prompts = np.unique(groups[mask])
    indices = {p: np.where(mask & (groups == p))[0] for p in prompts}
    rng = np.random.default_rng(20261103)
    pairs = [('fusion_only', 'svc'), ('e16_selected', 'fusion_only')]
    boot = {a+' minus '+b: [] for a,b in pairs}
    for _ in range(2000):
        ii = np.concatenate([indices[p] for p in rng.choice(prompts, len(prompts))])
        scores = {k: ba(y[ii], v[ii]) for k,v in pred.items()}
        for a,b in pairs: boot[a+' minus '+b].append(scores[a]-scores[b])
    result = dict(test_mean={k: float(np.mean([r[k] for r in folds])) for k in pred},
                  test_pooled={k: float(ba(y[mask], v[mask])) for k,v in pred.items()},
                  paired_ci95={k: np.percentile(v,[2.5,97.5]).tolist() for k,v in boot.items()},
                  folds=folds, elapsed_s=time.perf_counter()-start,
                  source='E16 val choices; no new parameter chosen on test', submission_eligible=False)
    lib.atomic(OUT/'results.json', lambda f: f.write(json.dumps(result, indent=2).encode()))
    print(json.dumps({k:v for k,v in result.items() if k!='folds'}, indent=2), flush=True)


if __name__ == '__main__':
    with threadpool_limits(limits=2): run()
