# E9 evaluation. Rule fixed before seeing results: the larger reader passes only if its best layer (picked on val) beats 8B's on test by >= .03 with paired prompt-bootstrap CI above 0.
import sys, numpy as np, pandas as pd; sys.path.insert(0, 'notebook'); import lib
from sklearn.linear_model import LogisticRegression as LR
from sklearn.metrics import balanced_accuracy_score as ba
t = lib.load_train('data/train.csv'); S = lib.make_splits(t); y = t.y.values; pr = t.prompt_id.values; n = len(t); D = 'kernels/reader/out/'
assert (np.load(D + 'train_id.npy') == t.id.values.astype(str)).all()
py = np.array([lib.L2I[m] for m in np.load(D + 'pool_model.npy')])
def run(name, l, pool):
    X = np.load(D + f'{name}_l{l}.npy').astype(np.float32); X = (X - X.mean(0)) / (X.std(0) + 1e-6); Z = np.full((5, n, 18), np.nan, np.float32)
    for f in range(5):
        a = S[f] == 0; Xa, ya = (np.r_[X[:n][a], X[n:]], np.r_[y[a], py]) if pool else (X[:n][a], y[a])
        Z[f, ~a] = LR(C=.003, max_iter=300).fit(Xa, ya).predict_log_proba(X[:n][~a])
    return Z
def score(Z, v):
    return np.mean([ba(y[S[f] == v], Z[f, S[f] == v].argmax(1)) for f in range(5)])
res = {}
for name in ('q8', 'q27'):
    for l in (16, 24, 27):
        for pool in (False, True):
            Z = run(name, l, pool); res[name, l, pool] = Z; print(name, l, 'pool' if pool else 'host', 'val', round(score(Z, 1), 4), 'test', round(score(Z, 2), 4), flush=True)
best = {m: max((k for k in res if k[0] == m), key=lambda k: score(res[k], 1)) for m in ('q8', 'q27')}; print('best by val', best)
A, B = res[best['q27']], res[best['q8']]; rng = np.random.default_rng(0); d = []
for _ in range(300):
    v = []
    for f in range(5):
        p_ = np.unique(pr[S[f] == 2]); i = np.concatenate([np.where((pr == q) & (S[f] == 2))[0] for q in rng.choice(p_, len(p_))])
        v.append(ba(y[i], A[f, i].argmax(1)) - ba(y[i], B[f, i].argmax(1)))
    d.append(np.mean(v))
print('q27-q8 test delta', round(score(A, 2) - score(B, 2), 4), 'ci', np.round(np.quantile(d, [.025, .975]), 4))
np.save(D + 'q27_best.npy', A); np.save(D + 'q8_best.npy', B)
