"""E21: all-prompt outer 5-fold check against host-adapted LoRA OOF.

Predeclare alpha=0.1. Never use tiled LoRA scores for inner validation: the
outer LoRA models saw those training prompts. Select ONLY the frozen reader C
inside outer train, refit it on outer train, then evaluate the held-out fold.
This changes no leaderboard submission and does not create new independent gold.
"""
import os
os.environ.setdefault('OMP_NUM_THREADS','2')
os.environ.setdefault('OPENBLAS_NUM_THREADS','2')
import hashlib
import json
import sys
import time
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import balanced_accuracy_score as ba,log_loss
from sklearn.preprocessing import StandardScaler
from threadpoolctl import threadpool_limits

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'notebook'))
import lib
from closing_audit import paired_ci
from spectral_reader import FEATURE,LAYERS,sha,dump

OUT=ROOT/'research/experiments/e21_nested_reader_confirm'
PLAN=dict(reader='Qwen3-0.6B',layer=16,modes='DCAC',C=[0.0003,0.003,0.03],
    alpha=0.1,max_iter=2000,inner_seed=20261103,inner_validation_prompts=24,
    outer='worker 5-fold seed42, 120 train / 30 test prompts; 100% test coverage',
    inner='96 train /24 val prompts within outer train; choose C by reader val logloss',
    baseline='fixed mean of row-standardized host-adapted q8 and ll8 OOF',
    gate='no weight/hyperparameter selection on outer test; no automatic submission')


def run():
    start=time.perf_counter()
    OUT.mkdir(parents=True,exist_ok=True)
    assert np.load(FEATURE/'done.npy').all(),'incomplete feature extraction'
    t=lib.load_train(ROOT/'data/train.csv');y=t.y.to_numpy();pr=t.prompt_id.to_numpy()
    assert np.array_equal(np.load(FEATURE/'id.npy'),t.id.astype(str))
    X=np.array(np.load(FEATURE/'features.npy',mmap_mode='r')[:,LAYERS.index(16)],dtype=np.float32).reshape(len(t),-1)
    assert X.shape[1]==2048 and np.isfinite(X).all()
    prompts=pd.Series(t.prompt_id.unique()).sample(frac=1,random_state=42).tolist()
    fold=t.prompt_id.map({p:i%5 for i,p in enumerate(prompts)}).to_numpy()
    paths=[ROOT/f'kernels/twostage/out_full/out_{tag}/oof_plain.npy' for tag in ['q8','ll8']]
    q,l=[np.load(p) for p in paths]
    assert q.shape==l.shape==(len(t),18) and np.isfinite(q).all() and np.isfinite(l).all()
    # This archived worker writes each outer fold in CSV row order. Cache lacks
    # per-row IDs/model revision: manifest the evidence and keep that limitation.
    worker=ROOT/'kernels/twostage/out_full/worker.py'
    code=worker.read_text()
    assert 'fold = t.prompt_id.map({p: i % 5 for i, p in enumerate(pr)}).values' in code
    manifest=dict(plan=PLAN,feature_manifest=json.loads((FEATURE/'manifest.json').read_text()),
        code_sha256=sha(Path(__file__)),worker_sha256=sha(worker),
        oof_sha256={str(p.relative_to(ROOT)):sha(p) for p in paths},
        caveat='Historical OOF assumed to follow archived worker and original CSV; '
               'per-row IDs/model revisions were not recorded. Not independently rerun LoRA.')
    signature=hashlib.sha256(json.dumps(manifest,sort_keys=True).encode()).hexdigest()
    dump(OUT/'manifest.json',dict(manifest,signature=signature))
    base=lib.N((lib.N(q)+lib.N(l))/2)
    prediction={k:np.full(len(t),-1) for k in ['baseline','fusion','reader']}
    folds=[]
    for f in range(5):
        path=OUT/f'fold{f}.json'
        if path.exists():
            r=json.loads(path.read_text());assert r['signature']==signature,'stale cached fold'
        else:
            outer_tr=fold!=f;outer_te=~outer_tr
            eligible=np.array([p for i,p in enumerate(prompts) if i%5!=f])
            inner_v=np.random.default_rng(PLAN['inner_seed']+f).permutation(eligible)[:24]
            va=np.isin(pr,inner_v);tr=outer_tr & ~va
            assert set(pr[tr]).isdisjoint(pr[va]) and set(pr[outer_te]).isdisjoint(pr[outer_tr])
            scaler=StandardScaler().fit(X[tr]);A=scaler.transform(X[tr]);V=scaler.transform(X[va])
            trials=[]
            for C in PLAN['C']:
                model=LogisticRegression(C=C,max_iter=PLAN['max_iter'],random_state=42).fit(A,y[tr])
                assert model.n_iter_.max()<PLAN['max_iter'],'unconverged inner head'
                trials.append(dict(C=C,train_ba=float(ba(y[tr],model.predict(A))),
                    val_ba=float(ba(y[va],model.predict(V))),
                    val_logloss=float(log_loss(y[va],model.predict_proba(V),labels=np.arange(18)))))
            choice=min(trials,key=lambda z:z['val_logloss'])
            scaler=StandardScaler().fit(X[outer_tr])
            model=LogisticRegression(C=choice['C'],max_iter=PLAN['max_iter'],random_state=42).fit(
                scaler.transform(X[outer_tr]),y[outer_tr])
            assert model.n_iter_.max()<PLAN['max_iter'],'unconverged refit head'
            z=lib.N(model.decision_function(scaler.transform(X[outer_te])))
            pred=dict(baseline=base[outer_te].argmax(1),reader=z.argmax(1),
                      fusion=(base[outer_te]+PLAN['alpha']*z).argmax(1))
            r=dict(signature=signature,fold=f,inner_trials=trials,chosen=choice,
                outer_train_prompts=int(t.prompt_id[outer_tr].nunique()),
                outer_test_prompts=int(t.prompt_id[outer_te].nunique()),
                train_refit_ba=float(ba(y[outer_tr],model.predict(scaler.transform(X[outer_tr])))),
                test={k:float(ba(y[outer_te],p)) for k,p in pred.items()},
                test_indices=np.flatnonzero(outer_te).tolist(),prediction={k:p.tolist() for k,p in pred.items()})
            lib.atomic(OUT/f'head_fold{f}.joblib',lambda h:joblib.dump(dict(
                signature=signature,scaler=scaler,model=model,labels=lib.LABELS,plan=PLAN),h))
            dump(path,r)
        folds.append(r)
        for key in prediction:prediction[key][r['test_indices']]=r['prediction'][key]
        elapsed=time.perf_counter()-start
        print(f'fold={f} test={r["test"]} elapsed_s={elapsed:.1f} ETA_s={elapsed/(f+1)*(4-f):.1f}',flush=True)
    assert all((p>=0).all() for p in prediction.values())
    result=dict(signature=signature,plan=PLAN,mean_test={k:float(np.mean([r['test'][k] for r in folds])) for k in prediction},
        pooled_test={k:float(ba(y,p)) for k,p in prediction.items()},
        paired_ci95=paired_ci(y,prediction['baseline'],prediction['fusion'],pr),
        test_rows=len(t),test_prompts=t.prompt_id.nunique(),test_coverage=1.,
        positive_folds=sum(r['test']['fusion']>r['test']['baseline'] for r in folds),
        elapsed_s=time.perf_counter()-start,submission_eligible=False,
        caveat=manifest['caveat']+' Historical adaptive research means these are not fresh blind gold prompts.')
    dump(OUT/'results.json',result)
    print(json.dumps(result,indent=2),flush=True)


if __name__=='__main__':
    with threadpool_limits(limits=2):run()
