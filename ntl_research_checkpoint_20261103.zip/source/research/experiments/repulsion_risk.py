# E13b: damage curve of soft repulsion per lam when the true passages-per-prompt k is 1 (only false clusters) up to 6.
import sys, json, numpy as np
sys.path.insert(0, 'research/experiments'); sys.argv = ['x']
src = open('research/experiments/repulsion.py').read().split("LAMS = ")[0]; exec(src)
out = {}
for k in (1, 2, 3, 6):
    for f in range(5):
        v, te = S[f] == 1, S[f] == 2; ch, w = lib.select_stack([l[f][v] for l in Ls], y[v]); B = np.zeros((len(y), 18)); B[te] = lib.blend([Ls[j][f][te] for j in ch], w)
        st = [sims(te, k, 10 + s) for s in range(4)]
        for lam in (0., .25, .5, 1.):
            out.setdefault(f'k{k} lam{lam}', []).append(np.mean([bas(y[r], repel(B[r], g, lam).argmax(1)) for r, g in st]))
        out.setdefault(f'k{k} cluster', []).append(np.mean([np.mean(np.bincount(g)[g] > 1) for _, g in st]))
    print(k, {n: round(float(np.mean(v_)), 4) for n, v_ in out.items() if n.startswith(f'k{k} ')}, flush=True)
json.dump({n: np.round(v_, 4).tolist() for n, v_ in out.items()}, open('research/experiments/repulsion_risk.json', 'w'), indent=1)
