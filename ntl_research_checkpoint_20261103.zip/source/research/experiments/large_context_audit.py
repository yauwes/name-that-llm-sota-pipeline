"""E33: frozen grouping/fusion under3500 additional external context rows.

Evaluate gold predictions only. Same E32 rows, thresholds, Gaussian checkpoints,
alpha and2..18eligibility. External source labels never affect inference. Known
Gold/Gold and external/external prompt edges are evaluated separately; cross
origin links have UNKNOWN truth, not automatically false-positive labels.
"""
import os
os.environ.setdefault('OMP_NUM_THREADS','2')
os.environ.setdefault('OPENBLAS_NUM_THREADS','2')
import argparse
import hashlib
import json
import time
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.metrics import recall_score
from threadpoolctl import threadpool_limits

import partial_group_audit as audit
from spectral_reader import ROOT,FEATURE as READER,LAYERS,sha,dump
from large_context_reader import FEATURE as EXTERNAL
import lib

OUT=ROOT/'research/experiments/e33_large_context'
E29=ROOT/'research/experiments/e29_partial_group_audit'
E30=ROOT/'research/experiments/e30_semantic_groups'
E32=ROOT/'research/experiments/e32_group_eligibility'
SEMANTIC=ROOT/'data/features/e30_semantic_groups'
CASES=['k1_seed0','k2_seed0','k2_seed1','k2_seed2','k4_seed0','k18_seed0']
PLAN=dict(cases=CASES,context='All3500 READER Agent500 responses appended in stable parquet order',
    train='No fitting, retraining or external source-label use; reuse E29 models and E30 training-only thresholds',
    alpha=.1,eligibility='Existing production2<=group size<=18',
    control='Additionally disable both injectivity and repel, predeclared stress control; not tuned on test',
    scoring='Score clusters touching eligible Gold targets including actual external member DC16 features',
    metric='Gold-target balanced accuracy only, same selected E32 rows',
    limitations=['Historical inspected gold and legacy LoRA OOF provenance',
        'External7generator128token responses are OOD stress, not representative hidden sampling',
        'Cross-origin prompt identity is unknown; never label every cross-origin link false',
        'Context pool repeated across folds, not independent random samples; no champion CV or submission'])


def pair_metrics(labels,truth):
    _,sizes=np.unique(truth,return_counts=True);positive=int((sizes*(sizes-1)//2).sum())
    tp=pred=0
    for g in np.unique(labels):
        ix=np.flatnonzero(labels==g);pred+=len(ix)*(len(ix)-1)//2
        _,counts=np.unique(truth[ix],return_counts=True);tp+=int((counts*(counts-1)//2).sum())
    return dict(tp=tp,fp=pred-tp,fn=positive-tp,pair_precision=tp/pred if pred else None,
        pair_recall=tp/positive if positive else None)


def diagnostics(labels,ng,gold_truth,ext_truth):
    counts=np.bincount(labels);g=np.bincount(labels[:ng],minlength=len(counts));e=counts-g
    cross=(g>0)&(e>0)
    return dict(gold_gold=pair_metrics(labels[:ng],gold_truth),external_external=pair_metrics(labels[ng:],ext_truth),
        cross_origin_edges_unknown_truth=int((g*e).sum()),mixed_origin_groups=int(cross.sum()),
        gold_rows_in_mixed_origin_groups=int(g[cross].sum()),eligible_gold_rows=int(((counts[labels[:ng]]>=2)&(counts[labels[:ng]]<=18)).sum()),
        gold_rows_in_non_singleton_groups=int((counts[labels[:ng]]>1).sum()),max_group_size=int(counts.max()))


def fusion(X,U,labels,prm,base,ng,cfg=None):
    size=np.bincount(labels)[labels];target=np.flatnonzero((size[:ng]>=2)&(size[:ng]<=18))
    pred=base.argmax(1).copy()
    if len(target):
        member=np.flatnonzero(np.isin(labels,np.unique(labels[target])))
        lp=audit.gauss.scores(X[member],labels[member],prm,U=U[member],cfg=cfg)
        assert np.isfinite(lp).all()
        pos=np.searchsorted(member,target);assert np.array_equal(member[pos],target)
        pred[target]=(base[target]+PLAN['alpha']*lib.N(lp[pos])).argmax(1)
    return pred


def run(max_cases):
    start=time.perf_counter();t=lib.load_train(ROOT/'data/train.csv')
    context=json.loads((EXTERNAL/'context_index.json').read_text())
    assert context['rows']==3500 and len(context['prompt_hash'])==3500
    y=t.y.to_numpy();gold_groups=t.prompt_id.to_numpy();ext_groups=np.array(context['prompt_hash'])
    ext=[]
    for kind in ['semantic','dc16']:
        p=EXTERNAL/kind;assert np.load(p/'done.npy').all()
        m=json.loads((p/'manifest.json').read_text());assert m['data_sha256']==context['data_sha256']
        assert np.array_equal(np.load(p/'text_sha256.npy'),context['text_sha256'])
        a=np.asarray(np.load(p/'features.npy'),dtype=np.float32);assert np.isfinite(a).all();ext.append(a)
    Ce,Xe=ext
    C=np.asarray(np.load(SEMANTIC/'features.npy'),dtype=np.float32)
    X=np.asarray(np.load(READER/'features.npy')[:,LAYERS.index(16),0,:],dtype=np.float32)
    for p in [SEMANTIC,READER]:assert np.array_equal(np.load(p/'id.npy'),t.id.astype(str))
    q,l=[np.load(ROOT/f'kernels/twostage/out_full/out_{n}/oof_plain.npy') for n in ['q8','ll8']]
    base=lib.N((lib.N(q)+lib.N(l))/2)
    manifest=dict(plan=PLAN,code_sha256=sha(Path(__file__)),helper_sha256=sha(Path(audit.__file__)),data_sha256=context['data_sha256'],
        context_index_sha256=sha(EXTERNAL/'context_index.json'),
        upstream={n:sha(p/'manifest.json') for n,p in [('e29',E29),('e30',E30),('e32',E32)]},
        external={k:dict(manifest_sha256=sha(EXTERNAL/k/'manifest.json'),feature_sha256=sha(EXTERNAL/k/'features.npy')) for k in ['semantic','dc16']},
        gaussian_sha256={f:sha(E29/f'gaussian_fold{f}.joblib') for f in range(5)})
    signature=hashlib.sha256(json.dumps(manifest,sort_keys=True).encode()).hexdigest()
    mf=OUT/'audit_manifest.json'
    if mf.exists():assert json.loads(mf.read_text())['signature']==signature,'Stale E33 audit'
    else:dump(mf,dict(manifest,signature=signature))
    new_cases=0;pooled={};complete=True
    for f in range(5):
        old=json.loads((E32/f'fold{f}.json').read_text());s=json.loads((E30/f'fold{f}.json').read_text())
        saved=joblib.load(E29/f'gaussian_fold{f}.joblib');prm=saved['params'];Ue=audit.gauss.transform(Xe,prm)
        fp=OUT/f'fold{f}.json'
        record=json.loads(fp.read_text()) if fp.exists() else dict(signature=signature,fold=f,cases=[],test_indices={},prediction={})
        assert record['signature']==signature
        for key in CASES:
            if key not in record['prediction']:
                if max_cases and new_cases>=max_cases:complete=False;continue
                began=time.perf_counter();ix=np.asarray(old['test_indices'][key]);ng=len(ix)
                cx=np.concatenate([C[ix],Ce]);xx=np.concatenate([X[ix],Xe]);uu=np.concatenate([audit.gauss.transform(X[ix],prm),Ue])
                labels=audit.clusters(cx,s['threshold']['threshold'])
                pred=dict(baseline=base[ix].argmax(1),gold_only=np.asarray(old['prediction'][key]['semantic_grouped_only']),
                    context_fusion=fusion(xx,uu,labels,prm,base[ix],ng),
                    context_no_injection=fusion(xx,uu,labels,prm,base[ix],ng,cfg=dict(inj=False,repel=False)))
                assert np.array_equal(pred['baseline'],old['prediction'][key]['baseline'])
                present=np.unique(y[ix]);diag=diagnostics(labels,ng,gold_groups[ix],ext_groups)
                entry=dict(case=key,rows=ng,total_context_rows=len(cx),diagnostics=diag,elapsed_s=time.perf_counter()-began,
                    present_classes=len(present),present_class_macro_recall={k:float(recall_score(y[ix],p,labels=present,average='macro',zero_division=0)) for k,p in pred.items()})
                record['cases'].append(entry);record['test_indices'][key]=ix.tolist();record['prediction'][key]={k:p.tolist() for k,p in pred.items()}
                dump(fp,record);new_cases+=1
                print(f'fold={f} case={key} rows={ng}+{len(Xe)} seconds={entry["elapsed_s"]:.2f} metrics={entry["present_class_macro_recall"]} mixed_gold={diag["gold_rows_in_mixed_origin_groups"]}',flush=True)
            pooled.setdefault(key,dict(indices=[],prediction={k:[] for k in record['prediction'][key]},diagnostics=[]))
            bucket=pooled[key];bucket['indices'].extend(record['test_indices'][key]);bucket['diagnostics'].append(next(c['diagnostics'] for c in record['cases'] if c['case']==key))
            for k in bucket['prediction']:bucket['prediction'][k].extend(record['prediction'][key][k])
        elapsed=time.perf_counter()-start
        print(f'fold={f} done new_cases={new_cases} elapsed_s={elapsed:.1f}',flush=True)
    summary={}
    for key,b in pooled.items():
        ix=np.asarray(b['indices']);pred={k:np.asarray(p) for k,p in b['prediction'].items()};di=b['diagnostics']
        pairs={}
        for name in ['gold_gold','external_external']:
            tp,fp,fn=[sum(d[name][k] for d in di) for k in ['tp','fp','fn']]
            pairs[name]=dict(tp=tp,fp=fp,fn=fn,pair_precision=tp/(tp+fp) if tp+fp else None,pair_recall=tp/(tp+fn) if tp+fn else None)
        summary[key]=dict(rows=len(ix),folds_present=len(di),present_classes=len(np.unique(y[ix])),
            balanced_accuracy18={k:float(recall_score(y[ix],p,labels=np.arange(18),average='macro',zero_division=0)) if len(np.unique(y[ix]))==18 else None for k,p in pred.items()},
            intervals={b+' minus '+a:audit.paired_interval(y[ix],pred[a],pred[b],gold_groups[ix]) for a,b in [('gold_only','context_fusion'),('baseline','context_fusion'),('context_fusion','context_no_injection')]},
            pair_diagnostics=pairs,diagnostics_totals={k:sum(d[k] for d in di) for k in ['cross_origin_edges_unknown_truth','mixed_origin_groups','gold_rows_in_mixed_origin_groups','eligible_gold_rows']})
    result=dict(signature=signature,plan=PLAN,complete=complete,cases=summary,elapsed_s=time.perf_counter()-start,
        submission_eligible=False,conclusion='Historical OOD context stress only; no replacement for official0.665 champion, no new submission.')
    dump(OUT/'results.json',result)
    print('complete',complete,'elapsed_s',result['elapsed_s'],flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--max-cases',type=int,default=0);a=p.parse_args()
    with threadpool_limits(limits=2):run(a.max_cases)
