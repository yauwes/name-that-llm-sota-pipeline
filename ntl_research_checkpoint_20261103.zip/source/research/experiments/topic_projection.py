"""E16: train-only prompt-nuisance projection + cached strict-rotation SVC.
All hyperparameters/blending chosen on val; test evaluated after selection.
This is exploratory reuse of historical prompts, never an automatic submission.
"""
import os
os.environ.setdefault('OMP_NUM_THREADS', '2')
os.environ.setdefault('OPENBLAS_NUM_THREADS', '2')
import hashlib
import json
import sys
import time
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import balanced_accuracy_score as ba
from sklearn.preprocessing import StandardScaler
from threadpoolctl import threadpool_limits

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'notebook'))
import lib
OUT = ROOT / 'research/experiments/e16_topic_projection'
OUT.mkdir(parents=True, exist_ok=True)
PLAN = dict(feature='q27_l16', pca=128, topic_rank=[0, 4, 16, 32],
            gamma=[0.5, 1.0], C=[0.003, 0.03], blend_alpha=[0.0, 0.05, 0.1, 0.2, 0.35],
            baseline='strict-rotation cached SVC4', selection='val BA only; ties prefer baseline',
            status='exploratory; no new gold holdout created')


def dump(path, obj):
    lib.atomic(path, lambda f: f.write(json.dumps(obj, indent=2).encode()))


def sha(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for b in iter(lambda: f.read(2 ** 20), b''): h.update(b)
    return h.hexdigest()


def run():
    started = time.perf_counter()
    t = lib.load_train(ROOT / 'data/train.csv')
    S = lib.make_splits(t)
    y = t.y.to_numpy()
    groups = t.prompt_id.to_numpy()
    feature = ROOT / 'kernels/reader/out/q27_l16.npy'
    svc_path = ROOT / 'kernels/svc4/out/members/svc4_p190k/oof.npy'
    assert np.array_equal(np.load(feature.parent/'train_id.npy'), t.id.astype(str))
    X = np.array(np.load(feature, mmap_mode='r')[:len(t)], dtype=np.float32)
    svc = np.load(svc_path)
    assert svc.shape == (5, len(t), 18)
    for f in range(5):
        assert np.isnan(svc[f, S[f] == 0]).all()
        assert np.isfinite(svc[f, S[f] != 0]).all()
    manifest = dict(plan=PLAN, feature_sha256=sha(feature), svc_sha256=sha(svc_path),
                    code_sha256=sha(Path(__file__)), train_sha256=sha(ROOT/'data/train.csv'),
                    split_md5=hashlib.md5(S.tobytes()).hexdigest(),
                    base_model_revision='missing from historical feature cache')
    signature = hashlib.sha256(json.dumps(manifest, sort_keys=True).encode()).hexdigest()
    dump(OUT/'manifest.json', dict(manifest, signature=signature))
    prediction = np.full(len(t), -1)
    baseline = np.full(len(t), -1)
    folds = []
    for f in range(5):
        path = OUT/f'fold{f}.json'
        if path.exists():
            result = json.loads(path.read_text())
            assert result['signature'] == signature, 'stale cached fold'
        else:
            tr, va, te = (S[f] == i for i in (0, 1, 2))
            scaler = StandardScaler().fit(X[tr])
            pca = PCA(128, svd_solver='randomized', iterated_power=3, random_state=42)
            A = pca.fit_transform(scaler.transform(X[tr]))
            V = pca.transform(scaler.transform(X[va]))
            E = pca.transform(scaler.transform(X[te]))
            # Prompt means cancel class-balanced source effects within each train prompt.
            train_groups = groups[tr]
            means = np.stack([A[train_groups == p].mean(0) for p in np.unique(train_groups)])
            _, _, vt = np.linalg.svd(means - means.mean(0), full_matrices=False)
            sv = lib.N(svc[f, va])
            st = lib.N(svc[f, te])
            best = dict(validation_ba=float(ba(y[va], sv.argmax(1))), alpha=0., rank=0, gamma=0., C=None)
            best_test = st
            trials = []
            for rank in PLAN['topic_rank']:
                U = vt[:rank].T
                for gamma in ([0.] if rank == 0 else PLAN['gamma']):
                    transform = lambda Z: Z - gamma * ((Z @ U) @ U.T)
                    aa, vv, ee = map(transform, [A, V, E])
                    for c in PLAN['C']:
                        model = LogisticRegression(C=c, max_iter=300, random_state=42).fit(aa, y[tr])
                        rv, rt = lib.N(model.decision_function(vv)), lib.N(model.decision_function(ee))
                        for alpha in PLAN['blend_alpha'][1:]:
                            z = sv + alpha * rv
                            candidate = dict(validation_ba=float(ba(y[va], z.argmax(1))),
                                             alpha=alpha, rank=rank, gamma=gamma, C=c)
                            trials.append(candidate)
                            if candidate['validation_ba'] > best['validation_ba']:
                                best, best_test = candidate, st + alpha * rt
            result = dict(signature=signature, fold=f, selected=best, trials=trials,
                          test_indices=np.where(te)[0].tolist(),
                          prediction=best_test.argmax(1).tolist(), baseline=st.argmax(1).tolist(),
                          selected_test_ba=float(ba(y[te], best_test.argmax(1))),
                          baseline_test_ba=float(ba(y[te], st.argmax(1))))
            dump(path, result)
        prediction[result['test_indices']] = result['prediction']
        baseline[result['test_indices']] = result['baseline']
        folds.append(result)
        elapsed = time.perf_counter()-started
        print(f'fold={f} val={result["selected"]["validation_ba"]:.4f} '
              f'test={result["selected_test_ba"]:.4f} baseline={result["baseline_test_ba"]:.4f} '
              f'elapsed_s={elapsed:.1f} ETA_s={elapsed/(f+1)*(4-f):.1f} '
              f'selection={result["selected"]}', flush=True)
    mask = prediction >= 0
    prompts = np.unique(groups[mask])
    idx = {p: np.where(mask & (groups == p))[0] for p in prompts}
    rng = np.random.default_rng(20261103)
    delta = []
    for _ in range(2000):
        ii = np.concatenate([idx[p] for p in rng.choice(prompts, len(prompts))])
        delta.append(ba(y[ii], prediction[ii])-ba(y[ii], baseline[ii]))
    result = dict(signature=signature, plan=PLAN,
                  selected_test_ba_mean=float(np.mean([r['selected_test_ba'] for r in folds])),
                  baseline_test_ba_mean=float(np.mean([r['baseline_test_ba'] for r in folds])),
                  selected_test_ba_pooled=float(ba(y[mask], prediction[mask])),
                  baseline_test_ba_pooled=float(ba(y[mask], baseline[mask])),
                  paired_delta_ci95=np.percentile(delta, [2.5, 97.5]).tolist(),
                  positive_rotations=sum(r['selected_test_ba'] > r['baseline_test_ba'] for r in folds),
                  elapsed_s=time.perf_counter()-started, submission_eligible=False,
                  test_rows=int(mask.sum()), test_prompts=len(prompts),
                  note='SVC cache is historical; NaN train mask/split shape checked, no fresh external gold.')
    dump(OUT/'results.json', result)
    pd.DataFrame(dict(id=t.id, prompt_id=t.prompt_id, y=y, selected=prediction, baseline=baseline)).to_csv(OUT/'oof.csv', index=False)
    print(json.dumps(result, indent=2), flush=True)


if __name__ == '__main__':
    with threadpool_limits(limits=2): run()
