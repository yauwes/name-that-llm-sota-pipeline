"""E18: aggregate error analysis and paired E14 audit; never tunes on test.

No feature fitting, submission, paid API call, or GPU allocation. Raw per-ID
predictions stay local; public output contains only aggregate diagnostics.
"""
import hashlib
import json
import re
import time
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import balanced_accuracy_score, confusion_matrix

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'research/experiments/e18_closing_audit'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def paired_ci(y, a, b, prompts, seed=20261103):
    # All classes occur in each prompt except a single missing train passage.
    # Accumulate correct/support counts by prompt before resampling prompts.
    unique = np.unique(prompts)
    support, diff = [], []
    for prompt in unique:
        m = prompts == prompt
        support.append(np.bincount(y[m], minlength=18))
        diff.append(np.bincount(y[m], weights=(b[m] == y[m]).astype(float)
                                - (a[m] == y[m]).astype(float), minlength=18))
    support, diff = np.array(support), np.array(diff)
    draw = np.random.default_rng(seed).integers(0, len(unique), (4000, len(unique)))
    totals = support[draw].sum(1)
    assert (totals > 0).all()
    return np.percentile((diff[draw].sum(1) / totals).mean(1), [2.5, 97.5]).tolist()


def run():
    started = time.perf_counter()
    OUT.mkdir(parents=True, exist_ok=True)
    t = pd.read_csv(ROOT / 'data/train.csv')
    labels = sorted(t.model.unique())
    y = t.model.map(dict(zip(labels, range(18)))).to_numpy()
    groups = t.prompt_id.to_numpy()
    prompts = pd.Series(t.prompt_id.unique()).sample(frac=1, random_state=42).tolist()
    fold = t.prompt_id.map({p: i % 5 for i, p in enumerate(prompts)}).to_numpy()
    mask = fold < 3
    comparison, hashes = {}, {}
    for name in ['q8', 'll8']:
        original = ROOT / f'kernels/s2control/out/out_{name}/oof_plain_ctrl.npy'
        candidate = ROOT / f'kernels/e14regen/out_live/out_{name}/oof_plain_regen.npy'
        A, B = np.load(original), np.load(candidate)
        assert A.shape == B.shape == (len(t), 18)
        assert np.isfinite(A[mask]).all() and np.isfinite(B[mask]).all()
        assert (np.ptp(B[mask], axis=1) > 0).all(), 'incomplete E14 fold'
        a, b = A.argmax(1), B.argmax(1)
        rows = []
        for f in range(3):
            m = fold == f
            rows.append(dict(fold=f, control=balanced_accuracy_score(y[m], a[m]),
                             e14=balanced_accuracy_score(y[m], b[m])))
        comparison[name] = dict(folds=rows,
            control_mean=float(np.mean([r['control'] for r in rows])),
            e14_mean=float(np.mean([r['e14'] for r in rows])),
            pooled_delta=float(balanced_accuracy_score(y[mask], b[mask])
                               - balanced_accuracy_score(y[mask], a[mask])),
            paired_prompt_ci95=paired_ci(y[mask], a[mask], b[mask], groups[mask]),
            positive_folds=sum(r['e14'] > r['control'] for r in rows),
            stage2_weights_saved=False,
            checkpoint_note='Source writes OOF and logs only; no final adapter/head state.')
        hashes[str(original.relative_to(ROOT))] = sha(original)
        hashes[str(candidate.relative_to(ROOT))] = sha(candidate)
    oo = pd.read_csv(ROOT / 'research/experiments/e16_topic_projection/oof.csv')
    assert np.array_equal(oo.id.astype(str), t.id.astype(str))
    assert np.array_equal(oo.y, y)
    m = oo.selected.to_numpy() >= 0
    yy, a, b = y[m], oo.baseline.to_numpy()[m], oo.selected.to_numpy()[m]
    fam = np.array([re.split(r'[-.\d]', label)[0] for label in labels])
    cm = confusion_matrix(yy, b, labels=np.arange(18))
    per_class = []
    for c, label in enumerate(labels):
        z = yy == c
        per_class.append(dict(model=label, n=int(z.sum()),
            svc_recall=float((a[z] == c).mean()), e16_recall=float((b[z] == c).mean())))
    errors = b != yy
    same_family = fam[yy] == fam[b]
    bins = pd.cut(t.text.str.split().str.len().to_numpy()[m], [0, 64, 100, 160, np.inf])
    length = []
    for interval in bins.categories:
        z = bins == interval
        present = np.unique(yy[z])
        length.append(dict(words=str(interval), n=int(z.sum()), classes=len(present),
            svc_accuracy=float((a[z] == yy[z]).mean()),
            e16_accuracy=float((b[z] == yy[z]).mean()),
            e16_BA_present_classes=float(balanced_accuracy_score(yy[z], b[z]))))
    offdiag = cm.copy()
    np.fill_diagonal(offdiag, 0)
    flat = np.argsort(offdiag.ravel())[::-1][:12]
    pairs = [dict(true=labels[i // 18], predicted=labels[i % 18], n=int(offdiag.ravel()[i]))
             for i in flat if offdiag.ravel()[i] > 0]
    result = dict(protocol='E14 same 3 prompt folds as control; E16 historical heldout predictions; no tuning',
        e14=comparison, e16=dict(per_class=per_class, length_slices=length,
            family_accuracy=float(same_family.mean()), error_count=int(errors.sum()),
            fraction_errors_within_family=float(same_family[errors].mean()),
            fixes=int(((a != yy) & (b == yy)).sum()),
            breaks=int(((a == yy) & (b != yy)).sum()), top_confusions=pairs),
        artifacts_sha256=hashes, elapsed_s=time.perf_counter() - started,
        submission_eligible=False, limitation='Bootstrap intervals are conditional on fixed historical models; '
        'not uncertainty for the whole adaptive research process or hidden leaderboard.')
    (OUT / 'results.json').write_text(json.dumps(result, indent=2))
    print(json.dumps(result, indent=2), flush=True)


if __name__ == '__main__':
    run()
