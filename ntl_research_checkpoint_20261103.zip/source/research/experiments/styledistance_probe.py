"""E25: frozen content-independent style encoder, independent passage inference.

Primary source: https://aclanthology.org/2025.naacl-long.436/
Use official final-layer mean pooling; no third-party repository code executes.
Pinned model, text hashes, resumable features; fit transformations on train only.
"""
import os
os.environ.setdefault('OMP_NUM_THREADS','2')
os.environ.setdefault('OPENBLAS_NUM_THREADS','2')
os.environ.setdefault('TOKENIZERS_PARALLELISM','false')
import argparse
import hashlib
import json
import sys
import time
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import balanced_accuracy_score as ba,log_loss
from sklearn.preprocessing import StandardScaler
from threadpoolctl import threadpool_limits

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'notebook'))
import lib
from closing_audit import paired_ci

OUT=ROOT/'research/experiments/e25_styledistance'
MODEL=ROOT/'data/models/StyleDistance'
FEATURE=ROOT/'data/features/e25_styledistance'
PLAN=dict(max_tokens=512,batch=8,max_memory_fraction=.4,
    pooling='last hidden, masked mean including actual special tokens, no padding',
    style_C=[.0003,.003,.03,.3],hybrid_C=[.003,.03],max_iter=2000,
    alpha=[0.,.05,.1,.2,.35],val_gain_required=.005,
    selection='head by val logloss; alpha by val BA, ties prefer simpler baseline',
    features='train-only standardized style768; hybrid appends 3x row-normalized external-stage1 q8/ll8 logits',
    scope='historical 70/15/15 prompt rotations; independent single-passage inference')


def sha(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for chunk in iter(lambda:f.read(2**20),b''):h.update(chunk)
    return h.hexdigest()


def dump(path,value):lib.atomic(path,lambda f:f.write(json.dumps(value,indent=2).encode()))


def extract(max_batches=0):
    import torch
    from transformers import AutoModel,AutoTokenizer
    begin=time.perf_counter();FEATURE.mkdir(parents=True,exist_ok=True)
    upstream=json.loads((OUT/'upstream.json').read_text())
    t=pd.read_csv(ROOT/'data/train.csv')
    device='mps' if torch.backends.mps.is_available() else 'cpu'
    if device=='mps':torch.mps.set_per_process_memory_fraction(PLAN['max_memory_fraction'])
    tok=AutoTokenizer.from_pretrained(MODEL,local_files_only=True,trust_remote_code=False)
    ids=tok(t.text.tolist(),truncation=False,add_special_tokens=True)['input_ids']
    lengths=np.array([len(x) for x in ids])
    # Tokenizer truncation preserves the terminal special token (unlike slicing).
    ids=tok(t.text.tolist(),truncation=True,max_length=PLAN['max_tokens'],add_special_tokens=True)['input_ids']
    manifest=dict(plan=PLAN,model=upstream['repo'],revision=upstream['revision'],device=device,
        dtype='float16' if device=='mps' else 'float32',rows=len(t),
        input_sha256=sha(ROOT/'data/train.csv'),code_sha256=sha(Path(__file__)),
        artifacts={p.name:sha(p) for p in [MODEL/'model.safetensors',MODEL/'config.json',MODEL/'tokenizer.json',MODEL/'1_Pooling/config.json']},
        truncated_rows=int((lengths>PLAN['max_tokens']).sum()),
        versions={k:__import__('importlib.metadata',fromlist=['version']).version(k) for k in ['torch','transformers','numpy']})
    signature=hashlib.sha256(json.dumps(manifest,sort_keys=True).encode()).hexdigest()
    mf=FEATURE/'manifest.json'
    if mf.exists():assert json.loads(mf.read_text())['signature']==signature,'stale style features'
    else:
        dump(mf,dict(manifest,signature=signature))
        np.save(FEATURE/'id.npy',t.id.astype(str).to_numpy(dtype=str))
        np.save(FEATURE/'text_sha256.npy',np.array([hashlib.sha256(x.encode()).hexdigest() for x in t.text]))
        np.save(FEATURE/'token_lengths.npy',lengths)
    assert np.array_equal(np.load(FEATURE/'id.npy'),t.id.astype(str))
    fp,dp=FEATURE/'features.npy',FEATURE/'done.npy'
    if fp.exists():X=np.load(fp,mmap_mode='r+');done=np.load(dp)
    else:
        X=np.lib.format.open_memmap(fp,mode='w+',dtype='float16',shape=(len(t),768));X[:]=np.nan;X.flush()
        done=np.zeros(len(t),bool);lib.npsave(dp,done)
    if done.all():print('Extraction already complete.',flush=True);return
    model=AutoModel.from_pretrained(MODEL,local_files_only=True,trust_remote_code=False,
        dtype=torch.float16 if device=='mps' else torch.float32,attn_implementation='sdpa').to(device).eval()
    order=np.argsort(-np.minimum(lengths,PLAN['max_tokens']),kind='stable');order=order[~done[order]]
    initial=int(done.sum());inference=time.perf_counter()
    for batch_no,s in enumerate(range(0,len(order),PLAN['batch'])):
        if max_batches and batch_no>=max_batches:break
        ix=order[s:s+PLAN['batch']]
        batch=tok.pad({'input_ids':[ids[i] for i in ix]},return_tensors='pt').to(device)
        with torch.inference_mode():
            hidden=model(**batch).last_hidden_state.float()
            mask=batch['attention_mask'].unsqueeze(-1)
            pooled=(hidden*mask).sum(1)/mask.sum(1)
        values=pooled.cpu().numpy();assert np.isfinite(values).all()
        X[ix]=values;X.flush();done[ix]=True;lib.npsave(dp,done)
        del batch,hidden,pooled,mask
        elapsed=time.perf_counter()-inference;rate=(int(done.sum())-initial)/max(elapsed,1e-6)
        if batch_no<3 or (batch_no+1)%40==0 or done.all():
            print(f'rows={done.sum()}/{len(t)} device={device} elapsed_s={time.perf_counter()-begin:.1f} ETA_s={(~done).sum()/rate:.1f}',flush=True)
    dump(OUT/'feature_manifest.json',dict(manifest,signature=signature))
    dump(OUT/'extraction_status.json',dict(signature=signature,rows_done=int(done.sum()),complete=bool(done.all()),
        elapsed_s=time.perf_counter()-begin,feature_sha256=sha(fp) if done.all() else None))
    del model
    if device=='mps':torch.mps.empty_cache()


def evaluate():
    start=time.perf_counter();assert np.load(FEATURE/'done.npy').all()
    t=lib.load_train(ROOT/'data/train.csv');y=t.y.to_numpy();S=lib.make_splits(t)
    assert np.array_equal(np.load(FEATURE/'id.npy'),t.id.astype(str))
    assert np.array_equal(np.load(FEATURE/'text_sha256.npy'),[hashlib.sha256(x.encode()).hexdigest() for x in t.text])
    X=np.asarray(np.load(FEATURE/'features.npy'),dtype=np.float32);assert np.isfinite(X).all()
    paths=[ROOT/f'kernels/twostage/out_full/out_{n}/s1_plain.npy' for n in ['q8','ll8']]
    paths.append(ROOT/'kernels/svc4/out/members/svc4_p190k/oof.npy')
    q,l,svc=[np.load(p) for p in paths];external=np.c_[lib.N(q),lib.N(l)]*3
    manifest=dict(plan=PLAN,feature_signature=json.loads((FEATURE/'manifest.json').read_text())['signature'],
        feature_sha256=sha(FEATURE/'features.npy'),code_sha256=sha(Path(__file__)),
        lib_sha256=sha(ROOT/'notebook/lib.py'),inputs={str(p.relative_to(ROOT)):sha(p) for p in paths},
        split_md5=hashlib.md5(S.tobytes()).hexdigest(),labels=lib.LABELS)
    signature=hashlib.sha256(json.dumps(manifest,sort_keys=True).encode()).hexdigest()
    dump(OUT/'evaluation_manifest.json',dict(manifest,signature=signature))
    predictions={k:np.full(len(t),-1) for k in ['baseline','style','selected']};folds=[]
    for f in range(5):
        path=OUT/f'fold{f}.json'
        if path.exists():r=json.loads(path.read_text());assert r['signature']==signature,'stale evaluation'
        else:
            tr,va,te=[S[f]==i for i in [0,1,2]]
            assert np.isnan(svc[f,tr]).all() and np.isfinite(svc[f,~tr]).all()
            scaler=StandardScaler().fit(X[tr]);A,V,E=[scaler.transform(X[z]) for z in [tr,va,te]]
            trials=[];chosen=None;chosen_head=None;style=None;style_t=None
            for name,Cs,a,v,e in [('style',PLAN['style_C'],A,V,E),
                ('hybrid',PLAN['hybrid_C'],np.c_[A,external[tr]],np.c_[V,external[va]],np.c_[E,external[te]])]:
                for C in Cs:
                    head=LogisticRegression(C=C,max_iter=PLAN['max_iter'],random_state=42).fit(a,y[tr])
                    assert head.n_iter_.max()<PLAN['max_iter'],'unconverged model'
                    trial=dict(name=name,C=C,iterations=int(head.n_iter_.max()),train_ba=float(ba(y[tr],head.predict(a))),
                        val_ba=float(ba(y[va],head.predict(v))),val_logloss=float(log_loss(y[va],head.predict_proba(v),labels=np.arange(18))))
                    trials.append(trial)
                    if name=='style' and (style is None or trial['val_logloss']<style['val_logloss']):
                        style=trial;style_t=head.predict(e)
                    if chosen is None or trial['val_logloss']<chosen['val_logloss']:
                        chosen=trial;chosen_head=head;pv,pt=[lib.N(head.decision_function(z)) for z in [v,e]]
            weights=lib.fit_weights([q[va],l[va],svc[f,va]],y[va])
            bv,bt=[lib.N(lib.blend([q[z],l[z],svc[f,z]],weights)) for z in [va,te]]
            alpha_trials=[dict(alpha=a,val_ba=float(ba(y[va],(bv+a*pv).argmax(1)))) for a in PLAN['alpha']]
            best=max(alpha_trials,key=lambda z:z['val_ba'])
            alpha=best['alpha'] if best['val_ba']>=alpha_trials[0]['val_ba']+PLAN['val_gain_required'] else 0.
            pred=dict(baseline=bt.argmax(1),style=style_t,selected=(bt+alpha*pt).argmax(1))
            r=dict(signature=signature,fold=f,chosen=chosen,style_chosen=style,trials=trials,alpha=alpha,
                alpha_trials=alpha_trials,test_indices=np.flatnonzero(te).tolist(),
                test={k:float(ba(y[te],p)) for k,p in pred.items()},prediction={k:p.tolist() for k,p in pred.items()})
            lib.atomic(OUT/f'head_fold{f}.joblib',lambda h:joblib.dump(dict(signature=signature,scaler=scaler,
                head=chosen_head,chosen=chosen,alpha=alpha,baseline_weights=weights,labels=lib.LABELS),h))
            dump(path,r)
        for k in predictions:predictions[k][r['test_indices']]=r['prediction'][k]
        folds.append(r);elapsed=time.perf_counter()-start
        print(f'fold={f} alpha={r["alpha"]} test={r["test"]} elapsed_s={elapsed:.1f} ETA_s={elapsed/(f+1)*(4-f):.1f}',flush=True)
    mask=predictions['selected']>=0
    result=dict(signature=signature,mean_test={k:float(np.mean([r['test'][k] for r in folds])) for k in predictions},
        pooled_test={k:float(ba(y[mask],v[mask])) for k,v in predictions.items()},
        selected_minus_baseline_ci95=paired_ci(y[mask],predictions['baseline'][mask],predictions['selected'][mask],t.prompt_id.to_numpy()[mask]),
        positive_rotations=sum(r['test']['selected']>r['test']['baseline'] for r in folds),
        elapsed_s=time.perf_counter()-start,submission_eligible=False,
        limitation='Historical repeatedly inspected gold and incomplete upstream baseline-cache provenance. '
                   'StyleDistance human-style benchmark performance is not exact-source LLM attribution evidence.')
    dump(OUT/'results.json',result);print(json.dumps(result,indent=2),flush=True)


if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--evaluate',action='store_true');ap.add_argument('--max-batches',type=int,default=0)
    args=ap.parse_args()
    with threadpool_limits(limits=2):
        if args.evaluate:evaluate()
        else:extract(args.max_batches)
