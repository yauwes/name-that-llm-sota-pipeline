"""E27: does style add signal beyond stacking external-only stage1 logits?

Preserve E26 outer folds, inner split and fixed alpha0.1. Compare logits-only,
style+logits, and a same-dimensional control whose style rows are shuffled
within each TRAINING prompt. Validation/test feature rows are never shuffled.
All transforms, C selection and refits respect the outer training boundary.
No competition submission; these remain repeatedly inspected historical gold.
"""
import os
os.environ.setdefault('OMP_NUM_THREADS','2')
os.environ.setdefault('OPENBLAS_NUM_THREADS','2')
import hashlib
import json
import sys
import time
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import balanced_accuracy_score as ba,log_loss
from sklearn.preprocessing import StandardScaler
from threadpoolctl import threadpool_limits

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'notebook'))
import lib
from closing_audit import paired_ci
from styledistance_probe import FEATURE,sha,dump

OUT=ROOT/'research/experiments/e27_nested_hybrid_style'
PLAN=dict(C=[.003,.03,.3],alpha=.1,max_iter=3000,inner_seed=20261103,
    inner_validation_prompts=24,logit_multiplier=3.,
    variants=['logits_only','hybrid_style','permuted_style'],
    outer='worker seed42 five folds:120train/30test prompts; all150prompts tested',
    inner='96train/24validation prompts; separate C choice by val logloss; refit120train',
    baseline='fixed mean of normalized host-adapted q8/ll8 OOF',
    fixed_alpha_source='E21/E26 protocol; not tuned against E27 outer test',
    primary='hybrid fusion minus logits-only fusion, paired prompt-bootstrap95%',
    capacity_control='permute style rows within each training prompt; same804dimensions as hybrid',
    submission_eligible=False)


def permute_within_prompt(A,groups,seed):
    rng=np.random.default_rng(seed);indices=np.arange(len(A))
    for group in np.unique(groups):
        ix=np.flatnonzero(groups==group);indices[ix]=rng.permutation(ix)
    assert np.array_equal(np.sort(indices),np.arange(len(A)))
    assert np.array_equal(groups[indices],groups)
    return A[indices]


def matrices(name,style,external,groups,train_mask,eval_mask,seed):
    if name=='logits_only':return external[train_mask],external[eval_mask],None
    scaler=StandardScaler().fit(style[train_mask])
    a,v=scaler.transform(style[train_mask]),scaler.transform(style[eval_mask])
    if name=='permuted_style':a=permute_within_prompt(a,groups[train_mask],seed)
    return np.c_[a,external[train_mask]],np.c_[v,external[eval_mask]],scaler


def fit(A,y,C):
    head=LogisticRegression(C=C,max_iter=PLAN['max_iter'],random_state=42).fit(A,y)
    assert head.n_iter_.max()<PLAN['max_iter'],'Unconverged head; do not promote'
    assert np.array_equal(head.classes_,np.arange(18))
    return head


def run():
    start=time.perf_counter();OUT.mkdir(parents=True,exist_ok=True)
    assert np.load(FEATURE/'done.npy').all()
    t=lib.load_train(ROOT/'data/train.csv');y=t.y.to_numpy();groups=t.prompt_id.to_numpy()
    assert np.array_equal(np.load(FEATURE/'id.npy'),t.id.astype(str))
    assert np.array_equal(np.load(FEATURE/'text_sha256.npy'),[hashlib.sha256(x.encode()).hexdigest() for x in t.text])
    style=np.asarray(np.load(FEATURE/'features.npy'),dtype=np.float32)
    assert style.shape==(len(t),768) and np.isfinite(style).all()
    prompts=pd.Series(t.prompt_id.unique()).sample(frac=1,random_state=42).tolist()
    fold=t.prompt_id.map({p:i%5 for i,p in enumerate(prompts)}).to_numpy()
    stage1=[ROOT/f'kernels/twostage/out_full/out_{tag}/s1_plain.npy' for tag in ['q8','ll8']]
    stage2=[ROOT/f'kernels/twostage/out_full/out_{tag}/oof_plain.npy' for tag in ['q8','ll8']]
    q,l,oq,ol=[np.load(p) for p in stage1+stage2]
    assert all(a.shape==(len(t),18) and np.isfinite(a).all() for a in [q,l,oq,ol])
    external=np.c_[lib.N(q),lib.N(l)]*PLAN['logit_multiplier']
    base=lib.N((lib.N(oq)+lib.N(ol))/2)
    worker=ROOT/'kernels/twostage/out_full/worker.py'
    assert 'fold = t.prompt_id.map({p: i % 5 for i, p in enumerate(pr)}).values' in worker.read_text()
    manifest=dict(plan=PLAN,labels=lib.LABELS,feature_manifest=json.loads((FEATURE/'manifest.json').read_text()),
        feature_sha256=sha(FEATURE/'features.npy'),inputs={str(p.relative_to(ROOT)):sha(p) for p in stage1+stage2+[worker,ROOT/'data/train.csv']},
        code_sha256=sha(Path(__file__)),lib_sha256=sha(ROOT/'notebook/lib.py'),
        fold_sha256=hashlib.sha256(fold.tobytes()).hexdigest(),
        limitation='Stage1 is external-only by archived worker; stage2 is matching host OOF. '
                   'Old cache lacks row IDs/base-model revisions and was not independently rerun. No fresh blind gold.')
    signature=hashlib.sha256(json.dumps(manifest,sort_keys=True).encode()).hexdigest()
    dump(OUT/'manifest.json',dict(manifest,signature=signature))
    names=['baseline']+PLAN['variants']+[n+'_head' for n in PLAN['variants']]
    predictions={name:np.full(len(t),-1) for name in names};folds=[]
    for f in range(5):
        path=OUT/f'fold{f}.json'
        if path.exists():
            r=json.loads(path.read_text());assert r['signature']==signature,'Stale E27 fold'
        else:
            outer=fold!=f;test=~outer
            eligible=np.array([p for i,p in enumerate(prompts) if i%5!=f])
            validation=np.random.default_rng(PLAN['inner_seed']+f).permutation(eligible)[:24]
            va=np.isin(groups,validation);tr=outer & ~va
            assert set(groups[tr]).isdisjoint(groups[va])
            assert set(groups[outer]).isdisjoint(groups[test])
            pred=dict(baseline=base[test].argmax(1));models={};records=[]
            for name in PLAN['variants']:
                A,V,_=matrices(name,style,external,groups,tr,va,20261127+f)
                trials=[]
                for C in PLAN['C']:
                    head=fit(A,y[tr],C)
                    trials.append(dict(C=C,iterations=int(head.n_iter_.max()),train_ba=float(ba(y[tr],head.predict(A))),
                        val_ba=float(ba(y[va],head.predict(V))),val_logloss=float(log_loss(y[va],head.predict_proba(V),labels=np.arange(18)))))
                chosen=min(trials,key=lambda r:r['val_logloss'])
                A,E,scaler=matrices(name,style,external,groups,outer,test,20261227+f)
                head=fit(A,y[outer],chosen['C']);scores=lib.N(head.decision_function(E))
                pred[name]=(base[test]+PLAN['alpha']*scores).argmax(1)
                pred[name+'_head']=scores.argmax(1)
                records.append(dict(name=name,dimensions=A.shape[1],trials=trials,chosen=chosen,
                    outer_refit_train_ba=float(ba(y[outer],head.predict(A))),refit_iterations=int(head.n_iter_.max())))
                models[name]=dict(head=head,scaler=scaler,chosen=chosen)
            r=dict(signature=signature,fold=f,variants=records,
                outer_train_prompts=len(np.unique(groups[outer])),outer_test_prompts=len(np.unique(groups[test])),
                test={k:float(ba(y[test],p)) for k,p in pred.items()},
                test_indices=np.flatnonzero(test).tolist(),prediction={k:p.tolist() for k,p in pred.items()})
            lib.atomic(OUT/f'heads_fold{f}.joblib',lambda h:joblib.dump(dict(signature=signature,plan=PLAN,labels=lib.LABELS,models=models),h))
            dump(path,r)
        for k in predictions:predictions[k][r['test_indices']]=r['prediction'][k]
        folds.append(r);elapsed=time.perf_counter()-start
        print(f'fold={f} test={r["test"]} elapsed_s={elapsed:.1f} ETA_s={elapsed/(f+1)*(4-f):.1f}',flush=True)
    assert all((p>=0).all() for p in predictions.values())
    comparisons=[('logits_only','hybrid_style'),('permuted_style','hybrid_style'),('baseline','hybrid_style'),('baseline','logits_only')]
    result=dict(signature=signature,plan=PLAN,mean_test={k:float(np.mean([r['test'][k] for r in folds])) for k in names},
        pooled_test={k:float(ba(y,p)) for k,p in predictions.items()},
        paired_ci95={b+' minus '+a:paired_ci(y,predictions[a],predictions[b],groups) for a,b in comparisons},
        positive_hybrid_vs_logits_folds=sum(r['test']['hybrid_style']>r['test']['logits_only'] for r in folds),
        test_rows=len(t),test_prompts=t.prompt_id.nunique(),test_coverage=1.,elapsed_s=time.perf_counter()-start,
        submission_eligible=False,limitation=manifest['limitation'])
    dump(OUT/'results.json',result);print(json.dumps(result,indent=2),flush=True)


if __name__=='__main__':
    with threadpool_limits(limits=2):run()
