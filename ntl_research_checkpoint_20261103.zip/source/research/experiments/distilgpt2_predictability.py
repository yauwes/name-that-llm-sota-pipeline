"""E28B: cost-qualified DistilGPT2 proxy; keep the same likelihood features.

The Qwen3-0.6B operational pilot remains archived and incomplete. No accuracy
claim compares the two backbones. DistilGPT2 is a component of the cited paper;
this single-model summary probe is still not a reproduction of its full system.
"""
import argparse
import copy
from pathlib import Path

from threadpoolctl import threadpool_limits
import predictability_reader as reader

reader.OUT=reader.ROOT/'research/experiments/e28_predictability_distilgpt2'
reader.FEATURE=reader.ROOT/'data/features/e28_predictability_distilgpt2'
reader.MODEL=reader.ROOT/'data/models/DistilGPT2'
reader.DOWNLOAD=reader.OUT/'download.json'
reader.PLAN=copy.deepcopy(reader.PLAN)
reader.PLAN.update(proxy='distilbert/distilgpt2',phase='E28B cost-qualified full-data pilot',
    wrapper_sha256=reader.sha(Path(__file__)))


if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--evaluate',action='store_true');ap.add_argument('--max-batches',type=int,default=0)
    args=ap.parse_args()
    with threadpool_limits(limits=2):
        if args.evaluate:reader.evaluate()
        else:reader.extract(args.max_batches)
