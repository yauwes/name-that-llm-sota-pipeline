"""Describe selected-fusion diversity; label-oracle is explicitly unservable."""
import json
from itertools import combinations

import numpy as np

from spectral_reader import ROOT, sha, dump
import lib


def run():
    t=lib.load_train(ROOT/'data/train.csv');y=t.y.to_numpy();pred={};hashes={}
    for name,directory in [('e38','e38_nonlinear_score_head'),('e39','e39_hierarchical_score_head')]:
        p=ROOT/'research/experiments'/directory;selected=np.full(len(t),-1);base=selected.copy();seen=np.zeros(len(t),bool)
        for f in range(5):
            path=p/f'fold{f}.json';r=json.loads(path.read_text());ix=np.array(r['test_indices'])
            assert not seen[ix].any();seen[ix]=True
            selected[ix]=r['prediction']['selected_fusion'];base[ix]=r['prediction']['baseline']
            hashes[str(path.relative_to(ROOT))]=sha(path)
        assert seen.all() and np.isin(selected,np.arange(18)).all()
        if 'baseline' in pred:assert np.array_equal(pred['baseline'],base)
        pred['baseline']=base;pred[name]=selected
    correct={k:p==y for k,p in pred.items()}
    macro=lambda mask:float(np.mean([mask[y==c].mean() for c in range(18)]))
    union=np.any(list(correct.values()),axis=0);base=correct['baseline']
    result=dict(rows=len(t),prompts=t.prompt_id.nunique(),
        balanced_accuracy={k:macro(v) for k,v in correct.items()},
        label_oracle_three_argmax_coverage=macro(union),
        rows_every_selected_classifier_wrong=int((~union).sum()),
        unique_extra_fixes_beyond_baseline=int((~base & union).sum()),
        shared_extra_fixes_e38_e39=int((~base & correct['e38'] & correct['e39']).sum()),
        prediction_disagreements={a+' versus '+b:int((pred[a]!=pred[b]).sum()) for a,b in combinations(pred,2)},
        input_sha256=hashes,
        interpretation='Descriptive overlap of three fixed, inner-selected argmax rules on historical OOF. Label-oracle uses unavailable true labels, cannot serve or submit, and is NOT an upper bound on score-level ensembling or future models. No new predictor was fitted or selected.',
        submission_eligible=False,new_submission_sent=False)
    dump(ROOT/'research/experiments/e39_hierarchical_score_head/selected_fusion_overlap.json',result)
    print(json.dumps(result,indent=2))


if __name__=='__main__':run()
