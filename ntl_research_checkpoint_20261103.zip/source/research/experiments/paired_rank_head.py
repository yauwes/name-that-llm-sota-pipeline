"""E24: prompt-paired column ranking added to ordinary row cross entropy.

The training prompt x source grid supplies paired supervision. At inference,
each passage is scored independently; no test grouping or assignment constraint.
Convex linear head, fixed C, train-only scaler/PCA, val-only lambda/alpha choice.
This is a research hypothesis inspired by symmetric contrastive objectives, not
a reproduction of CLIP or an evidence-backed competition submission.
"""
import os
os.environ.setdefault('OMP_NUM_THREADS','2')
os.environ.setdefault('OPENBLAS_NUM_THREADS','2')
import argparse
import hashlib
import json
import sys
import time
from pathlib import Path

import joblib
import numpy as np
from scipy.optimize import minimize
from scipy.special import logsumexp
from sklearn.decomposition import PCA
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import balanced_accuracy_score as ba,log_loss
from sklearn.preprocessing import StandardScaler
from threadpoolctl import threadpool_limits

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'notebook'))
import lib
from closing_audit import paired_ci

OUT=ROOT/'research/experiments/e24_paired_rank'
PLAN=dict(C=.003,lambda_column=[0.,.5,1.],max_iter=1000,
    features='train-only PCA128(q27_l16) + 3x row-normalized external-stage1 q8/ll8 logits',
    alpha=[0.,.05,.1,.2,.35],val_gain_required=.005,
    baseline='E19 external-stage1 q8+ll8+strict-rotation SVC, weights fit on val',
    selection='lambda by val logloss; alpha by val BA; tie prefers lambda0/baseline',
    negative_control='shuffle labels within each training prompt, head lambda1; standalone test only',
    scope='historical primary 70/15/15 rotations; no new gold, no hidden-test grouping')


def dump(path,value):
    lib.atomic(path,lambda f:f.write(json.dumps(value,indent=2).encode()))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def group_rows(y,groups,nclass):
    names,inverse=np.unique(groups,return_inverse=True)
    row=np.full((len(names),nclass),-1,dtype=int)
    assert len(np.unique(np.c_[inverse,y],axis=0))==len(y),'duplicate prompt-source pair'
    row[inverse,y]=np.arange(len(y))
    return row


def column_loss_grad(logits,rows):
    C=logits.shape[1]
    valid=rows>=0
    assert np.array_equal(np.sort(rows[valid]),np.arange(len(logits)))
    cube=logits[np.maximum(rows,0)].copy()
    cube[~valid]=-np.inf
    lp=cube-logsumexp(cube,axis=1,keepdims=True)
    diagonal=lp[:,np.arange(C),np.arange(C)]
    loss=-diagonal[valid].mean()
    gradient=np.exp(lp)
    gradient[:,np.arange(C),np.arange(C)]-=1.
    gradient*=valid[:,None,:]/valid.sum()
    result=np.zeros_like(logits)
    result[rows[valid]]=gradient[valid]
    return loss,result


def objective(theta,X,y,rows,C,lam):
    d=X.shape[1];K=rows.shape[1]
    W=theta[:d*K].reshape(d,K);bias=theta[d*K:]
    logits=X@W+bias
    lp=logits-logsumexp(logits,axis=1,keepdims=True)
    loss=-lp[np.arange(len(y)),y].mean()+.5/(C*len(y))*np.sum(W*W)
    G=np.exp(lp);G[np.arange(len(y)),y]-=1.;G/=len(y)
    if lam:
        cl,cg=column_loss_grad(logits,rows);loss+=lam*cl;G+=lam*cg
    grad=np.r_[(X.T@G+W/(C*len(y))).ravel(),G.sum(0)]
    return loss,grad


def fit_head(A,y,groups,lam):
    warm=LogisticRegression(C=PLAN['C'],max_iter=2000,random_state=42).fit(A,y)
    assert warm.n_iter_.max()<2000
    K=len(warm.classes_);assert np.array_equal(warm.classes_,np.arange(K))
    rows=group_rows(y,groups,K)
    initial=np.r_[warm.coef_.T.ravel(),warm.intercept_]
    opt=minimize(objective,initial,args=(A,y,rows,PLAN['C'],lam),jac=True,method='L-BFGS-B',
        options=dict(maxiter=PLAN['max_iter'],gtol=1e-6,ftol=1e-11,maxls=40))
    assert opt.success and opt.nit<PLAN['max_iter'],str(opt.message)
    d=A.shape[1]
    return dict(W=opt.x[:d*K].reshape(d,K),bias=opt.x[d*K:],lambda_column=lam,
        iterations=int(opt.nit),gradient_inf=float(np.abs(opt.jac).max()),objective=float(opt.fun))


def scores(head,A):return A@head['W']+head['bias']


def self_check():
    rng=np.random.default_rng(42)
    y=np.tile(np.arange(4),3)[:-1];groups=np.repeat(np.arange(3),4)[:-1]
    X=rng.normal(size=(len(y),5));rows=group_rows(y,groups,4)
    theta=rng.normal(scale=.1,size=24)
    for lam in [0.,.5,1.]:
        value,grad=objective(theta,X,y,rows,.3,lam)
        assert np.isfinite(value) and np.isfinite(grad).all()
        for i in rng.choice(len(theta),10,replace=False):
            delta=np.zeros_like(theta);delta[i]=1e-6
            numeric=(objective(theta+delta,X,y,rows,.3,lam)[0]-objective(theta-delta,X,y,rows,.3,lam)[0])/2e-6
            assert abs(grad[i]-numeric)<2e-7,(lam,i,grad[i],numeric)
    L=X@theta[:20].reshape(5,4)+theta[20:]
    cl,cg=column_loss_grad(L,rows)
    offset=rng.normal(size=(3,4));expanded=offset[groups]
    assert np.isclose(cl,column_loss_grad(L+expanded,rows)[0]),'column loss is not prompt-offset invariant'
    assert np.max(np.abs(cg.sum(0)))<1e-12,'column term must not train class intercepts'
    print('Analytic gradients, missing-source grid, prompt-offset invariance: OK',flush=True)


def alpha_choice(base,head,y):
    trials=[dict(alpha=a,val_ba=float(ba(y,(base+a*head).argmax(1)))) for a in PLAN['alpha']]
    best=max(trials,key=lambda r:r['val_ba'])
    a=best['alpha'] if best['val_ba']>=trials[0]['val_ba']+PLAN['val_gain_required'] else 0.
    return a,trials


def run():
    start=time.perf_counter();self_check();OUT.mkdir(parents=True,exist_ok=True)
    t=lib.load_train(ROOT/'data/train.csv');y=t.y.to_numpy();groups=t.prompt_id.to_numpy();S=lib.make_splits(t)
    paths=[ROOT/'kernels/reader/out/q27_l16.npy',ROOT/'kernels/twostage/out_full/out_q8/s1_plain.npy',
        ROOT/'kernels/twostage/out_full/out_ll8/s1_plain.npy',ROOT/'kernels/svc4/out/members/svc4_p190k/oof.npy']
    assert np.array_equal(np.load(paths[0].parent/'train_id.npy'),t.id.astype(str))
    X=np.array(np.load(paths[0],mmap_mode='r')[:len(t)],dtype=np.float32)
    q,l,svc=[np.load(p) for p in paths[1:]]
    assert q.shape==l.shape==(len(t),18) and svc.shape==(5,len(t),18)
    external=np.c_[lib.N(q),lib.N(l)]*3.
    manifest=dict(plan=PLAN,labels=lib.LABELS,inputs={str(p.relative_to(ROOT)):sha(p) for p in paths},
        train_sha256=sha(ROOT/'data/train.csv'),code_sha256=sha(Path(__file__)),
        lib_sha256=sha(ROOT/'notebook/lib.py'),split_md5=hashlib.md5(S.tobytes()).hexdigest(),
        limitation='Frozen historical cache; exact upstream revisions/external pool row provenance not fully reconstructed.')
    signature=hashlib.sha256(json.dumps(manifest,sort_keys=True).encode()).hexdigest()
    dump(OUT/'manifest.json',dict(manifest,signature=signature))
    predictions={k:np.full(len(t),-1) for k in ['baseline','ordinary','paired_selected','negative_control']}
    folds=[]
    for f in range(5):
        path=OUT/f'fold{f}.json'
        if path.exists():
            r=json.loads(path.read_text());assert r['signature']==signature,'stale completed fold'
        else:
            tr,va,te=[S[f]==i for i in [0,1,2]]
            assert np.isnan(svc[f,tr]).all() and np.isfinite(svc[f,~tr]).all()
            scaler=StandardScaler().fit(X[tr]);pca=PCA(128,svd_solver='randomized',iterated_power=3,random_state=42)
            Ap=pca.fit_transform(scaler.transform(X[tr]))
            Vp,Ep=[pca.transform(scaler.transform(X[z])) for z in [va,te]]
            A,V,E=[np.asarray(np.c_[p,external[z]],dtype=np.float64) for p,z in [(Ap,tr),(Vp,va),(Ep,te)]]
            weights=lib.fit_weights([q[va],l[va],svc[f,va]],y[va])
            bv,bt=[lib.N(lib.blend([q[z],l[z],svc[f,z]],weights)) for z in [va,te]]
            heads=[];trials=[]
            for lam in PLAN['lambda_column']:
                head=fit_head(A,y[tr],groups[tr],lam);heads.append(head)
                v=scores(head,V);train_score=scores(head,A)
                trials.append(dict(lambda_column=lam,iterations=head['iterations'],gradient_inf=head['gradient_inf'],
                    train_ba=float(ba(y[tr],train_score.argmax(1))),val_ba=float(ba(y[va],v.argmax(1))),
                    val_logloss=float(log_loss(y[va],lib.softmax(v),labels=np.arange(18)))))
            chosen=min(range(len(trials)),key=lambda i:trials[i]['val_logloss'])
            pv,pt=lib.N(scores(heads[chosen],V)),lib.N(scores(heads[chosen],E))
            ov,ot=lib.N(scores(heads[0],V)),lib.N(scores(heads[0],E))
            alpha,alpha_trials=alpha_choice(bv,pv,y[va]);ordinary_alpha,ordinary_trials=alpha_choice(bv,ov,y[va])
            shuffled=y[tr].copy();train_groups=groups[tr];rng=np.random.default_rng(20261103+f)
            for prompt in np.unique(train_groups):
                mask=train_groups==prompt;shuffled[mask]=rng.permutation(shuffled[mask])
            nc=fit_head(A,shuffled,train_groups,1.)
            pred=dict(baseline=bt.argmax(1),ordinary=(bt+ordinary_alpha*ot).argmax(1),
                paired_selected=(bt+alpha*pt).argmax(1),negative_control=scores(nc,E).argmax(1))
            r=dict(signature=signature,fold=f,val_trials=trials,chosen=trials[chosen],alpha=alpha,
                ordinary_alpha=ordinary_alpha,alpha_trials=alpha_trials,ordinary_alpha_trials=ordinary_trials,
                test={k:float(ba(y[te],p)) for k,p in pred.items()},
                test_indices=np.flatnonzero(te).tolist(),prediction={k:p.tolist() for k,p in pred.items()})
            lib.atomic(OUT/f'heads_fold{f}.joblib',lambda h:joblib.dump(dict(signature=signature,scaler=scaler,pca=pca,
                ordinary=heads[0],selected=heads[chosen],baseline_weights=weights,
                alpha=alpha,ordinary_alpha=ordinary_alpha,labels=lib.LABELS),h))
            dump(path,r)
        folds.append(r)
        for key in predictions:predictions[key][r['test_indices']]=r['prediction'][key]
        elapsed=time.perf_counter()-start
        print(f'fold={f} lambda={r["chosen"]["lambda_column"]} alpha={r["alpha"]} '
            f'test={r["test"]} elapsed_s={elapsed:.1f} ETA_s={elapsed/(f+1)*(4-f):.1f}',flush=True)
    mask=predictions['baseline']>=0
    ci=lambda a,b:paired_ci(y[mask],predictions[a][mask],predictions[b][mask],groups[mask])
    result=dict(signature=signature,plan=PLAN,mean_test={k:float(np.mean([r['test'][k] for r in folds])) for k in predictions},
        pooled_test={k:float(ba(y[mask],p[mask])) for k,p in predictions.items()},
        paired_ci95={'selected minus baseline':ci('baseline','paired_selected'),
                     'selected minus ordinary':ci('ordinary','paired_selected')},
        selected_nonzero_lambda_folds=sum(r['chosen']['lambda_column']>0 for r in folds),
        elapsed_s=time.perf_counter()-start,submission_eligible=False,
        limitation=manifest['limitation']+' Reuses historical prompts; frozen proxy head objective experiment, not champion CV.')
    dump(OUT/'results.json',result);print(json.dumps(result,indent=2),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--self-check',action='store_true');args=parser.parse_args()
    with threadpool_limits(limits=2):
        if args.self_check:self_check()
        else:run()
