"""E28: response-only proxy-LM predictability trajectories, bounded local memory.

Inspired by https://aclanthology.org/2026.findings-emnlp.2049/ : observed-token
log-probability, top-token log-probability and entropy. Add log rank; retain the
token trajectory and position-normalized summaries. Not a paper reproduction,
source-model likelihood, or white-box attribution of the18candidate generators.
"""
import os
os.environ.setdefault('OMP_NUM_THREADS','2')
os.environ.setdefault('OPENBLAS_NUM_THREADS','2')
os.environ.setdefault('TOKENIZERS_PARALLELISM','false')
import argparse
import hashlib
import json
import sys
import time
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import balanced_accuracy_score as ba,log_loss
from sklearn.preprocessing import StandardScaler
from threadpoolctl import threadpool_limits

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'notebook'))
import lib
from closing_audit import paired_ci
from spectral_reader import MODEL,sha,dump

OUT=ROOT/'research/experiments/e28_predictability'
FEATURE=ROOT/'data/features/e28_predictability'
CHANNELS=['observed_log_probability','top_log_probability','entropy_nats','log_rank']
SUMMARY=['mean','std','q10','q50','q90','min','max','lag1_correlation','position_slope']+[f'bin{i}_mean' for i in range(8)]
PLAN=dict(max_tokens=512,batch=4,logit_chunk=32,max_memory_fraction=.5,
    channels=CHANNELS,summary=SUMMARY,add_special_tokens=False,
    alignment='hidden position t predicts input token t+1; omit unconditioned first token and padding',
    C=[.003,.03,.3],hybrid_C=[.003,.03],max_iter=3000,
    alpha=[0.,.05,.1,.2,.35],val_gain_required=.005,
    selection='head by val logloss, alpha by val BA; train-only StandardScaler',
    scope='historical prompt rotations70/15/15; stage1 external-only + strict-rotation SVC baseline')


def token_statistics(logits,targets):
    """Float32 scores for one bounded token chunk; vocab is never held for all tokens."""
    import torch
    lp=torch.log_softmax(logits.float(),dim=-1)
    observed=lp.gather(1,targets[:,None]).squeeze(1)
    top=lp.max(-1).values
    entropy=-(lp.exp()*lp).sum(-1)
    rank=1+(lp>observed[:,None]).sum(-1)
    return torch.stack([observed,top,entropy,rank.float().log()],-1)


def summarize(trajectory):
    a=np.asarray(trajectory,dtype=np.float64);assert a.ndim==2 and a.shape[1]==4 and len(a)>0
    n=len(a);mu=a.mean(0);sd=a.std(0)
    if n>2:
        u,v=a[:-1],a[1:];du,dv=u-u.mean(0),v-v.mean(0)
        lag=(du*dv).sum(0)/np.maximum(np.sqrt((du*du).sum(0)*(dv*dv).sum(0)),1e-12)
    else:lag=np.zeros(4)
    position=np.linspace(-1,1,n) if n>1 else np.zeros(1)
    slope=(position[:,None]*(a-mu)).sum(0)/max((position*position).sum(),1e-12)
    blocks=np.array_split(a,8)
    values=[mu,sd,*np.quantile(a,[.1,.5,.9],axis=0),a.min(0),a.max(0),lag,slope]
    values.extend(block.mean(0) if len(block) else mu for block in blocks)
    result=np.stack(values).T.ravel().astype(np.float32)
    assert result.shape==(68,) and np.isfinite(result).all()
    return result


def self_check():
    import torch
    logits=torch.tensor([[0.,2.,-1.],[5.,5.,5.],[-2.,0.,3.]])
    targets=torch.tensor([1,0,0]);stats=token_statistics(logits,targets)
    assert torch.allclose(stats[:,0],-torch.nn.functional.cross_entropy(logits,targets,reduction='none'))
    assert torch.allclose(stats[:,3].exp(),torch.tensor([1.,1.,3.]))
    assert torch.all(stats[:,2]>=0) and torch.all(stats[:,2]<=np.log(3)+1e-6)
    constant=np.ones((9,4));s=summarize(constant).reshape(4,17)
    assert np.all(s[:,1]==0) and np.all(s[:,7:9]==0)
    assert np.isfinite(summarize(np.ones((1,4)))).all()
    print('Observed-token alignment formula, tied rank, entropy bounds and summary edge cases: OK',flush=True)


def extract(max_batches):
    import torch
    from transformers import AutoModelForCausalLM,AutoTokenizer
    self_check();begin=time.perf_counter();OUT.mkdir(parents=True,exist_ok=True);FEATURE.mkdir(parents=True,exist_ok=True)
    upstream=json.loads((ROOT/'research/experiments/e20_spectral_reader/download.json').read_text())
    t=pd.read_csv(ROOT/'data/train.csv');device='mps' if torch.backends.mps.is_available() else 'cpu'
    if device=='mps':torch.mps.set_per_process_memory_fraction(PLAN['max_memory_fraction'])
    tok=AutoTokenizer.from_pretrained(MODEL,local_files_only=True,trust_remote_code=False);tok.padding_side='right'
    if tok.pad_token_id is None:tok.pad_token=tok.eos_token
    ids=tok(t.text.tolist(),add_special_tokens=False,truncation=False)['input_ids'];lengths=np.array([len(x) for x in ids])
    ids=[a[:PLAN['max_tokens']] for a in ids];assert min(map(len,ids))>=2
    manifest=dict(plan=PLAN,model=upstream['repo'],revision=upstream['revision'],device=device,
        dtype='float16' if device=='mps' else 'float32',rows=len(t),
        code_sha256=sha(Path(__file__)),train_sha256=sha(ROOT/'data/train.csv'),
        artifacts={str(p.relative_to(MODEL)):sha(p) for p in [MODEL/'model.safetensors',MODEL/'config.json',MODEL/'tokenizer.json']},
        truncated_rows=int((lengths>PLAN['max_tokens']).sum()),
        feature_names=[f'{c}_{s}' for c in CHANNELS for s in SUMMARY])
    signature=hashlib.sha256(json.dumps(manifest,sort_keys=True).encode()).hexdigest()
    mf=FEATURE/'manifest.json'
    if mf.exists():assert json.loads(mf.read_text())['signature']==signature,'Stale likelihood extraction'
    else:
        dump(mf,dict(manifest,signature=signature));np.save(FEATURE/'id.npy',t.id.astype(str).to_numpy(dtype=str))
        np.save(FEATURE/'text_sha256.npy',np.array([hashlib.sha256(s.encode()).hexdigest() for s in t.text]));np.save(FEATURE/'token_lengths.npy',lengths)
    assert np.array_equal(np.load(FEATURE/'id.npy'),t.id.astype(str))
    assert np.array_equal(np.load(FEATURE/'text_sha256.npy'),[hashlib.sha256(s.encode()).hexdigest() for s in t.text])
    fp,tp,dp=FEATURE/'features.npy',FEATURE/'trajectory.npy',FEATURE/'done.npy'
    if fp.exists():X=np.load(fp,mmap_mode='r+');T=np.load(tp,mmap_mode='r+');done=np.load(dp)
    else:
        X=np.lib.format.open_memmap(fp,mode='w+',dtype='float32',shape=(len(t),68));X[:]=np.nan;X.flush()
        T=np.lib.format.open_memmap(tp,mode='w+',dtype='float16',shape=(len(t),PLAN['max_tokens']-1,4));T[:]=np.nan;T.flush()
        done=np.zeros(len(t),bool);lib.npsave(dp,done)
    if done.all():print('All likelihood rows already complete.',flush=True);return
    dtype=torch.float16 if device=='mps' else torch.float32
    model=AutoModelForCausalLM.from_pretrained(MODEL,local_files_only=True,trust_remote_code=False,dtype=dtype,attn_implementation='sdpa').to(device).eval()
    order=np.argsort(-np.minimum(lengths,PLAN['max_tokens']),kind='stable');order=order[~done[order]]
    initial=int(done.sum());inference=time.perf_counter()
    for batch_no,start in enumerate(range(0,len(order),PLAN['batch'])):
        if max_batches and batch_no>=max_batches:break
        ix=order[start:start+PLAN['batch']]
        batch=tok.pad({'input_ids':[ids[i] for i in ix]},return_tensors='pt').to(device)
        with torch.inference_mode():
            hidden=model.model(**batch,use_cache=False).last_hidden_state
            for j,i in enumerate(ix):
                n=len(ids[i])-1;parts=[]
                for k in range(0,n,PLAN['logit_chunk']):
                    stop=min(n,k+PLAN['logit_chunk'])
                    logits=model.lm_head(hidden[j,k:stop])
                    stats=token_statistics(logits,batch['input_ids'][j,k+1:stop+1])
                    values=stats.cpu().numpy();assert np.isfinite(values).all()
                    parts.append(values);del logits,stats
                trajectory=np.concatenate(parts);assert trajectory.shape==(n,4)
                T[i,:n]=trajectory;X[i]=summarize(trajectory)
        del hidden,batch
        T.flush();X.flush();done[ix]=True;lib.npsave(dp,done)
        duration=time.perf_counter()-inference;rate=(int(done.sum())-initial)/max(duration,1e-6)
        if batch_no<4 or (batch_no+1)%50==0 or done.all():
            print(f'rows={done.sum()}/{len(t)} device={device} elapsed_s={time.perf_counter()-begin:.1f} ETA_s={(~done).sum()/rate:.1f}'
                  +(f' allocated_MB={torch.mps.current_allocated_memory()/2**20:.1f}' if device=='mps' else ''),flush=True)
    dump(OUT/'feature_manifest.json',dict(manifest,signature=signature))
    dump(OUT/'extraction_status.json',dict(signature=signature,complete=bool(done.all()),rows_done=int(done.sum()),
        elapsed_s=time.perf_counter()-begin,feature_sha256=sha(fp) if done.all() else None,trajectory_sha256=sha(tp) if done.all() else None))
    del model
    if device=='mps':torch.mps.empty_cache()


def evaluate():
    begin=time.perf_counter();assert np.load(FEATURE/'done.npy').all()
    t=lib.load_train(ROOT/'data/train.csv');y=t.y.to_numpy();S=lib.make_splits(t)
    assert np.array_equal(np.load(FEATURE/'id.npy'),t.id.astype(str))
    X=np.asarray(np.load(FEATURE/'features.npy'),dtype=np.float32);assert X.shape==(len(t),68) and np.isfinite(X).all()
    paths=[ROOT/f'kernels/twostage/out_full/out_{tag}/s1_plain.npy' for tag in ['q8','ll8']]+[ROOT/'kernels/svc4/out/members/svc4_p190k/oof.npy']
    q,l,svc=[np.load(p) for p in paths];external=np.c_[lib.N(q),lib.N(l)]*3.
    manifest=dict(plan=PLAN,feature_signature=json.loads((FEATURE/'manifest.json').read_text())['signature'],
        feature_sha256=sha(FEATURE/'features.npy'),inputs={str(p.relative_to(ROOT)):sha(p) for p in paths},
        code_sha256=sha(Path(__file__)),split_md5=hashlib.md5(S.tobytes()).hexdigest(),labels=lib.LABELS)
    signature=hashlib.sha256(json.dumps(manifest,sort_keys=True).encode()).hexdigest();dump(OUT/'evaluation_manifest.json',dict(manifest,signature=signature))
    pred_all={k:np.full(len(t),-1) for k in ['baseline','likelihood','fusion']};folds=[]
    for f in range(5):
        fp=OUT/f'fold{f}.json'
        if fp.exists():r=json.loads(fp.read_text());assert r['signature']==signature,'Stale E28 evaluation'
        else:
            tr,va,te=[S[f]==i for i in [0,1,2]]
            assert np.isnan(svc[f,tr]).all() and np.isfinite(svc[f,~tr]).all()
            scaler=StandardScaler().fit(X[tr]);A,V,E=[scaler.transform(X[z]) for z in [tr,va,te]]
            best=None;standalone=None;trials=[];best_head=None
            for name,Cs,a,v,e in [('likelihood',PLAN['C'],A,V,E),('hybrid',PLAN['hybrid_C'],np.c_[A,external[tr]],np.c_[V,external[va]],np.c_[E,external[te]])]:
                for C in Cs:
                    head=LogisticRegression(C=C,max_iter=PLAN['max_iter'],random_state=42).fit(a,y[tr])
                    assert head.n_iter_.max()<PLAN['max_iter'],'Unconverged likelihood head'
                    trial=dict(name=name,C=C,iterations=int(head.n_iter_.max()),train_ba=float(ba(y[tr],head.predict(a))),
                        val_ba=float(ba(y[va],head.predict(v))),val_logloss=float(log_loss(y[va],head.predict_proba(v),labels=np.arange(18))))
                    trials.append(trial)
                    if name=='likelihood' and (standalone is None or trial['val_logloss']<standalone['val_logloss']):
                        standalone=trial;likelihood_pred=head.predict(e)
                    if best is None or trial['val_logloss']<best['val_logloss']:
                        best=trial;best_head=head;pv,pt=[lib.N(head.decision_function(z)) for z in [v,e]]
            weights=lib.fit_weights([q[va],l[va],svc[f,va]],y[va]);bv,bt=[lib.N(lib.blend([q[z],l[z],svc[f,z]],weights)) for z in [va,te]]
            alphas=[dict(alpha=a,val_ba=float(ba(y[va],(bv+a*pv).argmax(1)))) for a in PLAN['alpha']]
            chosen=max(alphas,key=lambda r:r['val_ba']);alpha=chosen['alpha'] if chosen['val_ba']>=alphas[0]['val_ba']+PLAN['val_gain_required'] else 0.
            pred=dict(baseline=bt.argmax(1),likelihood=likelihood_pred,fusion=(bt+alpha*pt).argmax(1))
            r=dict(signature=signature,fold=f,chosen=best,standalone=standalone,trials=trials,alpha=alpha,alpha_trials=alphas,
                test={k:float(ba(y[te],p)) for k,p in pred.items()},test_indices=np.flatnonzero(te).tolist(),prediction={k:p.tolist() for k,p in pred.items()})
            lib.atomic(OUT/f'head_fold{f}.joblib',lambda h:joblib.dump(dict(signature=signature,scaler=scaler,head=best_head,chosen=best,
                alpha=alpha,baseline_weights=weights,labels=lib.LABELS),h));dump(fp,r)
        for k in pred_all:pred_all[k][r['test_indices']]=r['prediction'][k]
        folds.append(r);elapsed=time.perf_counter()-begin
        print(f'fold={f} alpha={r["alpha"]} test={r["test"]} elapsed_s={elapsed:.1f} ETA_s={elapsed/(f+1)*(4-f):.1f}',flush=True)
    mask=pred_all['fusion']>=0
    result=dict(signature=signature,mean_test={k:float(np.mean([r['test'][k] for r in folds])) for k in pred_all},
        pooled_test={k:float(ba(y[mask],p[mask])) for k,p in pred_all.items()},
        paired_ci95=paired_ci(y[mask],pred_all['baseline'][mask],pred_all['fusion'][mask],t.prompt_id.to_numpy()[mask]),
        positive_folds=sum(r['test']['fusion']>r['test']['baseline'] for r in folds),elapsed_s=time.perf_counter()-begin,
        submission_eligible=False,limitation='Single small proxy LM, response-only summaries. Historical gold and incompletely manifested baseline caches; not paper reproduction or champion CV.')
    dump(OUT/'results.json',result);print(json.dumps(result,indent=2),flush=True)


if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--evaluate',action='store_true');ap.add_argument('--max-batches',type=int,default=0)
    args=ap.parse_args()
    with threadpool_limits(limits=2):
        if args.evaluate:evaluate()
        else:extract(args.max_batches)
