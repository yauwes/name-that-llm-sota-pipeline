import sys,numpy as np,re; sys.path.insert(0,'notebook'); import lib
from sklearn.feature_extraction.text import TfidfVectorizer as V
from sklearn.svm import LinearSVC
from sklearn.linear_model import LogisticRegression as LR
from sklearn.decomposition import PCA
from sklearn.metrics import balanced_accuracy_score as bas
t=lib.load_train('data/train.csv'); S=lib.make_splits(t); y=t.y.values; txt=np.array(t.text.tolist(),object); pr=t.prompt_id.values
R='kernels/twostage/out_full/'
svc=np.load('kernels/svc4/out/members/svc4_p190k/oof.npy'); q,l=[np.load(R+f'out_{k}/oof_plain.npy') for k in ('q8','ll8')]
ps=pd=None
import pandas as pd
pl=pd.Series(t.prompt_id.unique()).sample(frac=1,random_state=42).tolist(); fold=t.prompt_id.map({p:i%5 for i,p in enumerate(pl)}).values
Z=np.zeros((len(t),32768),np.float32)
for f in range(5): Z[fold==f]=np.load(R+f'out_q8/z_fold{f}.npy').astype(np.float32)
Zp=PCA(256,random_state=0).fit_transform(Z); Zp=(Zp-Zp.mean(0))/Zp.std(0); del Z
N=lib.N; X=V(analyzer='char_wb',ngram_range=(3,5),sublinear_tf=True,min_df=2,max_features=300000).fit_transform(txt)
def fit_sc(Xa,ya,w,Xb,kind):
    if kind=='svc': return LinearSVC(C=.5,class_weight='balanced').fit(Xa,ya,sample_weight=w).decision_function(Xb)
    return LR(C=.02,max_iter=400,class_weight='balanced').fit(Xa,ya,sample_weight=w).decision_function(Xb)
res={}
def add(k,v): res.setdefault(k,[]).append(v)
for f in range(5):
    tr,v,te=S[f]==0,S[f]==1,S[f]==2; un=v|te; ix=np.where(un)[0]
    for tname,T in (('svc',N(svc[f])),('q+l+svc',N(q)+N(l)+.5*N(svc[f]))):
        Pt=lib.softmax(T*1.5); conf=Pt.max(1); lab=T.argmax(1)
        add(f'teacher {tname}',bas(y[te],lab[te]))
        for kind,F in (('svc',X),('z',Zp)):
            base=fit_sc(F[tr],y[tr],np.ones(tr.sum()),F[te],kind); add(f'{tname}/{kind} student host only',bas(y[te],base.argmax(1)))
            for frac in (.5,1.):
                # pseudo rows are val+test rows, labelled by the teacher only, most confident fraction
                k=ix[np.argsort(-conf[ix])][:int(frac*len(ix))]; A=np.r_[np.where(tr)[0],k]; ya=np.r_[y[tr],lab[k]]; w=np.r_[np.ones(tr.sum()),np.full(len(k),.5)]
                s=fit_sc(F[A],ya,w,F[te],kind); add(f'{tname}/{kind} student pseudo{frac}',bas(y[te],s.argmax(1)))
                add(f'{tname}/{kind} T+base {frac}',bas(y[te],(N(T[te])+.5*N(base)).argmax(1))); add(f'{tname}/{kind} T+pseudo {frac}',bas(y[te],(N(T[te])+.5*N(s)).argmax(1)))
    print('rot',f,flush=True)
for k,v in res.items(): print(f'{k:40s} {np.mean(v):.4f} sd {np.std(v):.4f}')
