"""E31: fixed-alpha Gaussian grouping transfer to the stronger LoRA comparator.

Keep the outer folds, all E29/E30 sampled rows and alpha0.1 from E21/E26.
Do not tune alpha using any of these held-out predictions. Oracle groups remain
diagnostic only. No backbone or head retraining; no competition submission.
"""
import os
os.environ.setdefault('OMP_NUM_THREADS','2')
os.environ.setdefault('OPENBLAS_NUM_THREADS','2')
import hashlib
import json
import time
from pathlib import Path

import joblib
import numpy as np
from sklearn.metrics import recall_score
from threadpoolctl import threadpool_limits

import partial_group_audit as audit
from spectral_reader import ROOT,FEATURE as READER,LAYERS,sha,dump
import lib

OUT=ROOT/'research/experiments/e31_group_fusion_confirm'
E29=ROOT/'research/experiments/e29_partial_group_audit'
E30=ROOT/'research/experiments/e30_semantic_groups'
SEMANTIC=ROOT/'data/features/e30_semantic_groups'
PLAN=dict(alpha=.1,source='Pre-existing E21/E26 fixed alpha; no E31 test tuning',
    comparator='Mean normalized q8+ll8 matching outer-fold host-adapted OOF',
    variants=['baseline','single_fusion','qwen_group_fusion','semantic_group_fusion','oracle_fusion'],
    primary='semantic-group fusion minus baseline and minus qwen-group fusion',
    scope='Same partial-group rows as E29/E30; all Gaussian parameters frozen',submission_eligible=False)


def run():
    begin=time.perf_counter();OUT.mkdir(parents=True,exist_ok=True)
    t=lib.load_train(ROOT/'data/train.csv');y=t.y.to_numpy();groups=t.prompt_id.to_numpy()
    X=np.asarray(np.load(READER/'features.npy')[:,LAYERS.index(16),0,:],dtype=np.float32)
    C=np.asarray(np.load(SEMANTIC/'features.npy'),dtype=np.float32)
    for directory in [READER,SEMANTIC]:
        assert np.load(directory/'done.npy').all()
        assert np.array_equal(np.load(directory/'id.npy'),t.id.astype(str))
        assert np.array_equal(np.load(directory/'text_sha256.npy'),[hashlib.sha256(s.encode()).hexdigest() for s in t.text])
    paths=[ROOT/f'kernels/twostage/out_full/out_{n}/oof_plain.npy' for n in ['q8','ll8']]
    q,l=[np.load(p) for p in paths];assert q.shape==l.shape==(len(t),18) and np.isfinite(q).all() and np.isfinite(l).all()
    base=lib.N((lib.N(q)+lib.N(l))/2)
    worker=ROOT/'kernels/twostage/out_full/worker.py'
    assert 'fold = t.prompt_id.map({p: i % 5 for i, p in enumerate(pr)}).values' in worker.read_text()
    manifest=dict(plan=PLAN,code_sha256=sha(Path(__file__)),inputs={str(p.relative_to(ROOT)):sha(p) for p in paths+[worker,E29/'manifest.json',E30/'manifest.json']},
        gaussian_checkpoints={f:sha(E29/f'gaussian_fold{f}.joblib') for f in range(5)},
        limitation='Historical source/OOF scope follows archived worker; old LoRA caches lack complete original row/revision manifests. No independently retrained LoRA or fresh blind gold.')
    signature=hashlib.sha256(json.dumps(manifest,sort_keys=True).encode()).hexdigest();dump(OUT/'manifest.json',dict(manifest,signature=signature))
    pooled={}
    for f in range(5):
        fp=OUT/f'fold{f}.json'
        if fp.exists():r=json.loads(fp.read_text());assert r['signature']==signature,'Stale E31 fold'
        else:
            old=json.loads((E29/f'fold{f}.json').read_text());semantic=json.loads((E30/f'fold{f}.json').read_text())
            saved=joblib.load(E29/f'gaussian_fold{f}.joblib');assert saved['signature']==old['signature']
            prm=saved['params'];prediction={};indices={};records=[]
            for case in old['cases']:
                key=case['case'];ix=np.asarray(old['test_indices'][key]);U=audit.gauss.transform(X[ix],prm)
                gq=audit.clusters(X[ix],old['threshold']['threshold'])
                gs=audit.clusters(C[ix],semantic['threshold']['threshold'])
                oracle=np.unique(groups[ix],return_inverse=True)[1]
                assignments=dict(single_fusion=np.arange(len(ix)),qwen_group_fusion=gq,semantic_group_fusion=gs,oracle_fusion=oracle)
                pred=dict(baseline=base[ix].argmax(1))
                for name,labels in assignments.items():
                    lp=audit.gauss.scores(X[ix],labels,prm,U=U)
                    assert np.isfinite(lp).all()
                    pred[name]=(base[ix]+PLAN['alpha']*lib.N(lp)).argmax(1)
                present=np.unique(y[ix]);records.append(dict(case=key,rows=len(ix),present_classes=len(present),
                    present_class_macro_recall={m:float(recall_score(y[ix],p,labels=present,average='macro',zero_division=0)) for m,p in pred.items()}))
                indices[key]=ix.tolist();prediction[key]={m:p.tolist() for m,p in pred.items()}
            r=dict(signature=signature,fold=f,cases=records,test_indices=indices,prediction=prediction);dump(fp,r)
        for record in r['cases']:
            key=record['case'];pooled.setdefault(key,dict(indices=[],prediction={m:[] for m in PLAN['variants']}))
            pooled[key]['indices'].extend(r['test_indices'][key])
            for m in PLAN['variants']:pooled[key]['prediction'][m].extend(r['prediction'][key][m])
        elapsed=time.perf_counter()-begin;print(f'fold={f} elapsed_s={elapsed:.1f} ETA_s={elapsed/(f+1)*(4-f):.1f}',flush=True)
    summary={}
    for key,case in pooled.items():
        ix=np.asarray(case['indices']);truth=y[ix];present=np.unique(truth);pred={m:np.asarray(p) for m,p in case['prediction'].items()}
        summary[key]=dict(rows=len(ix),present_classes=len(present),balanced_accuracy18={m:float(recall_score(truth,p,labels=np.arange(18),average='macro',zero_division=0)) if len(present)==18 else None for m,p in pred.items()},
            intervals={b+' minus '+a:audit.paired_interval(truth,pred[a],pred[b],groups[ix]) for a,b in
                       [('baseline','semantic_group_fusion'),('qwen_group_fusion','semantic_group_fusion'),('semantic_group_fusion','oracle_fusion')]})
    result=dict(signature=signature,plan=PLAN,cases=summary,elapsed_s=time.perf_counter()-begin,submission_eligible=False,
        conclusion='Fixed-weight component transfer only; no measured gain over the official0.665champion, no alpha search on outer test.')
    dump(OUT/'results.json',result);print(json.dumps(result,indent=2),flush=True)


if __name__=='__main__':
    with threadpool_limits(limits=2):run()
