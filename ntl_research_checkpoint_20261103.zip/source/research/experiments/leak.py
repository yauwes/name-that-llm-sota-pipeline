import sys,numpy as np,pandas as pd; sys.path.insert(0,'notebook'); import lib
from sklearn.linear_model import LogisticRegression as LR
from sklearn.model_selection import GroupKFold,cross_val_predict
from sklearn.metrics import balanced_accuracy_score as bas
from sklearn.feature_extraction.text import CountVectorizer as C
t=lib.load_train('data/train.csv'); y=t.y.values; g=t.prompt_id.values; cv=GroupKFold(5)
print('chance',round(1/18,4),'rows',len(t),'dup text',t.text.duplicated().sum())
X=np.c_[t.index.values/len(t)]; print('row order',round(bas(y,cross_val_predict(LR(max_iter=500),X,y,groups=g,cv=cv)),4))
H=C(analyzer='char',ngram_range=(1,3),lowercase=False).fit_transform(t.id.astype(str)); print('id hex ngrams',H.shape,round(bas(y,cross_val_predict(LR(max_iter=300),H,y,groups=g,cv=cv)),4))
P2=C(analyzer='char',ngram_range=(1,3),lowercase=False).fit_transform(t.prompt_id.astype(str)); print('prompt id hex',round(bas(y,cross_val_predict(LR(max_iter=300),P2,y,groups=g,cv=cv)),4))
L=np.c_[t.text.str.len(),t.text.str.split().str.len(),t.text.str.endswith('.'),t.text.str.contains('\n'),t.text.str.startswith(' '),t.text.str.endswith(' ')].astype(float); L=(L-L.mean(0))/(L.std(0)+1e-9); print('length+edge',round(bas(y,cross_val_predict(LR(max_iter=500),L,y,groups=g,cv=cv)),4))
te=pd.read_csv('data/test.csv'); print('test rows',len(te),'visible overlap with train',te.text.isin(t.text).sum(),'id overlap',te.id.isin(t.id).sum())
try:
    p=pd.read_parquet('data/pool/ntl_open_pool.parquet',columns=['text','model']) if __import__('os').path.exists('data/pool/ntl_open_pool.parquet') else None
    if p is not None: print('pool exact train hits',t.text.isin(set(p.text)).sum())
except Exception as e: print(e)
