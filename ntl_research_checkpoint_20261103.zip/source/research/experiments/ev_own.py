import sys,numpy as np,torch,glob; sys.path.insert(0,'notebook'); import lib
t=lib.load_train('data/train.csv'); S=lib.make_splits(t); y=t.y.values; txt=t.text.tolist(); pr=t.prompt_id.values
R='kernels/twostage/out_full/'; ps=list(t.prompt_id.drop_duplicates())
# worker fold map: recover by which z_fold has the row count order
import re
src=open(R+'worker.py').read(); print([l for l in src.split('\n') if 'pr =' in l or 'pr=' in l][:3])
def rot(o):
    z=np.stack([o]*5).astype(np.float32)
    for f in range(5): z[f,S[f]==0]=np.nan
    return z
fold=None
exec([l for l in src.split('\n') if l.startswith('fold =')][0].join(["pr=sorted(t.prompt_id.unique()) if False else None\n",""]) if False else '')
members={}
for k in ('q8','ll8'):
    members[k]=rot(np.load(R+f'out_{k}/oof_plain.npy'))
svc4=np.load('kernels/svc4/out/members/svc4_p190k/oof.npy').astype(np.float32); members['svc4']=svc4
old=np.load('kernels/sparse7015/out/members/svc_p190k/oof.npy').astype(np.float32); members['svc_old']=old
def show(n,r): print(f"{n:28s} val {r['val']:.4f} test {r['test']:.4f} sd {r['test_sd']:.4f} mix {r['test_mix']:.4f} ci {np.round(r['ci'],3)} chosen {r['chosen']} w {np.round(r['weights'],2)} typo {r['typo']} rho {r['rho']}",flush=True)
for k,v in members.items(): show(k,lib.eval_scenario([v],y,txt,pr,S))
show('q8+ll8',lib.eval_scenario([members['q8'],members['ll8']],y,txt,pr,S))
show('q8+ll8+svc4',lib.eval_scenario([members[k] for k in ('q8','ll8','svc4')],y,txt,pr,S))
show('q8+ll8+svc4 typo sink',lib.eval_scenario([members[k] for k in ('q8','ll8','svc4')],y,txt,pr,S,typo=True,sink=True))
# twin on 2 answers per prompt
g=lib.pair_groups(pr); 
for k in ('q8','ll8'): pass
