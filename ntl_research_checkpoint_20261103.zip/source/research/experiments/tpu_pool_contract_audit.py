"""E36: audit the queued TPU input before spending hours on pretraining.

Group cardinality/coherence is a diagnostic, not proof every large group is
wrong or every small group is right. No raw text is written to public reports.
"""
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'research/experiments/e36_tpu_contract'


def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()


def summary(x):return {k:float(v) for k,v in zip(['p10','median','p90','mean'],[*np.percentile(x,[10,50,90]),x.mean()])}


def run():
    OUT.mkdir(exist_ok=True);path=ROOT/'data/e15/ntl_open_pool.parquet';r=pd.read_parquet(path)
    t=pd.read_csv(ROOT/'data/train.csv');pool=r.sample(frac=1,random_state=31).groupby('model').head(8000).reset_index(drop=True)
    assert set(pool.model)==set(t.model) and pool.notna().all().all()
    sizes=pool.groupby('prompt_group').size().sort_values(ascending=False)
    largest=pool[pool.prompt_group==sizes.index[0]].sample(500,random_state=36)
    # Coherence comparison: same vectorizer and representation for all cases.
    corpus=t.text.tolist()+largest.text.tolist()
    X=TfidfVectorizer(ngram_range=(1,2),stop_words='english',min_df=2,max_features=20000,dtype=np.float32).fit_transform(corpus)
    rng=np.random.default_rng(20263600);ids=np.arange(len(t));bygroup=list(t.groupby('prompt_id').indices.values())
    a,b=[],[]
    for _ in range(3000):
        i,j=rng.choice(bygroup[rng.integers(len(bygroup))],2,replace=False);a.append(i);b.append(j)
    positive=np.asarray(X[a].multiply(X[b]).sum(1)).ravel()
    a,b=[],[]
    while len(a)<3000:
        i,j=rng.choice(ids,2,replace=False)
        if t.prompt_id.iloc[i]!=t.prompt_id.iloc[j]:a.append(i);b.append(j)
    negative=np.asarray(X[a].multiply(X[b]).sum(1)).ravel()
    a,b=rng.integers(len(t),len(corpus),(2,3000));keep=a!=b
    coarse=np.asarray(X[a[keep]].multiply(X[b[keep]]).sum(1)).ravel()
    goldhash={hashlib.sha256(s.encode()).hexdigest() for s in t.text}
    local=ROOT/'kernels/tpu15/tpu15.py';server=ROOT/'research/live/20261104/tpu15_server/ntl-tpu15-unseen.py'
    expected=json.loads((ROOT/'research/live/20261104/tpu15_input_audit.json').read_text())['code_sha256']
    assert sha(server)==expected,'Pinned server snapshot changed'
    result=dict(pool_sha256=sha(path),code_sha256=sha(Path(__file__)),tpu_code_sha256=sha(server),
        local_code_sha256=sha(local),server_source_identical=local.read_bytes()==server.read_bytes(),
        concurrent_change_note='Local TPU source changed to a smoke mode after pinned server pull. Preserve that edit; do not push/cancel another job until ownership/version is reconciled.',
        raw_rows=len(r),capped_rows=len(pool),groups=len(sizes),max_group_size=int(sizes.max()),
        rows_in_groups_over18=int(sizes[sizes>18].sum()),same_group_triplet_rows=int((sizes//3).sum()*3),
        leftover_rows=int((sizes%3).sum()),duplicate_source_prompt_groups=int((pool.groupby(['prompt_group','model']).size()>1).sum()),
        flag_risk_rows=int(r.flag_gemini37_routing_risk.sum()),word_range_violation_rows=int((~r.n_words.between(30,300)).sum()),
        exact_gold_rows=int(r.text.map(lambda s:hashlib.sha256(s.encode()).hexdigest() in goldhash).sum()),
        top_group_ids=[dict(group=str(k),rows=int(v)) for k,v in sizes.head(8).items()],
        cosine_diagnostics=dict(gold_same_prompt=summary(positive),gold_different_prompt=summary(negative),largest_coarse_group=summary(coarse)),
        note='Unsupervised audit vectorizer sees the diagnostic corpus; not a train/test classifier evaluation or exact prompt-identity proof.',
        decision='Do not assume these metadata groups are real prompts. Stop unvalidated queued run. Test plain-CE-only stage1 in a separately named TPU smoke; retain true gold prompt centering only at stage2.',
        submission_eligible=False)
    (OUT/'results.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))


if __name__=='__main__':run()
