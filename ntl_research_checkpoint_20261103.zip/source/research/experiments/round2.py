"""Round 2, local CPU. Each mechanism gets its strength from val rows and is scored once on test rows. Baseline: q8+ll8+svc4 weighted on val."""
import json, sys, numpy as np, pandas as pd; sys.path.insert(0, 'notebook'); import lib
from sklearn.decomposition import PCA
from sklearn.linear_model import LogisticRegression as LR
from sklearn.metrics import balanced_accuracy_score as bas
t = lib.load_train('data/train.csv'); S = lib.make_splits(t); y = t.y.values; pr = t.prompt_id.values; N = lib.N; R = 'kernels/twostage/out_full/'
svc = np.load('kernels/svc4/out/members/svc4_p190k/oof.npy'); q, l = [np.load(R + f'out_{k}/oof_plain.npy') for k in ('q8', 'll8')]
pl = pd.Series(t.prompt_id.unique()).sample(frac=1, random_state=42).tolist(); fold = t.prompt_id.map({p: i % 5 for i, p in enumerate(pl)}).values
def pca(tag, d=256):
    Z = np.zeros((len(t), 32768), np.float32)
    for f in range(5): Z[fold == f] = np.load(R + f'out_{tag}/z_fold{f}.npy').astype(np.float32)
    P = PCA(d, random_state=0).fit_transform(Z); return (P - P.mean(0)) / P.std(0)
Zq, Zl = pca('q8'), pca('ll8'); Z = np.c_[Zq, Zl]; G = lib.pair_groups(pr, 2, 0)
def centre(A, g):
    A = A.copy()
    for k in np.unique(g): i = g == k; A[i] -= A[i].mean(0)
    return A
head = lambda A, ya, B, C=.02, w=None: LR(C=C, max_iter=500).fit(A, ya, sample_weight=w).decision_function(B)
FAM = lib.FAM; fams = [np.where(FAM == f)[0] for f in np.unique(FAM) if (FAM == f).sum() > 1]
def family_expert(tr, B):
    E = np.zeros((len(B), 18))
    for c in fams:
        m = np.isin(y[tr], c); s = head(Z[tr][m], y[tr][m], B, .02); s = s if s.ndim > 1 else np.c_[-s, s]; E[:, c] = N(s)
    return E
def bias_fit(X, yy, l2=.002, sweeps=3):
    b = np.zeros(18)
    for _ in range(sweeps):
        for c in range(18):
            g = [(bas(yy, (X + b + d * np.eye(18)[c]).argmax(1)) - l2 * abs(b[c] + d), d) for d in (-.4, -.2, -.1, 0, .1, .2, .4)]; b[c] += max(g)[1]
    return b
def soft_head(tr, teach, B, alpha):
    """KD by row expansion: (1-alpha) hard + alpha soft teacher targets, all rows are train side."""
    P = lib.softmax(teach[tr] * 1.5); n = len(tr); A = np.repeat(Z[tr], 18, 0); ya = np.tile(np.arange(18), n); w = (alpha * P + (1 - alpha) * np.eye(18)[y[tr]]).ravel(); k = w > 1e-3
    return LR(C=.02, max_iter=400).fit(A[k], ya[k], sample_weight=w[k]).decision_function(B)
out = {}; preds = {}
def rec(k, f, te, X): out.setdefault(k, []).append(bas(y[te], X.argmax(1))); preds.setdefault(k, np.full(len(y), -1))[te] = X.argmax(1)
def pick(Xv, Ev, yv, grid=(.25, .5, 1., 2.), margin=.003):
    b = {a: bas(yv, (Xv + a * Ev).argmax(1)) for a in grid}; a = max(b, key=b.get); return a if b[a] >= bas(yv, Xv.argmax(1)) + margin else 0.
for f in range(5):
    tr, v, te = [np.where(S[f] == i)[0] for i in (0, 1, 2)]; ms = [q, l, svc[f]]; w = lib.fit_weights([m[v] for m in ms], y[v]); T = lib.blend(ms, w); rec('base', f, te, T[te])
    # E1 per-class bias
    b = bias_fit(T[v], y[v]); rec('E1 class bias', f, te, T[te] + b)
    # E2 within-family experts
    E = family_expert(tr, Z); a = pick(T[v], E[v], y[v]); rec('E2 family expert', f, te, T[te] + a * E[te]); out.setdefault('E2 strength', []).append(a)
    # E3 twin on 2 answers per prompt, head fit on centred train pairs. True pairs are used, recovery precision was 0.964.
    Zc = centre(Z, G); W = head(Zc[tr], y[tr], Zc, .02); a = pick(T[v], N(W[v]), y[v]); rec('E3 twin head alone', f, te, W[te]); rec('E3 twin k=2', f, te, T[te] + a * N(W[te])); out.setdefault('E3 strength', []).append(a)
    # negative control: labels shuffled inside each train prompt
    rng = np.random.RandomState(f); ys = y.copy()
    for p in np.unique(pr[tr]): i = np.where(pr == p)[0]; ys[i] = rng.permutation(ys[i])
    rec('NC twin shuffled labels', f, te, head(Zc[tr], ys[tr], Zc[te], .02))
    # E4 stack of member scores fit on val rows only
    F = np.c_[N(q), N(l), N(svc[f])]; rec('E4 stack on val', f, te, head(F[v], y[v], F[te], .05))
    # E5 hard head against KD head, teacher q+l OOF on train rows, exploratory: those fold models saw other rows of this rotation
    H = head(Z[tr], y[tr], Z); a = pick(T[v], N(H[v]), y[v]); rec('E5 hard head alone', f, te, H[te]); rec('E5 T+hard head', f, te, T[te] + a * N(H[te]))
    K = soft_head(tr, N(q) + N(l), Z, .5); a = pick(T[v], N(K[v]), y[v]); rec('E5 KD head alone', f, te, K[te]); rec('E5 T+KD head', f, te, T[te] + a * N(K[te]))
    # E6 all that survived selection on val, together
    print('rot', f, {k: round(v[-1], 4) for k, v in out.items()}, flush=True)
m = preds['base'] >= 0; rng = np.random.RandomState(0); ups = np.unique(pr[m]); idx = {p: np.where((pr == p) & m)[0] for p in ups}; rows = []
for k, v in out.items():
    if k not in preds: rows.append(dict(exp=k, values=v)); continue
    d = []
    for _ in range(500):
        i = np.concatenate([idx[p] for p in rng.choice(ups, len(ups))]); d.append(bas(y[i], preds[k][i]) - bas(y[i], preds['base'][i]))
    r = dict(exp=k, test=round(float(np.mean(v)), 4), sd=round(float(np.std(v)), 4), delta=round(float(np.mean(v) - np.mean(out['base'])), 4), ci=[round(float(x), 4) for x in np.percentile(d, [2.5, 97.5])]); rows.append(r); print(r, flush=True)
json.dump(rows, open('research/experiments/round2.json', 'w'), indent=0)
