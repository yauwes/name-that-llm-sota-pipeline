"""E32: apply the EXISTING production group-size eligibility to E31 predictions.

Archived infer.py applies Gaussian evidence only to inferred groups of2..18.
E31 deliberately fused every row. Restore that serving condition without
searching a threshold/weight on test. Predictions can be gated exactly because
E31 fusion is rowwise; excluded rows return to their unchanged base argmax.
"""
import json
import time
from pathlib import Path

import numpy as np
from sklearn.metrics import recall_score
from threadpoolctl import threadpool_limits

import partial_group_audit as audit
from spectral_reader import ROOT,FEATURE as READER,LAYERS,sha,dump
import lib

OUT=ROOT/'research/experiments/e32_group_eligibility'
E29=ROOT/'research/experiments/e29_partial_group_audit'
E30=ROOT/'research/experiments/e30_semantic_groups'
E31=ROOT/'research/experiments/e31_group_fusion_confirm'
SEMANTIC=ROOT/'data/features/e30_semantic_groups'
SOURCE=ROOT/'research/checkpoints/failed_apex_v3/extracted/infer.py'


def run():
    begin=time.perf_counter();OUT.mkdir(parents=True,exist_ok=True)
    assert '_rows = (_sz >= 2) & (_sz <= 18)' in SOURCE.read_text()
    assert sha(Path(audit.__file__))==json.loads((E29/'manifest.json').read_text())['code_sha256']
    t=lib.load_train(ROOT/'data/train.csv');y=t.y.to_numpy();groups=t.prompt_id.to_numpy()
    X=np.asarray(np.load(READER/'features.npy')[:,LAYERS.index(16),0,:],dtype=np.float32)
    C=np.asarray(np.load(SEMANTIC/'features.npy'),dtype=np.float32)
    for directory in [READER,SEMANTIC]:assert np.array_equal(np.load(directory/'id.npy'),t.id.astype(str))
    manifest=dict(alpha=.1,eligibility='2<=inferred group size<=18, as in archived production source',
        code_sha256=sha(Path(__file__)),production_source_sha256=sha(SOURCE),helper_source_sha256=sha(Path(audit.__file__)),
        upstream={name:sha(path/'manifest.json') for name,path in [('e29',E29),('e30',E30),('e31',E31)]},
        scope='Historical serving-eligibility ablation; E31 all-row results already inspected, not a new blind confirmation.')
    import hashlib
    signature=hashlib.sha256(json.dumps(manifest,sort_keys=True).encode()).hexdigest();dump(OUT/'manifest.json',dict(manifest,signature=signature))
    pooled={}
    for f in range(5):
        a,b,old=[json.loads((p/f'fold{f}.json').read_text()) for p in [E29,E30,E31]]
        pred_f={};indices={};records=[]
        for case in old['cases']:
            key=case['case'];ix=np.asarray(old['test_indices'][key]);base=np.asarray(old['prediction'][key]['baseline'])
            assignments=dict(qwen_grouped_only=audit.clusters(X[ix],a['threshold']['threshold']),
                semantic_grouped_only=audit.clusters(C[ix],b['threshold']['threshold']),oracle_grouped_only=np.unique(groups[ix],return_inverse=True)[1])
            pred=dict(baseline=base);eligible_counts={}
            for name,labels in assignments.items():
                sizes=np.bincount(labels)[labels];eligible=(sizes>=2)&(sizes<=18)
                original={'qwen_grouped_only':'qwen_group_fusion','semantic_grouped_only':'semantic_group_fusion','oracle_grouped_only':'oracle_fusion'}[name]
                pred[name]=np.where(eligible,np.asarray(old['prediction'][key][original]),base)
                if not eligible.any():assert np.array_equal(pred[name],base)
                eligible_counts[name]=int(eligible.sum())
            present=np.unique(y[ix]);records.append(dict(case=key,rows=len(ix),eligible_rows=eligible_counts,present_classes=len(present),
                present_class_macro_recall={m:float(recall_score(y[ix],p,labels=present,average='macro',zero_division=0)) for m,p in pred.items()}))
            indices[key]=ix.tolist();pred_f[key]={m:p.tolist() for m,p in pred.items()}
            pooled.setdefault(key,dict(indices=[],prediction={m:[] for m in pred},eligible={m:0 for m in eligible_counts}))
            pooled[key]['indices'].extend(ix.tolist())
            for m,p in pred.items():pooled[key]['prediction'][m].extend(p.tolist())
            for m,n in eligible_counts.items():pooled[key]['eligible'][m]+=n
        dump(OUT/f'fold{f}.json',dict(signature=signature,fold=f,cases=records,test_indices=indices,prediction=pred_f))
    summary={}
    for key,case in pooled.items():
        ix=np.asarray(case['indices']);truth=y[ix];present=np.unique(truth);pred={m:np.asarray(p) for m,p in case['prediction'].items()}
        summary[key]=dict(rows=len(ix),present_classes=len(present),eligible_rows=case['eligible'],
            balanced_accuracy18={m:float(recall_score(truth,p,labels=np.arange(18),average='macro',zero_division=0)) if len(present)==18 else None for m,p in pred.items()},
            intervals={b+' minus '+a:audit.paired_interval(truth,pred[a],pred[b],groups[ix]) for a,b in
                       [('baseline','semantic_grouped_only'),('qwen_grouped_only','semantic_grouped_only')]})
    result=dict(signature=signature,cases=summary,elapsed_s=time.perf_counter()-begin,submission_eligible=False,
        limitation='Restores a documented serving condition; no independent gold, no champion CV, no tuning or new competition submission.')
    dump(OUT/'results.json',result);print(json.dumps(result,indent=2),flush=True)


if __name__=='__main__':
    with threadpool_limits(limits=2):run()
