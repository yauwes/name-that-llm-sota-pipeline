"""Fetch pinned official model/data inputs, never third-party executable code.

Public downloads only, no credentials required. Existing files are hash checked.
"""
import gzip
import hashlib
import json
import ssl
import urllib.request
from pathlib import Path

import certifi
from huggingface_hub import snapshot_download

ROOT=Path(__file__).resolve().parents[2]
REPO='Qwen/Qwen3-0.6B'
REVISION='c1899de289a04d12100db370d81485cdf75e47ca'


def run():
    spec=json.loads((ROOT/'research/live/20261103/reader_data_sources.json').read_text())
    assert spec['repository']=='LeoJeshua/READER'
    data=ROOT/'data/ext/reader_agent500';data.mkdir(parents=True,exist_ok=True)
    ctx=ssl.create_default_context(cafile=certifi.where())
    for entry in spec['files']:
        prefix=f'https://raw.githubusercontent.com/LeoJeshua/READER/{spec["revision"]}/data/agent500/responses/'
        assert entry['url'].startswith(prefix)
        target=data/Path(entry['path']).name
        if target.exists():content=target.read_bytes()
        else:
            with urllib.request.urlopen(entry['url'],context=ctx,timeout=60) as r:
                content=r.read(8*1024*1024)
        assert len(content)==entry['bytes']
        assert hashlib.sha1(f'blob {len(content)}\0'.encode()+content).hexdigest()==entry['git_blob_sha']
        records=[json.loads(line) for line in gzip.decompress(content).splitlines()]
        assert len(records)==500 and all(r['model_name']==entry['model'] for r in records)
        target.write_bytes(content)
        print(entry['model'],'500 records verified',flush=True)
    path=snapshot_download(REPO,revision=REVISION,local_dir=ROOT/'data/models/Qwen3-0.6B',token=False,
        allow_patterns=['config.json','model.safetensors','tokenizer.json','tokenizer_config.json',
                        'merges.txt','vocab.json','special_tokens_map.json','LICENSE','README.md'],max_workers=2)
    out=ROOT/'research/experiments/e20_spectral_reader';out.mkdir(parents=True,exist_ok=True)
    (out/'download.json').write_text(json.dumps(dict(repo=REPO,revision=REVISION,local_path=str(path)),indent=2))
    print('Pinned model inputs ready. No repository custom code executed.',flush=True)


if __name__=='__main__':run()
