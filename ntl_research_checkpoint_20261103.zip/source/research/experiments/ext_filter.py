"""Keep new rows only if they do not resemble any train prompt as much as the open pool's own limit, and pass its style checks."""
import numpy as np, pandas as pd, re
from sklearn.feature_extraction.text import TfidfVectorizer as V
n = pd.read_parquet('data/ext/new_rows.parquet'); t = pd.read_csv('data/train.csv', usecols=['text', 'prompt_id']); p = pd.read_parquet('data/pool/ntl_open_pool.parquet', columns=['max_cos_train', 'max_sim_train_prompt', 'flag_train_prompt_regen'])
print('open pool max_cos_train quantiles', p.max_cos_train.quantile([.5, .9, .99, 1]).round(3).tolist(), 'regen flag', p.flag_train_prompt_regen.mean().round(3), 'cos among unflagged max', p.max_cos_train[~p.flag_train_prompt_regen.astype(bool)].max().round(3))
v = V(sublinear_tf=True, stop_words='english', min_df=2, max_df=.2, dtype=np.float32); Xt = v.fit_transform(t.text); Xn = v.transform(n.text); c = np.zeros(len(n), np.float32); pid = t.prompt_id.values; sim = np.zeros(len(n), np.float32); uq = {u: np.where(pid == u)[0] for u in np.unique(pid)}
for s in range(0, len(n), 4000): c[s:s + 4000] = (Xn[s:s + 4000] @ Xt.T).max(axis=1).toarray().ravel()
n['max_cos_train'] = c; lim = float(p.max_cos_train[~p.flag_train_prompt_regen.astype(bool)].quantile(.99)); print('limit', round(lim, 3), 'new cos quantiles', np.round(np.quantile(c, [.5, .9, .99]), 3).tolist())
tx = n.text; style = tx.str.rstrip().str[-1].isin(list('.!?"”\'’)')) & ~tx.str.contains('\n') & ~tx.str.contains(r'\*\*|^#|\|') ; k = (c < lim) & style.values; print('pass cos', int((c < lim).sum()), 'pass style', int(style.sum()), 'kept', int(k.sum()))
f = n[k].reset_index(drop=True); f.to_parquet('data/ext/new_clean.parquet'); print(f.groupby('src').size().sort_values(ascending=False).head(10).to_string()); print(f.model.value_counts().to_string())
