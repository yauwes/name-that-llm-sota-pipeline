"""E29: oracle versus inferred groups under sparse prompt coverage.

Diagnostic adaptation of the archived shared-prompt Gaussian head, not champion
CV. Frozen Qwen3-0.6B DC layer16 has complete row/revision provenance. Train
only on120prompts; test30prompts with1/2/4/18responses each. Oracle groups and
full18-response context are deliberately non-serving diagnostic upper contexts.
"""
import os
os.environ.setdefault('OMP_NUM_THREADS','2')
os.environ.setdefault('OPENBLAS_NUM_THREADS','2')
import hashlib
import importlib.util
import json
import sys
import time
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.cluster import AgglomerativeClustering
from sklearn.metrics import recall_score
from threadpoolctl import threadpool_limits

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'notebook'))
import lib
from spectral_reader import FEATURE,LAYERS,sha,dump

SOURCE=ROOT/'research/checkpoints/failed_apex_v3/extracted/gauss.py'
# Inspected numerical functions only: numpy/sklearn, no IO/network/subprocess.
spec=importlib.util.spec_from_file_location('ntl_gauss_audited',SOURCE)
gauss=importlib.util.module_from_spec(spec);spec.loader.exec_module(gauss)
OUT=ROOT/'research/experiments/e29_partial_group_audit'
PLAN=dict(reader='Qwen3-0.6B DC layer16',outer='five seed42 folds,120train/30test prompts',
    partial_sizes=[1,2,4,18],seeds=[0,1,2],full_case_seeds=[0],
    gaussian=dict(red='wpca',d=64,se_shrink='lw',sp_shrink='lw',lam_floor=1e-4,n_exact=3,inj=True,iters=5,repel=True,sp_scale=1.),
    temperature=3.,pair_precision_target=.99,min_training_edges=20,
    cluster='complete-link cosine; threshold learned from all natural-prior training pairs; cap18',
    primary='same selected rows: oracle full-context minus oracle partial, and oracle partial minus inferred',
    limitation='Only30heldout prompts per clustering batch, not4000hidden rows. Oracle prompt IDs unavailable at serving; no submission.')


def threshold_fit(X,groups):
    unit=X/np.maximum(np.linalg.norm(X,axis=1,keepdims=True),1e-12)
    i,j=np.triu_indices(len(X),1);score=(unit@unit.T)[i,j]
    truth=groups[i]==groups[j];order=np.argsort(-score,kind='stable')
    score,truth=score[order],truth[order];tp=np.cumsum(truth);counts=np.arange(1,len(score)+1)
    ends=np.r_[score[1:]!=score[:-1],True]
    valid=ends & (counts>=PLAN['min_training_edges']) & (tp/counts>=PLAN['pair_precision_target'])
    if not valid.any():return dict(threshold=1.000001,train_edges=0,train_precision=None,train_recall=0.)
    ix=np.flatnonzero(valid)[-1]
    return dict(threshold=float(np.nextafter(score[ix],np.float32(-np.inf))),train_edges=int(counts[ix]),
        train_precision=float(tp[ix]/counts[ix]),train_recall=float(tp[ix]/truth.sum()))


def clusters(X,threshold):
    if len(X)<2 or threshold>1:return np.arange(len(X))
    unit=X/np.maximum(np.linalg.norm(X,axis=1,keepdims=True),1e-12)
    D=np.clip(1-unit@unit.T,0,2);np.fill_diagonal(D,0)
    labels=AgglomerativeClustering(n_clusters=None,metric='precomputed',linkage='complete',
        distance_threshold=max(1-threshold,1e-9),compute_full_tree=True).fit_predict(D)
    # A large cluster is unsafe for injective18-label inference: use singletons.
    next_id=int(labels.max())+1
    for g in np.unique(labels):
        ix=np.flatnonzero(labels==g)
        if len(ix)>18:labels[ix]=np.arange(next_id,next_id+len(ix));next_id+=len(ix)
    return np.unique(labels,return_inverse=True)[1]


def grouping_metrics(labels,truth,y):
    i,j=np.triu_indices(len(labels),1);a=labels[i]==labels[j];b=truth[i]==truth[j]
    tp=int((a&b).sum());fp=int((a&~b).sum());fn=int((~a&b).sum())
    sizes=np.bincount(labels)
    return dict(tp=tp,fp=fp,fn=fn,pair_precision=tp/(tp+fp) if tp+fp else None,
        pair_recall=tp/(tp+fn) if tp+fn else None,grouped_rows=int((sizes[labels]>1).sum()),
        max_group_size=int(sizes.max()),false_merged_groups=int(sum(len(np.unique(truth[labels==g]))>1 for g in np.unique(labels))),
        duplicate_source_groups=int(sum(len(np.unique(y[labels==g]))<sum(labels==g) for g in np.unique(labels))))


def paired_interval(y,a,b,groups):
    unique,inv=np.unique(groups,return_inverse=True);support=np.zeros((len(unique),18));diff=np.zeros_like(support)
    np.add.at(support,(inv,y),1);np.add.at(diff,(inv,y),(b==y).astype(float)-(a==y))
    draws=np.random.default_rng(20261129).integers(0,len(unique),(4000,len(unique)))
    total=support[draws].sum(1);d=diff[draws].sum(1);valid=(total>0).all(1)
    values=(d[valid]/total[valid]).mean(1)
    return dict(ci95=np.percentile(values,[2.5,97.5]).tolist() if len(values)>1000 else None,
                valid_draws=int(valid.sum()),requested_draws=4000,
                caveat='Prompt bootstrap conditional on resamples containing all18classes; sparse cases may exclude draws.')


def run():
    begin=time.perf_counter();OUT.mkdir(parents=True,exist_ok=True)
    t=lib.load_train(ROOT/'data/train.csv');y=t.y.to_numpy();groups=t.prompt_id.to_numpy()
    assert np.load(FEATURE/'done.npy').all()
    assert np.array_equal(np.load(FEATURE/'id.npy'),t.id.astype(str))
    assert np.array_equal(np.load(FEATURE/'text_sha256.npy'),[hashlib.sha256(s.encode()).hexdigest() for s in t.text])
    X=np.asarray(np.load(FEATURE/'features.npy')[:,LAYERS.index(16),0,:],dtype=np.float32)
    assert X.shape==(len(t),1024) and np.isfinite(X).all()
    prompts=pd.Series(t.prompt_id.unique()).sample(frac=1,random_state=42).tolist()
    fold=t.prompt_id.map({p:i%5 for i,p in enumerate(prompts)}).to_numpy()
    manifest=dict(plan=PLAN,labels=lib.LABELS,code_sha256=sha(Path(__file__)),gaussian_source_sha256=sha(SOURCE),
        train_sha256=sha(ROOT/'data/train.csv'),feature_sha256=sha(FEATURE/'features.npy'),
        feature_manifest=json.loads((FEATURE/'manifest.json').read_text()))
    signature=hashlib.sha256(json.dumps(manifest,sort_keys=True).encode()).hexdigest();dump(OUT/'manifest.json',dict(manifest,signature=signature))
    models=['singleton','oracle_partial','oracle_full_context','inferred','inferred_no_injection']
    cases=[(k,s) for k in PLAN['partial_sizes'] for s in (PLAN['full_case_seeds'] if k==18 else PLAN['seeds'])]
    pooled={f'k{k}_seed{s}':dict(indices=[],prediction={m:[] for m in models},diagnostics=[]) for k,s in cases}
    for f in range(5):
        fp=OUT/f'fold{f}.json'
        if fp.exists():r=json.loads(fp.read_text());assert r['signature']==signature,'Stale E29 fold'
        else:
            tr=fold!=f;te=~tr;ix=np.flatnonzero(te)
            threshold=threshold_fit(X[tr],groups[tr]);prm=gauss.fit(X[tr],y[tr],groups[tr],PLAN['gaussian'])
            prm['T1']=prm['Tg']=PLAN['temperature']
            U=gauss.transform(X[te],prm);g=np.unique(groups[te],return_inverse=True)[1]
            full=gauss.scores(X[te],g,prm,U=U).argmax(1)
            singleton=gauss.scores(X[te],np.arange(len(ix)),prm,U=U).argmax(1)
            records=[];test_indices={};prediction={}
            for k,seed in cases:
                rng=np.random.default_rng(20262900+f*10+seed)
                take=np.sort(np.concatenate([rng.choice(np.flatnonzero(g==v),min(k,sum(g==v)),replace=False) for v in np.unique(g)]))
                lab=clusters(X[ix[take]],threshold['threshold']);oracle=np.unique(g[take],return_inverse=True)[1]
                score=lambda labels,**cfg:gauss.scores(X[ix[take]],labels,prm,U=U[take],cfg=cfg).argmax(1)
                pred=dict(singleton=singleton[take],oracle_partial=score(oracle),oracle_full_context=full[take],
                    inferred=score(lab),inferred_no_injection=score(lab,inj=False,repel=False))
                diagnostics=grouping_metrics(lab,groups[ix[take]],y[ix[take]])
                key=f'k{k}_seed{seed}';present=np.unique(y[ix[take]])
                records.append(dict(case=key,rows=len(take),present_classes=len(present),grouping=diagnostics,
                    present_class_macro_recall={m:float(recall_score(y[ix[take]],p,labels=present,average='macro',zero_division=0)) for m,p in pred.items()}))
                test_indices[key]=ix[take].tolist();prediction[key]={m:p.tolist() for m,p in pred.items()}
            r=dict(signature=signature,fold=f,threshold=threshold,gaussian_info=prm['info'],cases=records,test_indices=test_indices,prediction=prediction)
            lib.atomic(OUT/f'gaussian_fold{f}.joblib',lambda h:joblib.dump(dict(signature=signature,params=prm,threshold=threshold,labels=lib.LABELS),h));dump(fp,r)
        for record in r['cases']:
            key=record['case'];pooled[key]['indices'].extend(r['test_indices'][key]);pooled[key]['diagnostics'].append(record['grouping'])
            for m in models:pooled[key]['prediction'][m].extend(r['prediction'][key][m])
        elapsed=time.perf_counter()-begin
        print(f'fold={f} threshold={r["threshold"]} elapsed_s={elapsed:.1f} ETA_s={elapsed/(f+1)*(4-f):.1f}',flush=True)
    summary={}
    for key,case in pooled.items():
        ix=np.asarray(case['indices']);truth=y[ix];pr=groups[ix];pred={m:np.array(p) for m,p in case['prediction'].items()};present=np.unique(truth)
        metrics={m:float(recall_score(truth,p,labels=np.arange(18),average='macro',zero_division=0)) if len(present)==18 else None for m,p in pred.items()}
        diag=case['diagnostics'];tp,fp,fn=[sum(d[k] for d in diag) for k in ['tp','fp','fn']]
        summary[key]=dict(rows=len(ix),prompts=len(np.unique(pr)),present_classes=len(present),balanced_accuracy18=metrics,
            pair_precision=tp/(tp+fp) if tp+fp else None,pair_recall=tp/(tp+fn) if tp+fn else None,
            grouped_rows=sum(d['grouped_rows'] for d in diag),false_merged_groups=sum(d['false_merged_groups'] for d in diag),
            duplicate_source_groups=sum(d['duplicate_source_groups'] for d in diag),
            intervals={b+' minus '+a:paired_interval(truth,pred[a],pred[b],pr) for a,b in [('oracle_partial','oracle_full_context'),('inferred','oracle_partial'),('inferred_no_injection','inferred')]})
    result=dict(signature=signature,plan=PLAN,cases=summary,elapsed_s=time.perf_counter()-begin,submission_eligible=False,
        conclusion='Oracle and inferred group diagnostics only; no gold hidden prompt IDs, no champion CV or deployable quality gain claimed.')
    dump(OUT/'results.json',result);print(json.dumps(result,indent=2),flush=True)


if __name__=='__main__':
    with threadpool_limits(limits=2):run()
