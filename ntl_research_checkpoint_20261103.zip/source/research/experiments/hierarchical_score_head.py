"""E39: soft provider×within-provider probabilities versus flat18class LR.

All selection uses inner prompts, fixed0.1 outer fusion. Class weights target
equal MODEL cost, not equal provider cost (providers contain unequal models).
Serializable checkpoints contain sklearn estimators and arrays only.
"""
import hashlib
import json
import time
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import balanced_accuracy_score as ba, log_loss
from sklearn.preprocessing import StandardScaler
from threadpoolctl import threadpool_limits

from spectral_reader import ROOT, sha, dump
from partial_group_audit import paired_interval
import lib

OUT=ROOT/'research/experiments/e39_hierarchical_score_head'
FAMILIES=np.unique(lib.FAM); FAMILY=np.array([list(FAMILIES).index(f) for f in lib.FAM])
PLAN=dict(C=[.01,.1,1.,10.],families=['flat','hierarchical'],alpha=.1,
    feature='36dim external-only q8+ll8 scores, each18dim row-normalized',
    transform='Train-only StandardScaler; no rowL2 after scaling',
    protocol='seed42 outer120train/30test prompts; inner96fit/24select; choose BA then logloss; refit120',
    hierarchy='Soft P(provider|x)*P(model|provider,x), no hard routing; singleton conditionals=1',
    weighting='Every estimator uses inverse training MODEL frequency sample weights. Provider prior remains proportional to model count, not uniform over6providers.',
    selection='Choose C and flat/hierarchical from inner labels; no outer comparator for selection',
    negative_control='Fixed hierarchical C1, labels permuted within training prompts',
    limitation='Historical repeatedly inspected gold; legacy external-score provenance incomplete. New head ablation, not championCV, fresh holdout or fullrawtext serving.')


def fit_head(X,y,C,kind):
    count=np.bincount(y,minlength=18);assert (count>0).all()
    w=len(y)/(18*count[y])
    def lr(A,b,weight):
        model=LogisticRegression(C=C,max_iter=1000,tol=1e-5).fit(A,b,sample_weight=weight)
        assert np.max(model.n_iter_)<model.max_iter, 'Unconverged LR'
        return model
    if kind=='flat':return dict(kind=kind,model=lr(X,y,w))
    provider=lr(X,FAMILY[y],w);conditional={}
    for f in range(len(FAMILIES)):
        classes=np.flatnonzero(FAMILY==f);m=FAMILY[y]==f
        conditional[f]=dict(classes=classes,model=lr(X[m],y[m],w[m]) if len(classes)>1 else None)
    return dict(kind=kind,provider=provider,conditional=conditional)


def probability(head,X):
    if head['kind']=='flat':
        assert np.array_equal(head['model'].classes_,np.arange(18))
        p=head['model'].predict_proba(X)
    else:
        p=np.zeros((len(X),18));provider=head['provider'].predict_proba(X)
        assert np.array_equal(head['provider'].classes_,np.arange(len(FAMILIES)))
        for f,r in head['conditional'].items():
            model=r['model'];classes=r['classes']
            if model is not None:assert np.array_equal(model.classes_,classes)
            within=model.predict_proba(X) if model is not None else np.ones((len(X),1))
            p[:,classes]=provider[:,f,None]*within
    assert np.isfinite(p).all() and (p>=0).all() and np.allclose(p.sum(1),1)
    p=np.asarray(p,dtype=np.float64);p/=p.sum(1,keepdims=True)
    return p


def run():
    start=time.perf_counter();OUT.mkdir(exist_ok=True);t=lib.load_train(ROOT/'data/train.csv');y=t.y.to_numpy();groups=t.prompt_id.to_numpy()
    paths=[ROOT/f'kernels/twostage/out_full/out_{tag}/{name}.npy' for name in ['s1_plain','oof_plain'] for tag in ['q8','ll8']]
    q,l,q2,l2=[np.load(p) for p in paths];assert all(a.shape==(len(t),18) and np.isfinite(a).all() for a in [q,l,q2,l2])
    X=np.concatenate([lib.N(q),lib.N(l)],1);base=lib.N((lib.N(q2)+lib.N(l2))/2)
    prompts=pd.Series(t.prompt_id.unique()).sample(frac=1,random_state=42).tolist();fold=t.prompt_id.map({p:i%5 for i,p in enumerate(prompts)}).to_numpy()
    manifest=dict(plan=PLAN,code_sha256=sha(Path(__file__)),train_sha256=sha(ROOT/'data/train.csv'),
        inputs={str(p.relative_to(ROOT)):sha(p) for p in paths},labels=lib.LABELS,provider_names=FAMILIES.tolist(),model_to_provider=FAMILY.tolist())
    signature=hashlib.sha256(json.dumps(manifest,sort_keys=True).encode()).hexdigest();mf=OUT/'manifest.json'
    if mf.exists():assert json.loads(mf.read_text())['signature']==signature
    else:dump(mf,dict(manifest,signature=signature))
    records=[]
    for f in range(5):
        fp=OUT/f'fold{f}.json'
        if fp.exists():r=json.loads(fp.read_text());assert r['signature']==signature
        else:
            tr=np.flatnonzero(fold!=f);te=np.flatnonzero(fold==f)
            tp=np.array([p for p in prompts if p in set(groups[tr])]);vp=tp[::5]
            fit=tr[~np.isin(groups[tr],vp)];va=tr[np.isin(groups[tr],vp)]
            scaler=StandardScaler().fit(X[fit]);A,V=[scaler.transform(X[i]) for i in [fit,va]];best={};trials=[]
            key=lambda z:(-z['val_ba'],z['val_logloss'])
            for kind in PLAN['families']:
                for C in PLAN['C']:
                    head=fit_head(A,y[fit],C,kind);p=probability(head,V)
                    trial=dict(kind=kind,C=C,val_ba=float(ba(y[va],p.argmax(1))),val_logloss=float(log_loss(y[va],p,labels=np.arange(18))))
                    trials.append(trial)
                    if kind not in best or key(trial)<key(best[kind]):best[kind]=trial
            chosen=min(best,key=lambda k:key(best[k]));scaler=StandardScaler().fit(X[tr]);A,E=[scaler.transform(X[i]) for i in [tr,te]]
            heads={};pred=dict(baseline=base[te].argmax(1));train_ba={}
            for kind,cfg in best.items():
                head=fit_head(A,y[tr],cfg['C'],kind);p=probability(head,E);heads[kind]=head
                pred[kind]=p.argmax(1);pred[kind+'_fusion']=(base[te]+PLAN['alpha']*lib.N(np.log(np.clip(p,1e-12,1)))).argmax(1)
                train_ba[kind]=float(ba(y[tr],probability(head,A).argmax(1)))
            pred['selected']=pred[chosen];pred['selected_fusion']=pred[chosen+'_fusion']
            perm=y[tr].copy();rng=np.random.default_rng(20263900+f)
            for g in np.unique(groups[tr]):
                ii=np.flatnonzero(groups[tr]==g);perm[ii]=rng.permutation(perm[ii])
            pred['label_permutation_control']=probability(fit_head(A,perm,1.,'hierarchical'),E).argmax(1)
            r=dict(signature=signature,fold=f,chosen=chosen,best=best,trials=trials,train_ba=train_ba,
                test={k:float(ba(y[te],p)) for k,p in pred.items()},test_indices=te.tolist(),prediction={k:p.tolist() for k,p in pred.items()})
            lib.atomic(OUT/f'heads_fold{f}.joblib',lambda h:joblib.dump(dict(signature=signature,scaler=scaler,heads=heads,chosen=chosen,
                labels=lib.LABELS,model_to_provider=FAMILY,training_indices=tr,all_gold_ids=t.id.astype(str).to_numpy()),h));dump(fp,r)
        records.append(r);elapsed=time.perf_counter()-start
        print('fold',f,'chosen',r['chosen'],'test',r['test'],'elapsed_s',round(elapsed,2),'ETA_s',round(elapsed/(f+1)*(4-f),2),flush=True)
    ix=np.concatenate([r['test_indices'] for r in records]);pred={k:np.concatenate([r['prediction'][k] for r in records]) for k in records[0]['prediction']}
    result=dict(signature=signature,mean_test={k:float(np.mean([r['test'][k] for r in records])) for k in pred},pooled_test={k:float(ba(y[ix],p)) for k,p in pred.items()},
        intervals={b+' minus '+a:paired_interval(y[ix],pred[a],pred[b],groups[ix]) for a,b in [('baseline','selected_fusion'),('flat_fusion','hierarchical_fusion')]},
        positive_folds=sum(r['test']['selected_fusion']>r['test']['baseline'] for r in records),elapsed_s=time.perf_counter()-start,submission_eligible=False)
    dump(OUT/'results.json',result);print(json.dumps(result,indent=2),flush=True)


if __name__=='__main__':
    with threadpool_limits(limits=2):run()
