"""E20: response-only length-normalized DC/first-AC reader, local Metal/CPU.

Source: https://arxiv.org/html/2606.10794v3 equation (3). This is an adaptation:
original prompts are unavailable, a 0.6B proxy is used, and K=1 only. Extraction
does not train on any labels. Never execute model repository custom code.

1. Resolve/download the official model at a pinned revision (download.json).
2. --max-batches 4 runs a memory/runtime smoke. Rerun without this limit to resume.
3. --evaluate fits all transforms on each rotation's training rows only.
"""
import os
os.environ.setdefault('OMP_NUM_THREADS', '2')
os.environ.setdefault('OPENBLAS_NUM_THREADS', '2')
os.environ.setdefault('TOKENIZERS_PARALLELISM', 'false')
import argparse
import hashlib
import json
import sys
import time
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from scipy.fft import dct
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import balanced_accuracy_score as ba, log_loss
from sklearn.preprocessing import StandardScaler
from threadpoolctl import threadpool_limits

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'notebook'))
import lib
from closing_audit import paired_ci

OUT = ROOT/'research/experiments/e20_spectral_reader'
MODEL = ROOT/'data/models/Qwen3-0.6B'
FEATURE = ROOT/'data/features/e20_spectral_reader'
LAYERS = [8, 16, 28]
PLAN = dict(layers=LAYERS, max_tokens=512, add_special_tokens=False, padding_side='right',
    modes=['DC', 'first_AC'], spectral_formula='gamma_r/T sum h_t cos(pi*r*(t+.5)/T)',
    batch=8, max_mps_memory_fraction=0.5, C=[0.0003, 0.003, 0.03],
    alpha=[0., 0.05, 0.1, 0.2, 0.35], val_gain_required=0.005,
    selection='separate best DC and DCAC by validation logloss; blend DCAC by val BA',
    max_iter=2000, scope='one response, no prompt context, no test grouping/accumulation')


def sha(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for b in iter(lambda: f.read(2**20), b''): h.update(b)
    return h.hexdigest()


def dump(path, value):
    lib.atomic(path, lambda f: f.write(json.dumps(value, indent=2).encode()))


def encode_trajectory(h):
    """h: valid response tokens x hidden dimensions; no pads/special tokens."""
    n = len(h)
    assert n > 0
    dc = h.mean(0, dtype=np.float32)
    weights = np.cos(np.pi*(np.arange(n)+0.5)/n)*np.sqrt(2)/n
    ac = weights.astype(np.float32) @ h
    if n == 1: ac = np.zeros_like(dc)
    return np.stack([dc, ac])


def self_check():
    rng = np.random.default_rng(42)
    for n in [1, 2, 5, 128]:
        h = rng.normal(size=(n, 8)).astype(np.float32)
        z = encode_trajectory(h)
        expected = dct(h, axis=0, type=2, norm='ortho')/np.sqrt(n)
        assert np.allclose(z[0], expected[0], atol=2e-6)
        assert np.allclose(z[1], expected[1] if n > 1 else 0, atol=2e-6)
        assert np.allclose(encode_trajectory(h+3)[1], z[1], atol=2e-6)
    print('DC/AC formula, one-token edge, offset invariance: OK', flush=True)


def extract(max_batches):
    import torch
    from transformers import AutoModel, AutoTokenizer
    start = time.perf_counter()
    self_check()
    OUT.mkdir(parents=True, exist_ok=True)
    FEATURE.mkdir(parents=True, exist_ok=True)
    upstream = json.loads((OUT/'download.json').read_text())
    t = pd.read_csv(ROOT/'data/train.csv')
    device = 'mps' if torch.backends.mps.is_available() else 'cpu'
    if device == 'mps':
        torch.mps.set_per_process_memory_fraction(PLAN['max_mps_memory_fraction'])
    tok = AutoTokenizer.from_pretrained(MODEL, local_files_only=True, trust_remote_code=False)
    tok.padding_side = 'right'
    if tok.pad_token is None: tok.pad_token = tok.eos_token
    ids = tok(t.text.tolist(), add_special_tokens=False, truncation=False)['input_ids']
    lengths = np.array([len(x) for x in ids])
    ids = [x[:PLAN['max_tokens']] for x in ids]
    manifest = dict(plan=PLAN, model=upstream['repo'], model_revision=upstream['revision'],
        train_sha256=sha(ROOT/'data/train.csv'), model_sha256=sha(MODEL/'model.safetensors'),
        config_sha256=sha(MODEL/'config.json'), tokenizer_sha256=sha(MODEL/'tokenizer.json'),
        code_sha256=sha(Path(__file__)), rows=len(t), device=device,
        dtype='float16' if device == 'mps' else 'float32',
        truncated_rows=int((lengths > PLAN['max_tokens']).sum()),
        versions={k:__import__('importlib.metadata',fromlist=['version']).version(k)
                  for k in ['torch','transformers','numpy']})
    signature = hashlib.sha256(json.dumps(manifest, sort_keys=True).encode()).hexdigest()
    statepath = FEATURE/'manifest.json'
    if statepath.exists():
        assert json.loads(statepath.read_text())['signature'] == signature, 'stale extraction scope'
    else:
        dump(statepath, dict(manifest, signature=signature))
        np.save(FEATURE/'id.npy',t.id.astype(str).to_numpy(dtype=str))
        np.save(FEATURE/'text_sha256.npy',np.array([hashlib.sha256(x.encode()).hexdigest() for x in t.text]))
        np.save(FEATURE/'token_lengths.npy',lengths)
    assert np.array_equal(np.load(FEATURE/'id.npy'),t.id.astype(str))
    assert np.array_equal(np.load(FEATURE/'text_sha256.npy'),
                          [hashlib.sha256(x.encode()).hexdigest() for x in t.text])
    fpath, dpath = FEATURE/'features.npy', FEATURE/'done.npy'
    if fpath.exists():
        feature = np.load(fpath, mmap_mode='r+')
        done = np.load(dpath) if dpath.exists() else np.zeros(len(t),bool)
    else:
        hidden = json.loads((MODEL/'config.json').read_text())['hidden_size']
        feature = np.lib.format.open_memmap(fpath,mode='w+',dtype='float16',
                                           shape=(len(t),len(LAYERS),2,hidden))
        feature[:] = np.nan
        feature.flush()
        done = np.zeros(len(t),bool)
    if done.all():
        print('All extraction rows already complete.',flush=True)
        return
    # Longest first: smoke exercises peak sequence memory; early ETA is conservative.
    order = np.argsort(-np.minimum(lengths, PLAN['max_tokens']),kind='stable')
    order = order[~done[order]]
    dtype = torch.float16 if device == 'mps' else torch.float32
    model = AutoModel.from_pretrained(MODEL, local_files_only=True, trust_remote_code=False,
                                    dtype=dtype,attn_implementation='sdpa').to(device).eval()
    initial_done = int(done.sum())
    inference_start = time.perf_counter()
    for batch_no,s in enumerate(range(0,len(order),PLAN['batch'])):
        if max_batches and batch_no >= max_batches: break
        ix = order[s:s+PLAN['batch']]
        batch = tok.pad({'input_ids':[ids[i] for i in ix]},return_tensors='pt').to(device)
        with torch.inference_mode():
            hs = model(**batch,output_hidden_states=True,use_cache=False).hidden_states
        for j,layer in enumerate(LAYERS):
            states = hs[layer].float().cpu().numpy()
            for b,i in enumerate(ix):
                z = encode_trajectory(states[b,:len(ids[i])])
                assert np.isfinite(z).all(), f'nonfinite spectral features at row {i}'
                feature[i,j] = z
        feature.flush()
        done[ix] = True
        lib.npsave(dpath,done)  # Commit completion only after the feature memmap flush.
        del hs,batch,states
        if device == 'mps': torch.mps.empty_cache()
        duration = time.perf_counter()-inference_start
        rate = (int(done.sum())-initial_done)/max(duration,1e-6)
        if batch_no < 4 or (batch_no+1)%25 == 0 or done.all():
            print(f'rows={done.sum()}/{len(t)} device={device} rows_s={rate:.3f} '
                  f'elapsed_s={time.perf_counter()-start:.1f} ETA_s={(~done).sum()/rate:.1f}'
                  +(f' allocated_MB={torch.mps.current_allocated_memory()/2**20:.1f}'
                    if device == 'mps' else ''),flush=True)
    dump(OUT/'extraction_status.json',dict(signature=signature,rows_done=int(done.sum()),
        rows_total=len(t),complete=bool(done.all()),elapsed_s=time.perf_counter()-start,
        device=device,feature_sha256=sha(fpath) if done.all() else None))
    dump(OUT/'feature_manifest.json',dict(manifest,signature=signature))
    del model
    if device == 'mps': torch.mps.empty_cache()


def evaluate():
    start = time.perf_counter()
    assert np.load(FEATURE/'done.npy').all(), 'extraction not complete'
    t = lib.load_train(ROOT/'data/train.csv')
    assert np.array_equal(np.load(FEATURE/'id.npy'),t.id.astype(str))
    y = t.y.to_numpy()
    S = lib.make_splits(t)
    X = np.load(FEATURE/'features.npy',mmap_mode='r')
    assert np.isfinite(X).all()
    q,l = [np.load(ROOT/f'kernels/twostage/out_full/out_{name}/s1_plain.npy') for name in ['q8','ll8']]
    svc = np.load(ROOT/'kernels/svc4/out/members/svc4_p190k/oof.npy')
    manifest = json.loads((FEATURE/'manifest.json').read_text())
    eval_manifest = dict(extraction_signature=manifest['signature'],plan=PLAN,
        code_sha256=sha(Path(__file__)),split_md5=hashlib.md5(S.tobytes()).hexdigest(),
        historical_baseline_inputs_sha256={name:sha(ROOT/path) for name,path in {
            'q8':'kernels/twostage/out_full/out_q8/s1_plain.npy',
            'll8':'kernels/twostage/out_full/out_ll8/s1_plain.npy',
            'svc':'kernels/svc4/out/members/svc4_p190k/oof.npy'}.items()})
    signature = hashlib.sha256(json.dumps(eval_manifest,sort_keys=True).encode()).hexdigest()
    dump(OUT/'evaluation_manifest.json',dict(eval_manifest,signature=signature))
    predictions={k:np.full(len(t),-1) for k in ['baseline','fusion','DC','DCAC']}
    folds=[]
    for f in range(5):
        foldpath=OUT/f'fold{f}.json'
        if foldpath.exists():
            r=json.loads(foldpath.read_text())
            assert r['signature']==signature,'stale evaluation fold'
        else:
            tr,va,te=[S[f]==i for i in [0,1,2]]
            assert np.isnan(svc[f,tr]).all() and np.isfinite(svc[f,~tr]).all()
            weights=lib.fit_weights([q[va],l[va],svc[f,va]],y[va])
            bv,bt=[lib.N(lib.blend([q[z],l[z],svc[f,z]],weights)) for z in [va,te]]
            best={};heads={};scores={};trials=[]
            for view,channels in [('DC',[0]),('DCAC',[0,1])]:
                for j,layer in enumerate(LAYERS):
                    a=np.array(X[:,j,channels,:]).reshape(len(t),-1)
                    scaler=StandardScaler().fit(a[tr]);A,V,E=[scaler.transform(a[z]) for z in [tr,va,te]]
                    for C in PLAN['C']:
                        head=LogisticRegression(C=C,max_iter=PLAN['max_iter'],random_state=42).fit(A,y[tr])
                        assert head.n_iter_.max()<PLAN['max_iter'],'unconverged head'
                        v=head.decision_function(V)
                        trial=dict(view=view,layer=layer,C=C,iterations=int(head.n_iter_.max()),
                            train_ba=float(ba(y[tr],head.predict(A))),
                            val_ba=float(ba(y[va],v.argmax(1))),
                            val_logloss=float(log_loss(y[va],head.predict_proba(V),labels=np.arange(18))))
                        trials.append(trial)
                        if view not in best or trial['val_logloss']<best[view]['val_logloss']:
                            best[view]=trial;heads[view]=(scaler,head)
                            scores[view]=(lib.N(v),lib.N(head.decision_function(E)))
            anchor=float(ba(y[va],bv.argmax(1)))
            choice=max([dict(alpha=a,val_ba=float(ba(y[va],(bv+a*scores['DCAC'][0]).argmax(1))))
                        for a in PLAN['alpha']],key=lambda z:z['val_ba'])
            alpha=choice['alpha'] if choice['val_ba']>=anchor+PLAN['val_gain_required'] else 0.
            pred=dict(baseline=bt.argmax(1),fusion=(bt+alpha*scores['DCAC'][1]).argmax(1),
                      **{view:scores[view][1].argmax(1) for view in ['DC','DCAC']})
            r=dict(signature=signature,fold=f,chosen=best,alpha=alpha,baseline_val_ba=anchor,
                   selected_val_ba=float(ba(y[va],(bv+alpha*scores['DCAC'][0]).argmax(1))),
                   val_trials=trials,test_indices=np.flatnonzero(te).tolist(),
                   test={key:float(ba(y[te],p)) for key,p in pred.items()},
                   prediction={key:p.tolist() for key,p in pred.items()})
            lib.atomic(OUT/f'heads_fold{f}.joblib',lambda h:joblib.dump(dict(
                signature=signature,heads=heads,config=best,alpha=alpha,
                baseline_weights=weights,labels=lib.LABELS),h))
            dump(foldpath,r)
        for key in predictions:predictions[key][r['test_indices']]=r['prediction'][key]
        folds.append(r)
        elapsed=time.perf_counter()-start
        print(f'fold={f} alpha={r["alpha"]} test={r["test"]} elapsed_s={elapsed:.1f} '
              f'ETA_s={elapsed/(f+1)*(4-f):.1f}',flush=True)
    mask=predictions['fusion']>=0
    ci=lambda a,b:paired_ci(y[mask],predictions[a][mask],predictions[b][mask],t.prompt_id.to_numpy()[mask])
    result=dict(signature=signature,mean_test={k:float(np.mean([r['test'][k] for r in folds])) for k in predictions},
        pooled_test={k:float(ba(y[mask],p[mask])) for k,p in predictions.items()},
        paired_ci95={'fusion minus baseline':ci('baseline','fusion'),'DCAC minus DC':ci('DC','DCAC')},
        positive_folds=sum(r['test']['fusion']>r['test']['baseline'] for r in folds),
        elapsed_s=time.perf_counter()-start,submission_eligible=False,
        note='Prompt-disjoint adaptation on historical gold. Single-response response-only small proxy; '
             'not the full READER multi-query evaluation and not the leaderboard champion.')
    dump(OUT/'results.json',result)
    print(json.dumps(result,indent=2),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--max-batches',type=int,default=0)
    parser.add_argument('--evaluate',action='store_true')
    parser.add_argument('--self-check',action='store_true')
    args=parser.parse_args()
    with threadpool_limits(limits=2):
        if args.self_check:self_check()
        elif args.evaluate:evaluate()
        else:extract(args.max_batches)
