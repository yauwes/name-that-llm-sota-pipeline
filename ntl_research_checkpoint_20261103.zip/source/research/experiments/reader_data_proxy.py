"""E22: cheap matched-count data-replacement qualification, not full-pool SOTA.

500 external rows/class, pool weight .35, frozen SVC4 recipe. For seven labels,
replace existing external rows with audited Agent500 train rows. All conditions
have identical class counts and weight totals; no prior/count confound. Keep 50
Agent500 prompt groups out of all fitting. Test only after validation selection.
"""
import os
os.environ.setdefault('OMP_NUM_THREADS','2')
os.environ.setdefault('OPENBLAS_NUM_THREADS','2')
import hashlib
import json
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import balanced_accuracy_score as ba
from threadpoolctl import threadpool_limits

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'notebook'))
import lib
from closing_audit import paired_ci

OUT=ROOT/'research/experiments/e22_reader_data'
PLAN=dict(cap_per_label=500,pool_weight=.35,replacement_fractions=[0.,1.],val_gain_required=.005,
    classifier='lib.svc4_fit_predict fixed C=.5',external_holdout='50 Agent500 prompt groups fixed by data audit',
    decision='choose replacement only if validation BA improves by >=.005; test once',
    checkpoint='fold logits/results; cheap proxy fit estimators discarded; no submission candidate')


def dump(path,value):
    lib.atomic(path,lambda f:f.write(json.dumps(value,indent=2).encode()))


def run():
    start=time.perf_counter()
    t=lib.load_train(ROOT/'data/train.csv');y=t.y.to_numpy();S=lib.make_splits(t)
    r=pd.read_parquet(ROOT/'data/ext/reader_agent500/audited.parquet')
    rt=r[r.eligible&~r.external_test].sample(frac=1,random_state=0)
    ext=r[r.eligible&r.external_test]
    assert set(rt.prompt_hash).isdisjoint(ext.prompt_hash)
    p=lib.load_pool(ROOT/'data/pool/ntl_open_pool.parquet')
    p,_=lib.leak_checks(t,S,p)
    pool=lib.cap_pool(p,PLAN['cap_per_label'],0)
    assert np.array_equal(np.bincount(pool.y,minlength=18),np.full(18,500))
    replacement=[]
    for label in range(18):
        old=pool[pool.y==label]
        new=rt[rt.y==label].head(len(old))
        replacement.append(pd.concat([old.head(len(old)-len(new))[['text','y']],new[['text','y']]]))
    replacement=pd.concat(replacement,ignore_index=True)
    assert np.array_equal(np.bincount(replacement.y,minlength=18),np.bincount(pool.y,minlength=18))
    conditions=[pool[['text','y']],replacement]
    audit=json.loads((OUT/'audit.json').read_text())
    manifest=dict(plan=PLAN,audit_sha256=hashlib.sha256((OUT/'audit.json').read_bytes()).hexdigest(),
        code_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        lib_sha256=hashlib.sha256((ROOT/'notebook/lib.py').read_bytes()).hexdigest(),
        split_md5=hashlib.md5(S.tobytes()).hexdigest(),labels=lib.LABELS,
        input_parquet_sha256=hashlib.sha256((ROOT/'data/ext/reader_agent500/audited.parquet').read_bytes()).hexdigest())
    assert manifest['input_parquet_sha256']==audit['audited_sha256']
    signature=hashlib.sha256(json.dumps(manifest,sort_keys=True).encode()).hexdigest()
    dump(OUT/'proxy_manifest.json',dict(manifest,signature=signature))
    preds={k:np.full(len(t),-1) for k in ['baseline','selected']};folds=[]
    for f in range(5):
        path=OUT/f'proxy_fold{f}.json'
        if path.exists():
            saved=json.loads(path.read_text());assert saved['signature']==signature,'stale proxy fold'
        else:
            tr,va,te=[S[f]==i for i in [0,1,2]]
            logits=[];trials=[]
            query=t.text[va].tolist()+t.text[te].tolist()+ext.text.tolist()
            for k,c in enumerate(conditions):
                scores=lib.svc4_fit_predict(t.text[tr].tolist()+c.text.tolist(),np.r_[y[tr],c.y],
                    np.r_[np.ones(tr.sum()),np.full(len(c),PLAN['pool_weight'])],query)
                assert np.isfinite(scores).all()
                v=scores[:va.sum()]
                logits.append(scores)
                trials.append(dict(replacement=PLAN['replacement_fractions'][k],validation_ba=float(ba(y[va],v.argmax(1)))))
                print(f'fold={f} replacement={k} val={trials[-1]["validation_ba"]:.4f} '
                      f'elapsed_s={time.perf_counter()-start:.1f}',flush=True)
            chosen=1 if trials[1]['validation_ba']>=trials[0]['validation_ba']+PLAN['val_gain_required'] else 0
            evaluate=lambda z:z[va.sum():va.sum()+te.sum()].argmax(1)
            b,s=map(evaluate,[logits[0],logits[chosen]])
            ep=logits[chosen][-len(ext):].argmax(1)
            ey=ext.y.to_numpy()
            saved=dict(signature=signature,fold=f,validation_trials=trials,chosen=chosen,
                baseline_test_ba=float(ba(y[te],b)),selected_test_ba=float(ba(y[te],s)),
                external_present_label_macro_recall=float(np.mean([(ep[ey==c]==c).mean() for c in np.unique(ey)])),
                external_labels=int(ext.y.nunique()),external_rows=len(ext),
                test_indices=np.flatnonzero(te).tolist(),baseline=b.tolist(),selected=s.tolist())
            # Local-only scores allow diagnostics without repeating sparse training.
            lib.npsave(OUT/f'proxy_logits_fold{f}.npy',np.stack(logits))
            dump(path,saved)
        for key in preds:preds[key][saved['test_indices']]=saved[key]
        folds.append(saved)
        elapsed=time.perf_counter()-start
        print(f'fold={f} test={saved["selected_test_ba"]:.4f} baseline={saved["baseline_test_ba"]:.4f} '
              f'elapsed_s={elapsed:.1f} ETA_s={elapsed/(f+1)*(4-f):.1f}',flush=True)
    m=preds['selected']>=0
    result=dict(signature=signature,plan=PLAN,mean_test={key:float(np.mean([r[f'{key}_test_ba'] for r in folds])) for key in preds},
        pooled_test={key:float(ba(y[m],p[m])) for key,p in preds.items()},
        paired_ci95=paired_ci(y[m],preds['baseline'][m],preds['selected'][m],t.prompt_id.to_numpy()[m]),
        positive_folds=sum(r['selected_test_ba']>r['baseline_test_ba'] for r in folds),
        selected_replacement_folds=sum(r['chosen']==1 for r in folds),
        external_present_label_macro_recall_mean=float(np.mean([r['external_present_label_macro_recall'] for r in folds])),
        elapsed_s=time.perf_counter()-start,submission_eligible=False,
        caveat='Small cap500 proxy, seven exact aliases only. Partial-label external recall is NOT '
               '18-class competition BA, and this is not the leaderboard champion. '
               'No inference-ready sparse estimator stored; source/config/fold scores are resumable.')
    dump(OUT/'results.json',result);print(json.dumps(result,indent=2),flush=True)


if __name__=='__main__':
    with threadpool_limits(limits=2):run()
