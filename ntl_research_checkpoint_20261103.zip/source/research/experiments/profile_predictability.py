"""Profile one real long batch; separate backbone, projection, stats and transfer.

No labels, model fitting or all-row extraction. Compare CPU versus MPS summary
arithmetic on identical projected logits before committing another large run.
"""
import json
import time
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from transformers import AutoModelForCausalLM,AutoTokenizer

from predictability_reader import ROOT,MODEL,token_statistics


def run():
    assert torch.backends.mps.is_available()
    torch.set_num_threads(2);torch.mps.set_per_process_memory_fraction(.5)
    tok=AutoTokenizer.from_pretrained(MODEL,local_files_only=True,trust_remote_code=False)
    if tok.pad_token_id is None:tok.pad_token=tok.eos_token
    text=pd.read_csv(ROOT/'data/train.csv').text.tolist()
    ids=tok(text,add_special_tokens=False,truncation=True,max_length=512)['input_ids']
    order=np.argsort([-len(x) for x in ids],kind='stable')[:4]
    batch=tok.pad({'input_ids':[ids[i] for i in order]},padding='max_length',max_length=512,return_tensors='pt').to('mps')
    start=time.perf_counter()
    model=AutoModelForCausalLM.from_pretrained(MODEL,local_files_only=True,trust_remote_code=False,
        dtype=torch.float16,attn_implementation='sdpa').to('mps').eval()
    torch.mps.synchronize();setup=time.perf_counter()-start
    results=[]
    with torch.inference_mode():
        for repeat in range(2):
            start=time.perf_counter();hidden=model.model(**batch,use_cache=False).last_hidden_state
            torch.mps.synchronize();decoder=time.perf_counter()-start
            for n in [32,128,256]:
                start=time.perf_counter();logits=model.lm_head(hidden[0,:n]);torch.mps.synchronize()
                projection=time.perf_counter()-start
                targets=batch['input_ids'][0,1:n+1]
                start=time.perf_counter();gpu_stats=token_statistics(logits,targets);torch.mps.synchronize()
                mps_stats=time.perf_counter()-start
                start=time.perf_counter();cpu_logits=logits.cpu();cpu_targets=targets.cpu();torch.mps.synchronize()
                transfer=time.perf_counter()-start
                start=time.perf_counter();cpu_stats=token_statistics(cpu_logits,cpu_targets)
                cpu_time=time.perf_counter()-start
                difference=float((cpu_stats-gpu_stats.cpu()).abs().max())
                row=dict(repeat=repeat,tokens=n,decoder_batch4_seconds=decoder,projection_seconds=projection,
                    mps_statistics_seconds=mps_stats,transfer_seconds=transfer,cpu_statistics_seconds=cpu_time,
                    max_abs_stats_difference=difference,allocated_MB=torch.mps.current_allocated_memory()/2**20,
                    driver_MB=torch.mps.driver_allocated_memory()/2**20)
                results.append(row);print(json.dumps(row),flush=True)
                del logits,gpu_stats,cpu_logits,cpu_targets,cpu_stats
            del hidden
    out=ROOT/'research/experiments/e28_predictability/profile.json'
    out.write_text(json.dumps(dict(setup_seconds=setup,cpu_threads=torch.get_num_threads(),
        recommended_memory_MB=torch.mps.recommended_max_memory()/2**20,results=results,
        scope='One longest real batch, two repeats; no attribution quality or all-row throughput claim.'),indent=2))
    del model;torch.mps.empty_cache()


if __name__=='__main__':run()
