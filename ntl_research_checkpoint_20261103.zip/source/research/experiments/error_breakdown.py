"""Aggregate saved outer-test errors without training or retuning from them."""
import argparse
import json
from pathlib import Path

import numpy as np
from sklearn.metrics import confusion_matrix, recall_score

from spectral_reader import ROOT, sha, dump
import lib


def analyze(directory, candidate):
    t = lib.load_train(ROOT/'data/train.csv'); y = t.y.to_numpy()
    records = [json.loads((directory/f'fold{f}.json').read_text()) for f in range(5)]
    ix = np.concatenate([r['test_indices'] for r in records])
    assert len(ix) == len(t) and np.array_equal(np.sort(ix), np.arange(len(t)))
    a, b = [np.concatenate([r['prediction'][key] for r in records]) for key in ['baseline', candidate]]
    assert a.shape == b.shape == ix.shape and np.isin(b, np.arange(18)).all()
    yy = y[ix]; aok = a == yy; bok = b == yy
    rec_a, rec_b = [recall_score(yy, p, labels=np.arange(18), average=None, zero_division=0) for p in [a,b]]
    per_class = [dict(model=label, support=int((yy==c).sum()),
        baseline_recall=float(rec_a[c]), candidate_recall=float(rec_b[c]),
        fixes=int((~aok & bok & (yy==c)).sum()), breaks=int((aok & ~bok & (yy==c)).sum())) for c,label in enumerate(lib.LABELS)]
    assert np.isclose(np.mean(rec_b), np.mean([r['candidate_recall'] for r in per_class]))
    words = t.text.str.split().str.len().to_numpy()[ix]; lengths = []
    for low, high in [(0,64),(64,100),(100,160),(160,np.inf)]:
        m = (words>low)&(words<=high); present = np.unique(yy[m])
        def score(p): return float(np.mean([(p[m & (yy==c)]==c).mean() for c in present])) if len(present) else None
        lengths.append(dict(words=f'({low},{high}]',rows=int(m.sum()),classes_present=len(present),
            baseline_ba_present_classes=score(a),candidate_ba_present_classes=score(b)))
    matrix = confusion_matrix(yy,b,labels=np.arange(18)); np.fill_diagonal(matrix,0)
    top = np.argsort(matrix.ravel())[::-1][:15]
    confusions = [dict(true=lib.LABELS[k//18],predicted=lib.LABELS[k%18],count=int(matrix.ravel()[k])) for k in top if matrix.ravel()[k]]
    within = lib.FAM[yy] == lib.FAM[b]; errors = ~bok
    prompts = t.prompt_id.to_numpy()[ix]
    deltas = np.array([(bok[prompts==p].mean()-aok[prompts==p].mean()) for p in np.unique(prompts)])
    result = dict(candidate=candidate,rows=len(ix),prompts=len(deltas),
        baseline_pooled_ba=float(rec_a.mean()),candidate_pooled_ba=float(rec_b.mean()),
        fixes=int((~aok & bok).sum()),breaks=int((aok & ~bok).sum()),changed_predictions=int((a!=b).sum()),
        errors=int(errors.sum()),fraction_errors_within_provider=float(within[errors].mean()),
        provider_accuracy=float(within.mean()),per_class=per_class,length_slices=lengths,top_confusions=confusions,
        per_prompt_accuracy_delta=dict(improved=int((deltas>0).sum()),worsened=int((deltas<0).sum()),unchanged=int((deltas==0).sum())),
        input_sha256={f'fold{f}.json':sha(directory/f'fold{f}.json') for f in range(5)},
        interpretation='Post-hoc descriptive error analysis on repeatedly inspected historical gold. Slices are not independent holdouts, probability calibration, hidden-test scores or permission to retune on outer tests.',
        new_submission_sent=False)
    dump(directory/'error_analysis.json',result)
    print(json.dumps({k:v for k,v in result.items() if k not in ['per_class','input_sha256']},indent=2))


if __name__ == '__main__':
    p=argparse.ArgumentParser();p.add_argument('directory',type=Path);p.add_argument('candidate');a=p.parse_args()
    analyze(a.directory,a.candidate)
