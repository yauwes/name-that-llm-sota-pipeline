"""E30: replace ONLY the grouping representation in the frozen E29 protocol.

Reuse all five Gaussian checkpoints, selected test rows, group-size cases and
temperatures. Learn a MiniLM cosine threshold from outer-training pairs only.
Compare inferred semantic groups with E29 inferred groups on identical rows.
"""
import os
os.environ.setdefault('OMP_NUM_THREADS','2')
os.environ.setdefault('OPENBLAS_NUM_THREADS','2')
import hashlib
import json
import sys
import time
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.metrics import recall_score
from threadpoolctl import threadpool_limits

import partial_group_audit as previous
from spectral_reader import FEATURE as READER_FEATURE,LAYERS,ROOT,sha,dump
sys.path.insert(0,str(ROOT/'notebook'))
import lib

FEATURE=ROOT/'data/features/e30_semantic_groups'
OUT=ROOT/'research/experiments/e30_semantic_groups'
OLD=ROOT/'research/experiments/e29_partial_group_audit'


def run():
    begin=time.perf_counter();assert np.load(FEATURE/'done.npy').all()
    t=lib.load_train(ROOT/'data/train.csv');y=t.y.to_numpy();groups=t.prompt_id.to_numpy()
    assert np.array_equal(np.load(FEATURE/'id.npy'),t.id.astype(str))
    assert np.array_equal(np.load(FEATURE/'text_sha256.npy'),[hashlib.sha256(s.encode()).hexdigest() for s in t.text])
    C=np.asarray(np.load(FEATURE/'features.npy'),dtype=np.float32)
    X=np.asarray(np.load(READER_FEATURE/'features.npy')[:,LAYERS.index(16),0,:],dtype=np.float32)
    assert C.shape==(len(t),384) and np.isfinite(C).all()
    old_manifest=json.loads((OLD/'manifest.json').read_text())
    prompts=pd.Series(t.prompt_id.unique()).sample(frac=1,random_state=42).tolist()
    fold=t.prompt_id.map({p:i%5 for i,p in enumerate(prompts)}).to_numpy()
    manifest=dict(plan='Same E29 Gaussian/cases; MiniLM cosine replaces QwenDC cosine in group inference only.',
        original_plan=previous.PLAN,previous_manifest_sha256=sha(OLD/'manifest.json'),
        gaussian_checkpoints={f:sha(OLD/f'gaussian_fold{f}.joblib') for f in range(5)},
        semantic_feature_sha256=sha(FEATURE/'features.npy'),semantic_manifest=json.loads((FEATURE/'manifest.json').read_text()),
        code_sha256=sha(Path(__file__)),helper_source_sha256=sha(Path(previous.__file__)),
        limitation='Small30prompt test batches and repeatedly inspected gold; no exact hidden group distribution or champion CV.')
    signature=hashlib.sha256(json.dumps(manifest,sort_keys=True).encode()).hexdigest();dump(OUT/'manifest.json',dict(manifest,signature=signature))
    pooled={}
    for f in range(5):
        fp=OUT/f'fold{f}.json'
        if fp.exists():r=json.loads(fp.read_text());assert r['signature']==signature,'Stale E30 fold'
        else:
            tr=fold!=f;ix=np.flatnonzero(~tr);old=json.loads((OLD/f'fold{f}.json').read_text())
            saved=joblib.load(OLD/f'gaussian_fold{f}.joblib');assert saved['signature']==old_manifest['signature']
            prm=saved['params'];U=previous.gauss.transform(X[ix],prm)
            threshold=previous.threshold_fit(C[tr],groups[tr]);records=[];prediction={};test_indices={}
            for case in old['cases']:
                key=case['case'];selected=np.asarray(old['test_indices'][key]);take=np.searchsorted(ix,selected)
                assert np.array_equal(ix[take],selected)
                g=previous.clusters(C[selected],threshold['threshold'])
                inferred=previous.gauss.scores(X[selected],g,prm,U=U[take]).argmax(1)
                diag=previous.grouping_metrics(g,groups[selected],y[selected])
                pred=dict(qwen_groups=np.asarray(old['prediction'][key]['inferred']),semantic_groups=inferred,
                    oracle_partial=np.asarray(old['prediction'][key]['oracle_partial']),
                    singleton=np.asarray(old['prediction'][key]['singleton']))
                present=np.unique(y[selected]);records.append(dict(case=key,rows=len(selected),present_classes=len(present),grouping=diag,
                    present_class_macro_recall={m:float(recall_score(y[selected],p,labels=present,average='macro',zero_division=0)) for m,p in pred.items()}))
                prediction[key]={m:p.tolist() for m,p in pred.items()};test_indices[key]=selected.tolist()
            r=dict(signature=signature,fold=f,threshold=threshold,cases=records,prediction=prediction,test_indices=test_indices)
            dump(fp,r)
        for record in r['cases']:
            key=record['case'];pooled.setdefault(key,dict(indices=[],prediction={m:[] for m in r['prediction'][key]},diagnostics=[]))
            pooled[key]['indices'].extend(r['test_indices'][key]);pooled[key]['diagnostics'].append(record['grouping'])
            for m in pooled[key]['prediction']:pooled[key]['prediction'][m].extend(r['prediction'][key][m])
        elapsed=time.perf_counter()-begin;print(f'fold={f} threshold={r["threshold"]} elapsed_s={elapsed:.1f} ETA_s={elapsed/(f+1)*(4-f):.1f}',flush=True)
    summary={}
    for key,case in pooled.items():
        ix=np.asarray(case['indices']);truth=y[ix];pred={m:np.asarray(p) for m,p in case['prediction'].items()};present=np.unique(truth)
        diag=case['diagnostics'];tp,fp,fn=[sum(d[k] for d in diag) for k in ['tp','fp','fn']]
        summary[key]=dict(rows=len(ix),present_classes=len(present),balanced_accuracy18={m:float(recall_score(truth,p,labels=np.arange(18),average='macro',zero_division=0)) if len(present)==18 else None for m,p in pred.items()},
            semantic_minus_qwen_ci=previous.paired_interval(truth,pred['qwen_groups'],pred['semantic_groups'],groups[ix]),
            pair_precision=tp/(tp+fp) if tp+fp else None,pair_recall=tp/(tp+fn) if tp+fn else None,
            grouped_rows=sum(d['grouped_rows'] for d in diag),false_merged_groups=sum(d['false_merged_groups'] for d in diag),
            duplicate_source_groups=sum(d['duplicate_source_groups'] for d in diag))
    result=dict(signature=signature,cases=summary,elapsed_s=time.perf_counter()-begin,submission_eligible=False,
        conclusion='Prompt-grouping representation ablation on a small Gaussian proxy, not a measured gain over the official0.665champion.')
    dump(OUT/'results.json',result);print(json.dumps(result,indent=2),flush=True)


if __name__=='__main__':
    with threadpool_limits(limits=2):run()
