"""E33 external context features; no source labels used for extraction/training.

3500 pre-existing READER Agent500 responses are stress context, not a simulated
draw from the hidden distribution. Persist row/text hashes, not raw passages.
Qwen prefix acceleration must reproduce the full model's hidden[16] first.
"""
import os
os.environ.setdefault('TOKENIZERS_PARALLELISM','false')
os.environ.setdefault('OMP_NUM_THREADS','2')
os.environ.setdefault('OPENBLAS_NUM_THREADS','2')
import argparse
import hashlib
import json
import time
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from transformers import AutoModel,AutoTokenizer

from spectral_reader import ROOT,sha,dump,FEATURE as GOLD_READER,LAYERS
from lib import npsave

DATA=ROOT/'data/ext/reader_agent500/audited.parquet'
OUT=ROOT/'research/experiments/e33_large_context'
FEATURE=ROOT/'data/features/e33_large_context'
MODELS=dict(semantic='MiniLM-L6-v2',dc16='Qwen3-0.6B')
UPSTREAM=dict(semantic='e30_semantic_groups',dc16='e20_spectral_reader')
PLAN=dict(rows='All3500 audited external rows, stable parquet order; no source-label filtering',
    scope='Unlabeled context only; no threshold fitting, classifier training or test-weight selection',
    semantic=dict(max_tokens=256,batch=32,pooling='official masked mean plus L2'),
    dc16=dict(max_tokens=512,batch=8,layer=16,pooling='valid-token float32 mean; no EOS/specials',
        prefix='first16layers, no final norm; fail closed on full-model parity',
        prefix_max_abs_tolerance=1e-5,cache_relative_l2_tolerance=.01))


def dc_values(h,lengths):
    a=h.float().cpu().numpy()
    return np.stack([a[j,:n].mean(0,dtype=np.float32) for j,n in enumerate(lengths)])


def run(kind,max_batches):
    begin=time.perf_counter();OUT.mkdir(exist_ok=True);folder=FEATURE/kind;folder.mkdir(parents=True,exist_ok=True)
    torch.set_num_threads(2)
    r=pd.read_parquet(DATA);texts=r.text.tolist()
    assert len(r)==3500 and all(isinstance(s,str) and s.strip() for s in texts)
    hashes=np.array([hashlib.sha256(s.encode()).hexdigest() for s in texts])
    ids=np.array([f'agent500-row{i}-{h[:16]}' for i,h in enumerate(hashes)])
    device='mps' if torch.backends.mps.is_available() else 'cpu'
    if device=='mps':torch.mps.set_per_process_memory_fraction(.5)
    modeldir=ROOT/'data/models'/MODELS[kind];plan=PLAN[kind]
    tok=AutoTokenizer.from_pretrained(modeldir,local_files_only=True,trust_remote_code=False)
    tok.padding_side='right'
    if tok.pad_token is None:tok.pad_token=tok.eos_token
    kwargs=dict(add_special_tokens=False) if kind=='dc16' else {}
    full=tok(texts,truncation=False,**kwargs)['input_ids'];lengths=np.array([len(a) for a in full])
    token=tok(texts,truncation=True,max_length=plan['max_tokens'],**kwargs)
    up=json.loads((ROOT/'research/experiments'/UPSTREAM[kind]/'download.json').read_text())
    artifact_names=['model.safetensors','config.json','tokenizer.json']
    if kind=='semantic':artifact_names+=['1_Pooling/config.json']
    manifest=dict(plan=PLAN,kind=kind,rows=len(r),data_sha256=sha(DATA),code_sha256=sha(Path(__file__)),
        model=up['repo'],revision=up['revision'],device=device,dtype='float16' if device=='mps' else 'float32',
        truncated_rows=int((lengths>plan['max_tokens']).sum()),
        artifacts={name:sha(modeldir/name) for name in artifact_names},
        versions={k:__import__('importlib.metadata',fromlist=['version']).version(k) for k in ['torch','transformers','numpy']})
    signature=hashlib.sha256(json.dumps(manifest,sort_keys=True).encode()).hexdigest()
    mf=folder/'manifest.json'
    if mf.exists():assert json.loads(mf.read_text())['signature']==signature,'Stale external features'
    else:
        dump(mf,dict(manifest,signature=signature));np.save(folder/'id.npy',ids)
        np.save(folder/'text_sha256.npy',hashes);np.save(folder/'token_lengths.npy',lengths)
    assert np.array_equal(np.load(folder/'id.npy'),ids)
    assert np.array_equal(np.load(folder/'text_sha256.npy'),hashes)
    fp,dp=folder/'features.npy',folder/'done.npy'
    if fp.exists():X=np.load(fp,mmap_mode='r+');done=np.load(dp)
    else:
        X=np.lib.format.open_memmap(fp,mode='w+',dtype='float16',shape=(len(r),384 if kind=='semantic' else 1024))
        X[:]=np.nan;X.flush();done=np.zeros(len(r),bool);npsave(dp,done)
    if done.all():print(kind,'already complete',flush=True);return
    model=AutoModel.from_pretrained(modeldir,local_files_only=True,trust_remote_code=False,
        dtype=torch.float16 if device=='mps' else torch.float32,attn_implementation='sdpa').to(device).eval()
    if kind=='dc16':
        gold=pd.read_csv(ROOT/'data/train.csv')
        gt=tok(gold.text.tolist(),add_special_tokens=False,truncation=True,max_length=512)['input_ids']
        ix=np.argsort([-len(a) for a in gt],kind='stable')[:8]
        batch=tok.pad({'input_ids':[gt[i] for i in ix]},return_tensors='pt').to(device)
        with torch.inference_mode():full_h=model(**batch,output_hidden_states=True,use_cache=False).hidden_states[16].clone()
        reference=dc_values(full_h,[len(gt[i]) for i in ix])
        cached=np.asarray(np.load(GOLD_READER/'features.npy',mmap_mode='r')[ix,LAYERS.index(16),0,:],dtype=np.float32)
        rel=float(np.linalg.norm(reference-cached)/max(np.linalg.norm(cached),1e-12))
        assert rel<=plan['cache_relative_l2_tolerance'],f'Gold cache DC mismatch: {rel}'
        model.layers=torch.nn.ModuleList(list(model.layers[:16]));model.norm=torch.nn.Identity()
        model.config.num_hidden_layers=16;model.config.layer_types=model.config.layer_types[:16]
        with torch.inference_mode():prefix_h=model(**batch,use_cache=False).last_hidden_state
        delta=float((prefix_h-full_h).abs().max().item())
        assert delta<=plan['prefix_max_abs_tolerance'],f'Prefix/full hidden16 mismatch: {delta}'
        dump(OUT/'prefix_parity.json',dict(full_vs_prefix_max_abs=delta,gold_cache_relative_l2=rel,
            gold_cache_max_abs=float(np.max(np.abs(reference-cached))),gold_probe_indices=ix.tolist(),
            gold_reader_manifest_sha256=sha(GOLD_READER/'manifest.json'),signature=signature,
            scope='Eight longest gold passages, same-batch full/prefix hidden16; no source labels or classifier fitting'))
        del full_h,prefix_h,batch,reference,cached
        if device=='mps':torch.mps.empty_cache()
        print('Prefix/full hidden16 parity',delta,'gold cache relative L2',rel,flush=True)
    order=np.argsort(-np.minimum(lengths,plan['max_tokens']),kind='stable');order=order[~done[order]]
    start=time.perf_counter();initial=int(done.sum())
    for b,s in enumerate(range(0,len(order),plan['batch'])):
        if max_batches and b>=max_batches:break
        ix=order[s:s+plan['batch']]
        batch=tok.pad({k:[v[i] for i in ix] for k,v in token.items()},return_tensors='pt').to(device)
        with torch.inference_mode():
            h=model(**batch,**({'use_cache':False} if kind=='dc16' else {})).last_hidden_state
            if kind=='semantic':
                mask=batch['attention_mask'].unsqueeze(-1);z=(h.float()*mask).sum(1)/mask.sum(1)
                values=torch.nn.functional.normalize(z,p=2,dim=1).cpu().numpy()
            else:values=dc_values(h,[min(lengths[i],plan['max_tokens']) for i in ix])
        assert np.isfinite(values).all();X[ix]=values;X.flush();done[ix]=True;npsave(dp,done)
        del h,batch
        if device=='mps':torch.mps.empty_cache()
        elapsed=time.perf_counter()-start;rate=(int(done.sum())-initial)/max(elapsed,1e-6)
        if b<3 or (b+1)%25==0 or done.all():
            print(f'{kind} rows={done.sum()}/{len(r)} device={device} elapsed_s={time.perf_counter()-begin:.1f} ETA_s={(~done).sum()/rate:.1f}',flush=True)
    dump(OUT/f'{kind}_extraction_status.json',dict(signature=signature,complete=bool(done.all()),rows_done=int(done.sum()),
        elapsed_s=time.perf_counter()-begin,feature_sha256=sha(fp) if done.all() else None))
    del model
    if device=='mps':torch.mps.empty_cache()


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--kind',choices=MODELS,required=True);p.add_argument('--max-batches',type=int,default=0)
    a=p.parse_args();run(a.kind,a.max_batches)
