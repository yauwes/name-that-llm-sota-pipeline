"""E35: harder3530..4040row context, known different gold-training prompts.

E33 OOD context produced zero cross-origin merges. Replace part of its3500
context rows by ALL outer-training passages, never the unselected test responses.
This is a known-training-context stress, not an IID hidden-test simulation.
All Gaussian models/thresholds/alpha/eligibility remain frozen. Training labels
are not supplied to group inference or to context scoring.
"""
import os
os.environ.setdefault('OMP_NUM_THREADS','2')
os.environ.setdefault('OPENBLAS_NUM_THREADS','2')
import hashlib
import json
import time
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.metrics import recall_score
from threadpoolctl import threadpool_limits

import large_context_audit as previous
from spectral_reader import ROOT,sha,dump
import lib

OUT=ROOT/'research/experiments/e35_mixed_context'
PLAN=dict(cases=previous.CASES,context_rows=3500,
    context='ALL outer-training gold passages plus seeded unlabeled external rows to fill3500; no unselected outer-test responses',
    frozen='E29Gaussian, E30thresholds, E32eligibility2..18, alpha0.1',
    truth='Target-to-training prompt links are known wrong; target-to-external identity remains unknown',
    limitation='Training context was seen by the Gaussian classifier: serving-compatible reference stress, not unseen4000row hidden simulation or fresh gold',
    submission_eligible=False)


def diagnose(labels,ng,nt,gold_truth,train_truth,ext_truth):
    size=np.bincount(labels);a=np.bincount(labels[:ng],minlength=len(size));b=np.bincount(labels[ng:ng+nt],minlength=len(size));c=size-a-b
    return dict(gold_gold=previous.pair_metrics(labels[:ng],gold_truth),
        known_gold_gold_training=previous.pair_metrics(labels[:ng+nt],np.r_[gold_truth,train_truth]),
        external_external=previous.pair_metrics(labels[ng+nt:],ext_truth),
        target_training_known_wrong_edges=int((a*b).sum()),target_external_unknown_edges=int((a*c).sum()),
        target_rows_merged_with_wrong_training_prompt=int(a[b>0].sum()),
        target_rows_merged_with_external_prompt_unknown=int(a[c>0].sum()),
        eligible_gold_rows=int(((size[labels[:ng]]>=2)&(size[labels[:ng]]<=18)).sum()))


def run():
    begin=time.perf_counter();OUT.mkdir(exist_ok=True);t=lib.load_train(ROOT/'data/train.csv')
    y=t.y.to_numpy();groups=t.prompt_id.to_numpy()
    context=json.loads((previous.EXTERNAL/'context_index.json').read_text());ext_groups=np.array(context['prompt_hash'])
    C=np.asarray(np.load(previous.SEMANTIC/'features.npy'),dtype=np.float32)
    X=np.asarray(np.load(previous.READER/'features.npy')[:,previous.LAYERS.index(16),0,:],dtype=np.float32)
    Ce,Xe=[np.asarray(np.load(previous.EXTERNAL/k/'features.npy'),dtype=np.float32) for k in ['semantic','dc16']]
    for p in [previous.SEMANTIC,previous.READER]:assert np.array_equal(np.load(p/'id.npy'),t.id.astype(str))
    q,l=[np.load(ROOT/f'kernels/twostage/out_full/out_{n}/oof_plain.npy') for n in ['q8','ll8']];base=lib.N((lib.N(q)+lib.N(l))/2)
    prompts=pd.Series(t.prompt_id.unique()).sample(frac=1,random_state=42).tolist();fold=t.prompt_id.map({p:i%5 for i,p in enumerate(prompts)}).to_numpy()
    manifest=dict(plan=PLAN,code_sha256=sha(Path(__file__)),helper_sha256=sha(Path(previous.__file__)),
        e33_audit_manifest_sha256=sha(previous.OUT/'audit_manifest.json'),
        context_index_sha256=sha(previous.EXTERNAL/'context_index.json'))
    signature=hashlib.sha256(json.dumps(manifest,sort_keys=True).encode()).hexdigest();mf=OUT/'manifest.json'
    if mf.exists():assert json.loads(mf.read_text())['signature']==signature,'Stale E35 results'
    else:dump(mf,dict(manifest,signature=signature))
    pooled={}
    for f in range(5):
        fp=OUT/f'fold{f}.json'
        if fp.exists():r=json.loads(fp.read_text());assert r['signature']==signature
        else:
            start=time.perf_counter();tr=np.flatnonzero(fold!=f)
            ei=np.random.default_rng(20263500+f).choice(len(Ce),PLAN['context_rows']-len(tr),replace=False)
            assert len(tr)+len(ei)==3500
            old=json.loads((previous.E32/f'fold{f}.json').read_text());s=json.loads((previous.E30/f'fold{f}.json').read_text())
            prm=joblib.load(previous.E29/f'gaussian_fold{f}.joblib')['params']
            xx_context=np.concatenate([X[tr],Xe[ei]]);uu_context=previous.audit.gauss.transform(xx_context,prm)
            cc_context=np.concatenate([C[tr],Ce[ei]])
            records=[];prediction={};indices={}
            for key in PLAN['cases']:
                ix=np.array(old['test_indices'][key]);ng=len(ix)
                assert not set(groups[ix])&set(groups[tr])
                labels=previous.audit.clusters(np.concatenate([C[ix],cc_context]),s['threshold']['threshold'])
                xx=np.concatenate([X[ix],xx_context]);uu=np.concatenate([previous.audit.gauss.transform(X[ix],prm),uu_context])
                pred=dict(baseline=base[ix].argmax(1),gold_only=np.array(old['prediction'][key]['semantic_grouped_only']),
                    mixed_context=previous.fusion(xx,uu,labels,prm,base[ix],ng),
                    mixed_no_injection=previous.fusion(xx,uu,labels,prm,base[ix],ng,cfg=dict(inj=False,repel=False)))
                diag=diagnose(labels,ng,len(tr),groups[ix],groups[tr],ext_groups[ei]);present=np.unique(y[ix])
                records.append(dict(case=key,rows=ng,total_context_rows=ng+3500,diagnostics=diag,
                    present_classes=len(present),present_class_macro_recall={k:float(recall_score(y[ix],p,labels=present,average='macro',zero_division=0)) for k,p in pred.items()}))
                indices[key]=ix.tolist();prediction[key]={k:p.tolist() for k,p in pred.items()}
            r=dict(signature=signature,fold=f,cases=records,prediction=prediction,test_indices=indices,
                training_context_rows=len(tr),external_context_rows=len(ei),context_external_indices=ei.tolist(),elapsed_s=time.perf_counter()-start)
            dump(fp,r)
        for c in r['cases']:
            key=c['case'];pooled.setdefault(key,dict(indices=[],prediction={k:[] for k in r['prediction'][key]},diagnostics=[]))
            b=pooled[key];b['indices'].extend(r['test_indices'][key]);b['diagnostics'].append(c['diagnostics'])
            for k in b['prediction']:b['prediction'][k].extend(r['prediction'][key][k])
        elapsed=time.perf_counter()-begin;print(f'fold={f} seconds={r["elapsed_s"]:.2f} elapsed_s={elapsed:.1f} ETA_s={elapsed/(f+1)*(4-f):.1f}',flush=True)
    summary={}
    for key,b in pooled.items():
        ix=np.array(b['indices']);pred={k:np.array(p) for k,p in b['prediction'].items()};di=b['diagnostics']
        pairs={}
        for name in ['gold_gold','known_gold_gold_training','external_external']:
            tp,fp,fn=[sum(d[name][k] for d in di) for k in ['tp','fp','fn']]
            pairs[name]=dict(tp=tp,fp=fp,fn=fn,pair_precision=tp/(tp+fp) if tp+fp else None,pair_recall=tp/(tp+fn) if tp+fn else None)
        summary[key]=dict(rows=len(ix),balanced_accuracy18={k:float(recall_score(y[ix],p,labels=np.arange(18),average='macro',zero_division=0)) for k,p in pred.items()},
            intervals={b+' minus '+a:previous.audit.paired_interval(y[ix],pred[a],pred[b],groups[ix]) for a,b in [('gold_only','mixed_context'),('baseline','mixed_context'),('mixed_context','mixed_no_injection')]},
            pair_diagnostics=pairs,diagnostics_totals={k:sum(d[k] for d in di) for k in ['target_training_known_wrong_edges','target_external_unknown_edges','target_rows_merged_with_wrong_training_prompt','target_rows_merged_with_external_prompt_unknown','eligible_gold_rows']})
    result=dict(signature=signature,plan=PLAN,cases=summary,elapsed_s=time.perf_counter()-begin,submission_eligible=False,
        conclusion='Known-training-context scale stress only. No weight/threshold chosen from test; not a hidden-score prediction.')
    dump(OUT/'results.json',result);print(json.dumps(result,indent=2),flush=True)


if __name__=='__main__':
    with threadpool_limits(limits=2):run()
