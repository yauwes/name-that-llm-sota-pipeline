"""Frozen MiniLM semantic features for prompt grouping, not source classification."""
import os
os.environ.setdefault('TOKENIZERS_PARALLELISM','false')
import hashlib
import json
import time
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from transformers import AutoModel,AutoTokenizer

from spectral_reader import ROOT,sha,dump
from lib import npsave

OUT=ROOT/'research/experiments/e30_semantic_groups'
FEATURE=ROOT/'data/features/e30_semantic_groups'
MODEL=ROOT/'data/models/MiniLM-L6-v2'
PLAN=dict(max_tokens=256,batch=32,pooling='official masked mean plus L2 normalization',
    use='cosine prompt matching only; no source-label training',trust_remote_code=False)


def extract():
    begin=time.perf_counter();FEATURE.mkdir(parents=True,exist_ok=True);torch.set_num_threads(2)
    t=pd.read_csv(ROOT/'data/train.csv');device='mps' if torch.backends.mps.is_available() else 'cpu'
    if device=='mps':torch.mps.set_per_process_memory_fraction(.35)
    up=json.loads((OUT/'download.json').read_text())
    tok=AutoTokenizer.from_pretrained(MODEL,local_files_only=True,trust_remote_code=False)
    full=tok(t.text.tolist(),truncation=False)['input_ids'];lengths=np.array([len(x) for x in full])
    token=tok(t.text.tolist(),truncation=True,max_length=PLAN['max_tokens'])
    manifest=dict(plan=PLAN,model=up['repo'],revision=up['revision'],device=device,dtype='float16' if device=='mps' else 'float32',
        train_sha256=sha(ROOT/'data/train.csv'),code_sha256=sha(Path(__file__)),truncated_rows=int((lengths>PLAN['max_tokens']).sum()),
        artifacts={str(p.relative_to(MODEL)):sha(p) for p in [MODEL/'model.safetensors',MODEL/'config.json',MODEL/'tokenizer.json',MODEL/'1_Pooling/config.json']})
    signature=hashlib.sha256(json.dumps(manifest,sort_keys=True).encode()).hexdigest();mf=FEATURE/'manifest.json'
    if mf.exists():assert json.loads(mf.read_text())['signature']==signature,'Stale semantic features'
    else:
        dump(mf,dict(manifest,signature=signature));np.save(FEATURE/'id.npy',t.id.astype(str).to_numpy(dtype=str))
        np.save(FEATURE/'text_sha256.npy',np.array([hashlib.sha256(s.encode()).hexdigest() for s in t.text]));np.save(FEATURE/'token_lengths.npy',lengths)
    assert np.array_equal(np.load(FEATURE/'id.npy'),t.id.astype(str))
    fp,dp=FEATURE/'features.npy',FEATURE/'done.npy'
    if fp.exists():X=np.load(fp,mmap_mode='r+');done=np.load(dp)
    else:
        X=np.lib.format.open_memmap(fp,mode='w+',dtype='float16',shape=(len(t),384));X[:]=np.nan;X.flush()
        done=np.zeros(len(t),bool);np.save(dp,done)
    if done.all():print('Semantic features already complete.',flush=True);return
    model=AutoModel.from_pretrained(MODEL,local_files_only=True,trust_remote_code=False,
        dtype=torch.float16 if device=='mps' else torch.float32,attn_implementation='sdpa').to(device).eval()
    order=np.argsort(-np.minimum(lengths,PLAN['max_tokens']),kind='stable');order=order[~done[order]]
    start=time.perf_counter();initial=int(done.sum())
    for b,s in enumerate(range(0,len(order),PLAN['batch'])):
        ix=order[s:s+PLAN['batch']]
        batch=tok.pad({k:[v[i] for i in ix] for k,v in token.items()},return_tensors='pt').to(device)
        with torch.inference_mode():
            h=model(**batch).last_hidden_state.float();mask=batch['attention_mask'].unsqueeze(-1)
            z=(h*mask).sum(1)/mask.sum(1);z=torch.nn.functional.normalize(z,p=2,dim=1)
        values=z.cpu().numpy();assert np.isfinite(values).all()
        X[ix]=values;X.flush();done[ix]=True
        npsave(dp,done)
        del h,z,batch,mask
        elapsed=time.perf_counter()-start;rate=(int(done.sum())-initial)/max(elapsed,1e-6)
        if b<3 or (b+1)%20==0 or done.all():
            print(f'rows={done.sum()}/{len(t)} device={device} elapsed_s={time.perf_counter()-begin:.1f} ETA_s={(~done).sum()/rate:.1f}',flush=True)
    dump(OUT/'feature_manifest.json',dict(manifest,signature=signature))
    dump(OUT/'extraction_status.json',dict(complete=bool(done.all()),rows_done=int(done.sum()),elapsed_s=time.perf_counter()-begin,feature_sha256=sha(fp)))
    del model
    if device=='mps':torch.mps.empty_cache()


if __name__=='__main__':extract()
