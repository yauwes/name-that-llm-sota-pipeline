"""E19: CPU adaptation of external-only stage1 logits + frozen reader.

Keep the 70/15/15 prompt contract. Do not tile host-finetuned LoRA OOF into
rotations: only external-pool stage1 scores are used here. Cache provenance is
historical, not independently reproduced. No automatic competition submission.
"""
import os
os.environ.setdefault('OMP_NUM_THREADS', '2')
os.environ.setdefault('OPENBLAS_NUM_THREADS', '2')
import hashlib
import json
import sys
import time
from pathlib import Path

import joblib
import numpy as np
from sklearn.decomposition import PCA
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import balanced_accuracy_score as ba, log_loss
from sklearn.preprocessing import StandardScaler
from threadpoolctl import threadpool_limits

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'notebook'))
import lib
from closing_audit import paired_ci

OUT = ROOT / 'research/experiments/e19_reader_strong_fusion'
PLAN = dict(reader='q27_l16', transforms='train-only scaler; optional PCA128',
    max_iter=2000,
    reader_C=[0.0003, 0.003, 0.03], hybrid_C=[0.003, 0.03], logit_multiplier=[1., 3.],
    alpha=[0., 0.05, 0.1, 0.2, 0.35], val_gain_required=0.005,
    baseline='val-fit nonnegative weights: external-stage1 q8,ll8 + strict-rotation SVC4',
    choice='reader configuration by val logloss; alpha by val BA with conservative gate',
    limitations='historical prompts/cache; no independently reproduced stage1 provenance or new gold')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def dump(path, value):
    lib.atomic(path, lambda f: f.write(json.dumps(value, indent=2).encode()))


def run():
    begin = time.perf_counter()
    OUT.mkdir(parents=True, exist_ok=True)
    t = lib.load_train(ROOT / 'data/train.csv')
    y = t.y.to_numpy()
    S = lib.make_splits(t)
    reader_path = ROOT / 'kernels/reader/out/q27_l16.npy'
    qpath = ROOT / 'kernels/twostage/out_full/out_q8/s1_plain.npy'
    lpath = ROOT / 'kernels/twostage/out_full/out_ll8/s1_plain.npy'
    spath = ROOT / 'kernels/svc4/out/members/svc4_p190k/oof.npy'
    assert np.array_equal(np.load(reader_path.parent / 'train_id.npy'), t.id.astype(str))
    X = np.array(np.load(reader_path, mmap_mode='r')[:len(t)], dtype=np.float32)
    q, l, svc = [np.load(p) for p in [qpath, lpath, spath]]
    assert q.shape == l.shape == (len(t), 18) and svc.shape == (5, len(t), 18)
    assert np.isfinite(q).all() and np.isfinite(l).all()
    for f in range(5):
        assert np.isnan(svc[f, S[f] == 0]).all()
        assert np.isfinite(svc[f, S[f] != 0]).all()
    external_logits = np.concatenate([lib.N(q), lib.N(l)], axis=1)
    manifest = dict(plan=PLAN, labels=lib.LABELS, split_md5=hashlib.md5(S.tobytes()).hexdigest(),
        inputs={str(p.relative_to(ROOT)): sha(p) for p in
                [reader_path, qpath, lpath, spath, ROOT/'data/train.csv',
                 ROOT/'kernels/twostage/out_full/worker.py']},
        code_sha256=sha(Path(__file__)),
        scope='Stage1 worker source trains on external pool before evaluating host. '
              'Unlike stage2 OOF, stage1 scores do not use host gold labels. Historical row order '
              'and exact external pool/model revisions lack a complete original manifest.')
    signature = hashlib.sha256(json.dumps(manifest, sort_keys=True).encode()).hexdigest()
    dump(OUT/'manifest.json', dict(manifest, signature=signature))
    all_pred = {key: np.full(len(t), -1) for key in ['baseline', 'selected', 'candidate']}
    results = []
    for f in range(5):
        path = OUT/f'fold{f}.json'
        if path.exists():
            result = json.loads(path.read_text())
            assert result['signature'] == signature, 'stale cached fold'
        else:
            started = time.perf_counter()
            tr, va, te = [S[f] == i for i in (0, 1, 2)]
            weights = lib.fit_weights([q[va], l[va], svc[f, va]], y[va])
            base_v = lib.blend([q[va], l[va], svc[f, va]], weights)
            base_t = lib.blend([q[te], l[te], svc[f, te]], weights)
            base_v, base_t = lib.N(base_v), lib.N(base_t)
            scaler = StandardScaler().fit(X[tr])
            A, V, E = [scaler.transform(X[z]) for z in [tr, va, te]]
            trials, best, best_key, best_model = [], None, None, None
            best_v = best_t = None
            pca = PCA(128, svd_solver='randomized', iterated_power=3, random_state=42)
            Ap = pca.fit_transform(A)
            Vp, Ep = pca.transform(V), pca.transform(E)
            features = [('reader_full', A, V, E, PLAN['reader_C'])]
            for mult in PLAN['logit_multiplier']:
                features.append((f'hybrid_PCA128_logitx{mult}',
                    np.c_[Ap, external_logits[tr]*mult],
                    np.c_[Vp, external_logits[va]*mult],
                    np.c_[Ep, external_logits[te]*mult], PLAN['hybrid_C']))
            # Held-out scores do not enter configuration or alpha selection.
            for key, a, v, e, Cs in features:
                for C in Cs:
                    model = LogisticRegression(C=C, max_iter=PLAN['max_iter'], random_state=42).fit(a, y[tr])
                    assert model.n_iter_.max() < PLAN['max_iter'], 'unconverged candidate: do not promote'
                    rv = model.decision_function(v)
                    trial = dict(name=key, C=C, iterations=int(model.n_iter_.max()),
                        train_ba=float(ba(y[tr], model.predict(a))),
                        val_ba=float(ba(y[va], rv.argmax(1))),
                        val_logloss=float(log_loss(y[va], model.predict_proba(v), labels=np.arange(18))))
                    trials.append(trial)
                    if best is None or trial['val_logloss'] < best['val_logloss']:
                        best, best_key, best_model = trial, key, model
                        best_v, best_t = lib.N(rv), lib.N(model.decision_function(e))
            anchor_ba = float(ba(y[va], base_v.argmax(1)))
            alpha_trials = [dict(alpha=a, val_ba=float(ba(y[va], (base_v+a*best_v).argmax(1))))
                            for a in PLAN['alpha']]
            choice = max(alpha_trials, key=lambda z: z['val_ba'])
            alpha = choice['alpha'] if choice['val_ba'] >= anchor_ba+PLAN['val_gain_required'] else 0.
            selected = (base_t+alpha*best_t).argmax(1)
            result = dict(signature=signature, fold=f, weights=weights.tolist(), candidates=trials,
                chosen=best, alpha_trials=alpha_trials, alpha=alpha,
                baseline_val_ba=anchor_ba, selected_val_ba=float(ba(y[va],(base_v+alpha*best_v).argmax(1))),
                baseline_test_ba=float(ba(y[te],base_t.argmax(1))),
                selected_test_ba=float(ba(y[te],selected)),
                candidate_test_ba=float(ba(y[te],best_t.argmax(1))),
                test_indices=np.flatnonzero(te).tolist(), baseline=base_t.argmax(1).tolist(),
                selected=selected.tolist(), candidate=best_t.argmax(1).tolist(),
                elapsed_s=time.perf_counter()-started)
            lib.atomic(OUT/f'head_fold{f}.joblib', lambda h: joblib.dump(dict(
                signature=signature, scaler=scaler, pca=pca, model=best_model,
                name=best_key, alpha=alpha, baseline_weights=weights, labels=lib.LABELS), h))
            dump(path, result)
        for key in all_pred:
            all_pred[key][result['test_indices']] = result[key]
        results.append(result)
        elapsed = time.perf_counter()-begin
        print(f'fold={f} base_val={result["baseline_val_ba"]:.4f} val={result["selected_val_ba"]:.4f} '
              f'base_test={result["baseline_test_ba"]:.4f} test={result["selected_test_ba"]:.4f} '
              f'alpha={result["alpha"]} model={result["chosen"]["name"]} '
              f'elapsed_s={elapsed:.1f} ETA_s={elapsed/(f+1)*(4-f):.1f}', flush=True)
    mask = all_pred['selected'] >= 0
    result = dict(plan=PLAN, signature=signature, mean_test={key:float(np.mean(
        [r[f'{key}_test_ba'] for r in results])) for key in all_pred},
        pooled_test={key:float(ba(y[mask],p[mask])) for key,p in all_pred.items()},
        paired_prompt_ci95=paired_ci(y[mask],all_pred['baseline'][mask],all_pred['selected'][mask],
                                     t.prompt_id.to_numpy()[mask]),
        positive_folds=sum(r['selected_test_ba'] > r['baseline_test_ba'] for r in results),
        elapsed_s=time.perf_counter()-begin, test_rows=int(mask.sum()),
        submission_eligible=False,
        note='Stricter adaptation scope than tiled stage2 OOF, but all historical data and '
             'incomplete upstream cache provenance. This is not CV of the public LB champion.')
    dump(OUT/'results.json',result)
    print(json.dumps(result,indent=2),flush=True)


if __name__ == '__main__':
    with threadpool_limits(limits=2):
        run()
