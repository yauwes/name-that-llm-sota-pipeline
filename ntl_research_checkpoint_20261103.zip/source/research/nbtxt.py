import json,sys,glob
for p in glob.glob(sys.argv[1]+'/*.ipynb'):
    n=json.load(open(p))
    for c in n['cells']:
        s=''.join(c['source'])
        if c['cell_type']=='markdown': print('[MD]',s)
        elif len(sys.argv)>2: print('[CODE]',s[:int(sys.argv[2])])
