# Name That LLM: laporan teknis

Status 2026-11-02. Skor asli terbaik 0.664 (peringkat 157 dari 4.224). Target 0.99 tidak tercapai dan menurut bukti di bawah tidak realistis. Autosubmit 0.99+ tidak pernah terpicu, jadi antrean submit dihentikan dan kandidat disimpan.

## Kesimpulan
- Puncak leaderboard 0.737. Hanya dua tim di atas 0.72. Tidak ada bukti siapa pun mendekati 0.99.
- Pemeriksaan kebocoran pada `id`, `prompt_id`, urutan baris, panjang teks, dan duplikat dengan train atau pool tidak menemukan apa pun, jadi tidak ada jalan pintas yang sah.
- Skor train 1.0 pada SVC adalah hafalan. Gate 0.99 yang menuntut train, val, dan test sekaligus tidak terpenuhi: test lokal terbaik 0.615.
- Gap 0.72431 lawan 0.659: ini bukan satu pipeline yang sama. Notebook `name-that-llm-sota-apex-ensemble-0-72431` (SVC, stilometri, LightGBM, Sinkhorn, Hungarian per kluster, dengan 0.72431 tertulis di judulnya) mendapat 0.330 di Kaggle. Skor 0.659 berasal dari `ntl-sota-apex-0-72-without-llama`, fork notebook publik 0.660 tanpa Llama yang penulis aslinya catat 0.659. Asal angka 0.72431 tidak ada di notebook, jadi penyebab pastinya belum terverifikasi. Hungarian adalah kandidat kuat karena menurunkan skor di percobaan publik, dan bobot validasinya tidak bisa diaudit.

## Submission di akun `ajikajadeh`
| ID | Isi | Asal | Public LB |
|---|---|---|---:|
| 57889656 | SOTA Apex Grandmaster 0.75+ (Hungarian DP dan lain-lain) | bukan sesi ini | masih diproses 2026-11-02 12:08 WIB |
| 57876141 | fork One Swap, `ntl-sub-oneswap` v1 | sesi ini | **0.664** |
| 57874130 | SOTA Apex tanpa Llama | bukan sesi ini | 0.659 |
| 57873164 | S12 SOTA Apex 0.72431 v2 | bukan sesi ini | 0.330 |
| 57872845 | S12 SOTA Apex 0.72431 | bukan sesi ini | tidak ada skor |
| 57871600 | S12 FullGroup k18 0.72431 | bukan sesi ini | tidak ada skor |

Kandidat tersimpan, belum disubmit: `ntl-sub-apex` (kernel sudah dipush), Apex-H, dan One Swap + adapter sendiri (`kernels/own/build_own.py`, dataset private `ajikajadeh/ntl-own-adapters`, lolos smoke T4x2 dengan akurasi in-sample q8 0.78 dan ll8 0.82 pada 40 baris train). Karena ini code competition, `submission.parquet` hidden test tidak bisa diunduh. Yang tersimpan adalah kernel, versi, dan resepnya.

## Skenario dan perkiraan
Rentang memakai derau identik-kode 0.009. Baris pertama terukur, baris lain perkiraan. Peringkat dari snapshot LB 2026-11-01 dan bergeser seiring waktu.

| Skenario | Test lokal 70/15/15 | Perkiraan public LB | Perkiraan peringkat | Waktu |
|---|---:|---:|---:|---|
| One Swap (fork publik) | tidak ada OOF | 0.664 terukur | 157 terukur | commit 10 menit, rerun 8 jam |
| One Swap + q8 ll8 sendiri | tidak ada OOF | 0.655-0.673 | 35-700 | rerun 8,2 jam |
| q8 + ll8 + SVC4 kita saja | 0.615 (CI 0.595-0.634) | 0.60-0.65 | 900-1.650 | training q8 dan ll8 berjalan paralel di T4x2, SVC 98 menit CPU, rerun diperkirakan di bawah 1 jam, belum disubmit |
| Data generasi sendiri per model | belum ada | tidak diketahui | tidak diketahui | butuh akses API 18 model |

## Masalah
Klasifikasi 18 LLM, metrik balanced accuracy, prompt uji tidak pernah terlihat, komposisi kelas public dan private berbeda. Train 2.699 passage dari 150 prompt, seimbang. LB teratas 0.737, sekitar 10 tim di atas 0.70 dari 4.128, notebook publik terbaik 0.664.

## Validasi
Prompt-grouped 5-fold, tetap di `src/common.py` (md5 fold `ac4e35f8d690ca131c38dd76de0a67fe`). Trik kelompok hanya dinilai pada 2-3 passage per prompt.

Alasannya bukti publik: CV 0.593 berpasangan dengan LB 0.592 untuk blend LoRA dua tahap, sementara nested CV 0.6865 pada grup 18 penuh jatuh ke LB 0.56. Satu kode yang sama bisa bergeser 0.009 di LB, jadi kenaikan yang lebih kecil bukan bukti.

## Hasil lokal (OOF)
| Model | Balanced acc | fold SD | Akurasi family |
|---|---:|---:|---:|
| char+style+shape SVC, pool 190k | 0.4704 | 0.018 | 0.738 |
| sama, pool 100k | 0.4616 | 0.028 | 0.734 |
| sama, pool 100k, bobot pool 1.0 | 0.4567 | 0.028 | 0.729 |
| char+style SVC, pool 40k | 0.4334 | 0.013 | 0.729 |
| word+char+style SVC, pool 20k | 0.4178 | 0.011 | 0.720 |
| word+char+style SVC, host saja | 0.3326 | 0.019 | 0.678 |
| LightGBM stilometri, host saja | 0.2982 | 0.016 | 0.645 |
| blend p190k + p20k | 0.4745 | | |

Blend ini memakai bobot tetap yang dipilih pada OOF yang sama, jadi sedikit optimistis. Pembanding publik: SVC 4-view 198k sekitar 0.50, LoRA dua tahap sekitar 0.57-0.60.

Yang terbukti: skala data mengalahkan pilihan fitur (0.333 ke 0.470 hanya dengan menambah pool), sejalan dengan `kaggle-writeups/llm-detect-ai-generated-text/writeups/r001-comprehensive-1st-place-write-up.md` dan `r005-5th-place-solution-1-7-million-training-examples.md`.

## Hasil 70/15/15 pada data penuh
Pembagian per prompt, 5 rotasi, MD5 `e52bf922570b1d00a0e51c510ac4f16d`. Bobot dipilih dari baris val, skor dari baris test.

| Anggota | Val | Test | SD | CI 95% per prompt |
|---|---:|---:|---:|---|
| SVC tunggal p190k | 0.4835 | 0.4759 | 0.026 | 0.459-0.492 |
| SVC 4-view p190k | 0.5062 | 0.5006 | 0.031 | 0.479-0.520 |
| q8 | 0.5814 | 0.5755 | 0.013 | 0.557-0.592 |
| ll8 | 0.5748 | 0.5784 | 0.024 | 0.562-0.595 |
| q8 + ll8 | 0.5986 | 0.5963 | 0.018 | 0.578-0.614 |
| q8 + ll8 + SVC4 | 0.6184 | **0.6147** | 0.025 | 0.595-0.634 |
| sama + typography + Sinkhorn | 0.6204 | 0.6123 | 0.024 | 0.592-0.631 |

q8 dan ll8 dilatih dengan 5-fold lama, bukan 70/15/15, sehingga OOF-nya tetap bebas prompt tetapi modelnya tidak persis per rotasi. Twin rule belum dinilai pada anggota ini karena head per fold tidak disimpan.

## Ronde 2: mekanisme setelah blend
Pembanding q8+ll8+SVC4 test 0.6166, delta dengan CI bootstrap per prompt (`research/experiments/round2.py`).

| Mekanisme | Test | Delta | CI 95% | Status |
|---|---:|---:|---|---|
| Bias logit per kelas | 0.5987 | -0.0179 | -0.028 sampai -0.008 | ditolak |
| Ahli dalam keluarga model | 0.6171 | +0.0005 | -0.005 sampai +0.007 | inkonklusif |
| Twin k=2, head baru pada fitur PCA | 0.6084 | -0.0082 | -0.018 sampai 0.000 | ditolak untuk varian ini |
| Stack dilatih pada baris val | 0.5522 | -0.0644 | -0.081 sampai -0.046 | ditolak |
| Head fitur biasa + blend | 0.6185 | +0.0019 | -0.009 sampai +0.012 | inkonklusif |
| Head KD + blend | 0.6209 | +0.0043 | -0.008 sampai +0.017 | inkonklusif |

Kontrol negatif (label diacak di dalam prompt) 0.0465, chance 0.0556. Head KD sendirian 0.571 lawan head biasa 0.521, tetapi gurunya memakai OOF 5-fold yang pernah melihat prompt rotasi lain, jadi angka ini eksploratif. Twin di sini memakai head PCA baru, bukan head terpusat per fold seperti resep publik, jadi hasilnya tidak membantah +0.028 di leaderboard publik.

## Data eksternal
Pencarian Kaggle mendaftar 177 dataset terkait. 23 dataset yang belum tercakup pool diperiksa dan 22 berhasil diunduh, hanya file parquet, csv, dan md (`research/experiments/ext_scan.py`). Setelah dedup terhadap Open Pool dan train ada 100.220 baris baru. Setelah saringan kemiripan prompt (cos < 0,255, persentil 99 milik Open Pool) dan gaya tersisa 64.618 baris (`ext_filter.py`). Sebagian besar kemungkinan baris yang sengaja dibuang kurator Open Pool, jadi nilainya harus diukur.

Petunjuk tim atas, belum terbukti: pemilik akun `lianmatsuo`, bernama sama dengan tim peringkat 1, memublikasikan potongan GGUF Kimi-K3 per rentang layer (UD-IQ2_XXS, 93 layer) dan merujuk `experiments/teacher_runner` di repo yang tidak bisa diakses dari sini. READER (https://arxiv.org/abs/2606.10794) melaporkan model pembaca yang lebih kuat membuat jejak penulis lebih mudah dipisahkan secara linear. GLM-5.3, GLM-5.3-Flash, dan Kimi-K3 berbobot terbuka di Hugging Face. Hipotesisnya: fitur atau likelihood dari model besar, lalu distilasi. Belum diuji karena loader dan kuantisasi kustomnya mahal.

Hasil terukurnya ada di E8 di bawah: menambah 64.618 baris tidak menaikkan SVC.

## Eksperimen yang gagal
- Pseudo-label satu putaran, baris test ikut dilabeli: gabungan 0.6176 lawan guru 0.6171. Student hanya menghafal label guru pada baris yang sama.
- Self-training ketat 3 putaran, baris test tidak pernah dilabeli: student 0.5247 ke 0.5257, gabungan 0.5967, di bawah guru 0.6171. Tidak dipakai. Skrip di `research/experiments/`.
- E7, baris pool dibobot ulang dengan classifier domain host (`kernels/svc4da/svc4da.py`): SVC 0.5001 lawan 0.5006, q8+ll8+SVC 0.6069 lawan 0.6147. Ditolak. AUC 0.9996 di log kernel adalah in-sample dan tidak bermakna. Diukur held-out per prompt (3 fold, 20.000 baris pool), AUC domain 0.807: teks pool dan teks kompetisi berbeda secara nyata, tetapi tumpang tindih. Bobot ulang tidak memperbaiki skor.
- E8, Open Pool ditambah 64.618 baris eksternal baru (cap 30.000 per kelas, `kernels/svc4ext/svc4ext.py`): SVC 0.4991 lawan 0.5006, q8+ll8+SVC 0.6175 lawan 0.6147 (CI 0.600 sampai 0.635), val turun 0.6184 ke 0.6133. Tidak ada kenaikan yang bisa dibedakan dari noise. Menambah data eksternal bukan tuas utama.
- E9, pembaca beku Qwen3.8-27B lawan 8B pada 28 layer pertama, 2.699 baris train + 3.600 baris pool (`kernels/reader/reader.py`, `research/experiments/ev_reader.py`). Aturan ditetapkan sebelum hasil keluar: selisih test minimal 0.03 dengan CI di atas 0. Layer dipilih di val: 27B layer 16 test 0.4146, 8B layer 24 test 0.3871, selisih 0.0275 (CI 0.0075 sampai 0.049). Tidak lulus ambang, walau CI di atas 0. Layer 24 dan 27 milik 27B lebih lemah (0.357 dan 0.356). Dalam blend, 27B mendapat bobot nol: 0.6146 lawan 0.6147. 8B beku 0.6176. Finetune 27B dan layer di atas 28 tidak diuji.
- Kebocoran: `id` 0.054, `prompt_id` 0.055, urutan baris 0.049, panjang dan tepi teks 0.096, chance 0.056. Duplikat exact dengan train: 0.

## Pelajaran dari notebook publik
- Judul "0.670+" tidak terbukti. Akun yang mem-fork resep itu mentok 0.664, dan fork kita mendapat 0.664.
- Twin rule adalah kenaikan terbesar yang tercatat (+0.028). Hungarian rugi 0.009-0.017. Menghapus Llama -0.005 sampai -0.008. ATLAS 20% lawan 10% +0.003.
- Menambah anggota kuat menurunkan skor pada beberapa percobaan publik (0.635-0.648).
- Celah terbesar yang tersisa kemungkinan data generasi sendiri berskala besar, sesuai `kaggle-writeups/llm-detect-ai-generated-text/writeups/r001-comprehensive-1st-place-write-up.md`. Ini dugaan, belum terbukti di kompetisi ini.

## Lubang yang dihindari
- Hungarian di dalam kluster uji: rugi 0.009-0.017 di LB. Hidden test tampaknya punya sedikit passage per prompt.
- Sinkhorn ke uniform: komposisi uji tidak uniform. Di sini soft, dan dipilih pada campuran Dirichlet simulasi.
- Menambah anggota LoRA ke blend kuat: paling banyak 0.004. Stack memakai forward selection dengan syarat +0.002 pada skor nested.
- Tahap 2 lebih banyak epoch atau mencampur pool: lebih buruk.
- Pool sumber: kecurigaan awal saya pada label GLM/Kimi/Qwen terlalu dibesar-besarkan. Classifier host saja juga lemah di kelas itu, jadi tidak ada sumber yang dibuang.

## Notebook A100
`notebook/ntl_a100.ipynb`, dibangun dari `lib.py` + `cells.py` oleh `build.py`.

| Kelompok | Anggota |
|---|---|
| Sparse dan stilometri | `svc_p190k`, `svc_p100k_w1`, `lgb_style` |
| LoRA dua tahap | `q8`, `q14`, `ll8`, `q25_7`, `deberta` |
| Skala data | `q8_big` |
| Student-teacher | `q8_kd`, `q14_kd`, `q8_kd2`: label lunak guru tahap 1 pada pool, tanpa kebocoran host |
| Likelihood per sumber | `atlas_q8`, setelah ATLAS https://arxiv.org/abs/2610.19583 |

Post-processing yang diukur: bukti tipografi, soft Sinkhorn, self-training transduktif, twin terpusat pada k=2,3 (hanya dilaporkan). Notebook ini tidak lagi menjadi jalur submit. Revisi terakhirnya (perbaikan deteksi Colab, SVC 4-view, twin, sibling) lolos `check_protocol.py` tetapi belum lolos smoke penuh.

### Yang sudah diverifikasi
- Smoke T4x2 versi 5 end to end: SVC, LightGBM, LoRA, ATLAS, stack, post-processing, prediksi. KD lolos di versi 4 dan kodenya tidak berubah sesudahnya.
- Sel ekspor asli dijalankan dari Mac dengan nama uji dan gate mati: dataset private terbuat, kernel offline jalan di cabang inferensi sungguhan, `submission.parquet` keluar. Dataset dan kernel uji sudah dihapus.
- Bug yang ketemu: `peft` rekursi pada `find_spec`, T4 salah terdeteksi bf16, bentuk centring, kebocoran memori saat retry OOM, memori logit ATLAS, `userSecrets` (seharusnya `userdata`), `-r skip` yang membuang semua checkpoint di subfolder, `competitions download -c` yang sudah tidak ada.

### Yang belum diverifikasi
- Eksekusi di Colab: hanya sel setup yang dijalankan, memakai modul `google.colab` palsu. Unduhan model dan `drive.mount` sungguhan belum pernah jalan.
- Jalur bf16 hanya berjalan di A100.
- Durasi di A100 belum terukur.
- Aturan data eksternal: halaman rules tidak bisa diambil. Notebook publik memakai pool yang sama.

### Risiko runtime
ATLAS butuh 3,3 detik per passage di T4x2, sekitar 3,6 jam untuk 4.000 passage, di luar anggota lain. Fork One Swap selesai dinilai paling lama 9 jam pada T4x2.

## Referensi
- ATLAS https://arxiv.org/abs/2610.19583
- READER https://arxiv.org/abs/2606.10794
- TRACE https://arxiv.org/abs/2603.28054
