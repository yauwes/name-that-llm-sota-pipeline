# E15 on TPU v5e-8: the ntl-twostage-train recipe (Qwen3-8B cut to 24 layers, LoRA r16 on every projection, mean pool of 8 layers,
# plain + prompt-centred heads, same-prompt triplets) trained only on pool rows the public v5 members never saw.
# SPMD data parallel over 8 chips, bf16 base, fixed (rows, tokens) shapes so XLA compiles each shape once (GoPain, forum 754657).
# A tiny smoke pass runs first in the same session; it compiles the same shapes, so a bug costs minutes, not the whole run.
# Output keys match the GPU worker, so kernels/own/build_own.py converts final.pt for the public l24 inference path.
import glob, json, math, os, subprocess, sys, time
T00 = time.time()
def log(*a): print(f'[{time.time() - T00:7.0f}s]', *a, flush=True)
subprocess.run([sys.executable, '-m', 'pip', 'install', '-q', 'peft==0.20.0'], check=False)
import numpy as np, pandas as pd, torch
from torch import nn
import torch_xla, torch_xla.core.xla_model as xm, torch_xla.runtime as xr, torch_xla.distributed.spmd as xs
from torch_xla.utils.checkpoint import checkpoint as xla_ckpt
import transformers, peft
from transformers import AutoConfig, AutoModel, AutoTokenizer
from peft import LoraConfig, get_peft_model
xr.use_spmd(); NDEV = xr.global_runtime_device_count(); MESH = xs.Mesh(np.arange(NDEV), (NDEV, 1), ('data', 'model')); dev = xm.xla_device()
log('versions torch', torch.__version__, 'torch_xla', torch_xla.__version__, 'transformers', transformers.__version__, 'peft', peft.__version__, '| devices', NDEV)

C = dict(tag='q8u', seed=31, keep=24, hs=4096, layers=[2, 4, 6, 8, 12, 16, 20, 24], cap=8000, s1_budget=4.0 * 3600, buckets=(128, 256, 448), b1=21, b2=8, be=64)
OUT = f"/kaggle/working/out_{C['tag']}"; os.makedirs(OUT, exist_ok=True); L = C['layers']
data = next(p for p in ['/kaggle/input/competitions/name-that-llm', '/kaggle/input/name-that-llm'] if os.path.exists(p + '/train.csv'))
def base_dir():
    for f in sorted(glob.glob('/kaggle/input/**/config.json', recursive=True)):
        j = json.load(open(f))
        if j.get('model_type') == 'qwen3' and j.get('hidden_size') == 4096 and j.get('num_hidden_layers') == 36: return os.path.dirname(f)
    raise FileNotFoundError('Qwen3-8B base')
MD = base_dir(); log('model', MD)
t = pd.read_csv(data + '/train.csv'); LABELS = sorted(t.model.unique()); L2I = {l: i for i, l in enumerate(LABELS)}; y = t.model.map(L2I).values
pr = pd.Series(t.prompt_id.unique()).sample(frac=1, random_state=42).tolist(); fold = t.prompt_id.map({p: i % 5 for i, p in enumerate(pr)}).values
p = pd.read_parquet(glob.glob('/kaggle/input/**/ntl_open_pool.parquet', recursive=True)[0], columns=['text', 'model', 'prompt_group'])
p = p.sample(frac=1, random_state=C['seed']).groupby('model').head(C['cap']).reset_index(drop=True); py = p.model.map(L2I).values
log('pool', len(p), np.bincount(py, minlength=18).tolist())
tok = AutoTokenizer.from_pretrained(MD); tok.padding_side = 'right'; tok.pad_token = tok.pad_token or tok.eos_token
def enc(tx): return [i + [tok.eos_token_id] for i in tok(list(tx), add_special_tokens=False, truncation=True, max_length=447)['input_ids']]
T, PT = enc(t.text), enc(p.text); log('tokenised')

def build():
    mc = AutoConfig.from_pretrained(MD); mc.num_hidden_layers, mc.use_cache = C['keep'], False
    if getattr(mc, 'layer_types', None) is not None: mc.layer_types = mc.layer_types[:C['keep']]
    b = AutoModel.from_pretrained(MD, config=mc, dtype=torch.bfloat16)
    b.gradient_checkpointing_enable(); b.enable_input_require_grads()
    for mod in b.modules():  # swap HF's torch checkpoint for the XLA one on every decoder layer
        if hasattr(mod, '_gradient_checkpointing_func'): mod._gradient_checkpointing_func = xla_ckpt
    m = get_peft_model(b, LoraConfig(r=16, lora_alpha=32, lora_dropout=.05, bias='none', target_modules=['q_proj', 'k_proj', 'v_proj', 'o_proj', 'gate_proj', 'up_proj', 'down_proj']))
    for q in m.parameters():
        if q.requires_grad: q.data = q.data.float()
    norms = nn.ModuleList([nn.LayerNorm(C['hs']) for _ in L]); plain = nn.Linear(C['hs'] * len(L), 18); cent = nn.Linear(C['hs'] * len(L), 18)
    return [x.to(dev) for x in (m, norms, plain, cent)]

def batch(rows, toks, n):
    """fixed shape (n, bucket): rows beyond the real ones are padding with weight 0."""
    Lb = next(b for b in C['buckets'] if b >= max(len(toks[i]) for i in rows)); ids = np.full((n, Lb), tok.pad_token_id, np.int64); am = np.zeros((n, Lb), np.int64)
    ids[:, 0] = tok.eos_token_id; am[:, 0] = 1  # padding rows keep one real token: a fully masked row turns attention into NaN
    for j, i in enumerate(rows): ids[j, :len(toks[i])] = toks[i]; am[j, :len(toks[i])] = 1
    ids, am = torch.from_numpy(ids).to(dev), torch.from_numpy(am).to(dev); xs.mark_sharding(ids, MESH, ('data', None)); xs.mark_sharding(am, MESH, ('data', None)); return ids, am

def rep(parts, ids, am):
    m, norms = parts[0], parts[1]; hs = m(input_ids=ids, attention_mask=am, output_hidden_states=True, use_cache=False).hidden_states
    a = am.unsqueeze(-1).float(); a[:, 0] = 0
    return torch.cat([n((hs[l].float() * a).sum(1) / a.sum(1).clamp(min=1)) for l, n in zip(L, norms)], -1)

def triplets(groups, rng):
    s = pd.Series(np.arange(len(groups))).groupby(groups).apply(list); out, rest = [], []
    for g in s:
        g = list(rng.permutation(g))
        while len(g) >= 3: out.append([g.pop() for _ in range(3)])
        rest += g
    rest = list(rng.permutation(rest)); out += [rest[i:i + 3] for i in range(0, len(rest) - 2, 3)]; return out

def plan(groups, toks, k, rng, epochs):
    """batches of k triplets, each batch inside one length bucket so padding stays small."""
    out = []
    for _ in range(epochs):
        tr = triplets(groups, rng); key = [next(b for b in C['buckets'] if b >= max(len(toks[i]) for i in x)) for x in tr]; ep = []
        for b in C['buckets']:
            sel = [x for x, kk in zip(tr, key) if kk == b]; sel = [sel[i] for i in rng.permutation(len(sel))]; ep += [sel[i:i + k] for i in range(0, len(sel), k)]
        out.append([ep[i] for i in rng.permutation(len(ep))])
    return out

def fit(parts, toks, ys, groups, epochs, lr_a, lr_h, cw, seed, name, k, budget=1e9):
    m, norms, plain, cent = parts; rng = np.random.RandomState(seed); torch.manual_seed(seed); n = 3 * k + (1 if k == 21 else 0); drop = nn.Dropout(.1)
    ad = [q for q in m.parameters() if q.requires_grad]; hd = list(norms.parameters()) + list(plain.parameters()) + list(cent.parameters())
    opt = torch.optim.AdamW([{'params': ad, 'lr': lr_a}, {'params': hd, 'lr': lr_h}], weight_decay=.01)
    B = plan(groups, toks, k, rng, epochs); total = sum(map(len, B)); warm = max(1, total // 10)
    sch = torch.optim.lr_scheduler.LambdaLR(opt, lambda s: (s + 1) / warm if s < warm else .5 * (1 + math.cos(math.pi * (s - warm) / max(1, total - warm))))
    cwt = torch.tensor(cw if cw is not None else np.ones(18), dtype=torch.float32, device=dev); m.train(); norms.train(); t0 = time.time(); step = 0; ls = []
    for ep in B:
        for b in ep:
            if time.time() - t0 > budget: log(name, 'budget stop at step', step, '/', total); return
            rows = [i for x in b for i in x]; ids, am = batch(rows, toks, n)
            yy = np.zeros(n, np.int64); yy[:len(rows)] = ys[rows]; w = np.zeros(n, np.float32); w[:len(rows)] = 1
            yy, w = torch.from_numpy(yy).to(dev), torch.from_numpy(w).to(dev); w = w * cwt[yy]
            z = rep(parts, ids, am); zc = z[:3 * k].reshape(k, 3, -1); zc = (zc - zc.mean(1, keepdim=True)).reshape(3 * k, -1)
            ce = lambda lg, yv, wv: (nn.functional.cross_entropy(lg, yv, reduction='none') * wv).sum() / wv.sum().clamp(min=1e-6)
            loss = ce(plain(drop(z)), yy, w) + ce(cent(drop(zc)), yy[:3 * k], w[:3 * k])
            loss.backward(); torch.nn.utils.clip_grad_norm_(ad + hd, 1.); opt.step(); opt.zero_grad(set_to_none=True); sch.step(); xm.mark_step(); step += 1
            if step % 50 == 0 or step in (1, 3): ls.append(float(loss.detach().cpu())); log(name, 'step', step, '/', total, 'loss %.3f' % ls[-1], '%.2fs/step' % ((time.time() - t0) / step))
    log(name, 'fit done', step, 'steps', '%ds' % (time.time() - t0))

@torch.no_grad()
def feats(parts, toks, idx):
    parts[0].eval(); parts[1].eval(); o = sorted(idx, key=lambda i: len(toks[i])); Z = np.zeros((len(toks), C['hs'] * len(L)), np.float32)
    for s in range(0, len(o), C['be']):
        q = o[s:s + C['be']]; ids, am = batch(q, toks, C['be']); z = rep(parts, ids, am); xm.mark_step(); Z[q] = z.cpu().float().numpy()[:len(q)]
    return Z
def heads(parts, Z):  # on CPU: a new row count would be one more XLA compile
    return [Z @ h.weight.detach().cpu().float().numpy().T + h.bias.detach().cpu().float().numpy() for h in parts[2:4]]
def state(parts):
    m, norms, plain, cent = parts
    return {**{'m.' + k: v.detach().cpu() for k, v in m.named_parameters() if v.requires_grad}, 'norms': {k: v.cpu() for k, v in norms.state_dict().items()},
            'plain': {k: v.cpu() for k, v in plain.state_dict().items()}, 'cent': {k: v.cpu() for k, v in cent.state_dict().items()}}
def load(parts, s):
    m, norms, plain, cent = parts; mp = dict(m.named_parameters())
    for k, v in s.items():
        if k.startswith('m.'): mp[k[2:]].data.copy_(v.to(dev))
    norms.load_state_dict(s['norms']); plain.load_state_dict(s['plain']); cent.load_state_dict(s['cent']); xm.mark_step()

parts = build(); init = state(parts); log('model on TPU')
counts = np.bincount(py, minlength=18); cw = counts.sum() / (18 * np.clip(counts, 1, None))
# ---- smoke: same shapes, a few steps, every code path once
sm = np.random.RandomState(0).choice(len(p), 400, replace=False)
fit(parts, [PT[i] for i in sm], py[sm], p.prompt_group.values[sm], 1, 1e-4, 1e-3, cw, 0, 'smoke-s1', C['b1'])
s0 = state(parts); load(parts, s0); fi = np.where(fold != 0)[0][:120]
fit(parts, [T[i] for i in fi], y[fi], t.prompt_id.values[fi], 1, 5e-5, 5e-4, None, 0, 'smoke-s2', C['b2'])
Z = feats(parts, T, list(range(130))); a, b = heads(parts, Z[:130]); assert np.isfinite(a).all() and np.isfinite(Z[:130]).all(); log('SMOKE OK', a.shape)
del s0; load(parts, init)  # base weights are frozen, so resetting adapters and heads gives a fresh model without a second copy in HBM
# ---- stage 1 on the unseen pool, then stage 2 per fold and a final fit on all host rows
fit(parts, PT, py, p.prompt_group.values, 1, 1e-4, 1e-3, cw, C['seed'], C['tag'] + '-s1', C['b1'], C['s1_budget'])
s1 = state(parts); torch.save(s1, f'{OUT}/stage1.pt'); Z = feats(parts, T, list(range(len(T)))); a, _ = heads(parts, Z); np.save(f'{OUT}/s1_plain.npy', a.astype(np.float32))
log(C['tag'], 'stage1 host acc %.4f' % (a.argmax(1) == y).mean())
oof_p, oof_c = np.zeros((len(t), 18), np.float32), np.zeros((len(t), 18), np.float32)
for f in list(range(5)) + ['final']:
    load(parts, s1); fi = np.arange(len(t)) if f == 'final' else np.where(fold != f)[0]
    fit(parts, [T[i] for i in fi], y[fi], t.prompt_id.values[fi], 2, 5e-5, 5e-4, None, C['seed'] + 1 + (f if f != 'final' else 9), f"{C['tag']}-s2-{f}", C['b2'])
    if f == 'final': torch.save(state(parts), f'{OUT}/final.pt'); log('final saved'); break
    va = np.where(fold == f)[0]; Z = feats(parts, T, list(va)); oof_p[va], oof_c[va] = heads(parts, Z[va])
    np.save(f'{OUT}/oof_plain.npy', oof_p); np.save(f'{OUT}/oof_center.npy', oof_c); log(C['tag'], 'fold', f, 'acc %.4f' % (oof_p[va].argmax(1) == y[va]).mean())
log(C['tag'], 'OOF acc %.4f' % (oof_p.argmax(1) == y).mean(), '| total %.1f h' % ((time.time() - T00) / 3600))
