import gc, glob, hashlib, json, math, os, random, re, subprocess, time
import importlib.util as _iu
from functools import lru_cache
from pathlib import Path
if not hasattr(_iu, '_ntl_fs'):  # peft rejects Kaggle's torchao; guarded because the notebook reloads this module
    _iu._ntl_fs = _iu.find_spec
    _iu.find_spec = lambda name, *a, **k: None if name.split('.')[0] == 'torchao' else _iu._ntl_fs(name, *a, **k)
import numpy as np, pandas as pd, torch
from torch import nn
from scipy.optimize import minimize
from scipy.sparse import hstack
from scipy.special import logsumexp
from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS as SW, TfidfVectorizer as V
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import balanced_accuracy_score as bas, f1_score, recall_score
from sklearn.model_selection import GroupKFold
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import LinearSVC

LABELS = sorted("""gpt-5.5 gpt-5.6-luna gpt-5.6-sol gpt-5.6-terra gpt-6-astra gemini-3.1-pro-preview gemini-3.6-flash
gemini-3.7-flash gemini-3.8-flash claude-fable-5 claude-opus-4-6 claude-opus-4-8 claude-opus-5 claude-sonnet-5
qwen3.8-max glm-5.3 glm-5.3-flash kimi-k3""".split())
L2I = {m: i for i, m in enumerate(LABELS)}
FAM = np.array([re.split(r'[-.\d]', m)[0] for m in LABELS])
SPLIT_MD5 = 'e52bf922570b1d00a0e51c510ac4f16d'
dev = torch.device('cuda:0') if torch.cuda.is_available() else torch.device('cpu')
BF = torch.cuda.is_available() and torch.cuda.get_device_capability(0)[0] >= 8  # T4 reports bf16 support but only emulates it
DT = torch.bfloat16 if BF else torch.float16

def log(*a):
    m = ' '.join([time.strftime('%H:%M:%S')] + [str(x) for x in a]); print(m, flush=True)
    if os.environ.get('NTL_LOG'):
        with open(os.environ['NTL_LOG'], 'a') as f: f.write(m + '\n')
def atomic(path, write):
    """write to a temp name first, so a disconnect never leaves a half file that looks complete."""
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True); tmp = path.with_name(path.name + '.tmp')
    with open(tmp, 'wb') as f: write(f)
    os.replace(tmp, path)
def npsave(path, a): atomic(path, lambda f: np.save(f, a))
def ptsave(path, o): atomic(path, lambda f: torch.save(o, f))
def done(path, info=None): atomic(path, lambda f: f.write(json.dumps(info or {}).encode()))

def load_train(csv):
    t = pd.read_csv(csv); t['y'] = t.model.map(L2I); return t

def make_splits(t, seed=42):
    """5 rotations of 70/15/15 by prompt: 0 train, 1 val, 2 test. Test blocks never overlap, nor do val blocks."""
    pr = pd.Series(t.prompt_id.unique()).sample(frac=1, random_state=seed).tolist(); n = len(pr); nt, nv = max(1, round(.153 * n)), max(1, round(.147 * n)); S = np.zeros((5, len(t)), np.int8)
    for f in range(5):
        a = f * n // 5; S[f, t.prompt_id.isin([pr[(a + nt + i) % n] for i in range(nv)])] = 1; S[f, t.prompt_id.isin([pr[(a + i) % n] for i in range(nt)])] = 2
    assert len(t) != 2699 or hashlib.md5(S.tobytes()).hexdigest() == SPLIT_MD5, 'splits changed, a resumed run would mix protocols'
    return S

def load_pool(pq):
    p = pd.read_parquet(pq, columns=['id', 'text', 'model', 'prompt_group', 'n_words', 'flag_gemini37_routing_risk', 'max_cos_train', 'max_sim_train_prompt'])
    p = p[~p.flag_gemini37_routing_risk & p.n_words.between(30, 300)].reset_index(drop=True); p['y'] = p.model.map(L2I)
    return p

def _norm(s): return re.sub(r'\W+', ' ', s.lower()).strip()
def leak_checks(t, S, p):
    """asserts the split contract and removes any pool row whose text equals a host row. Returns the pool and the evidence for the report."""
    for f in range(5):
        g = [set(t.prompt_id[S[f] == v]) for v in (0, 1, 2)]; assert not (g[0] & g[1] or g[0] & g[2] or g[1] & g[2]), f'prompt shared inside rotation {f}'
    for v in (1, 2):
        b = [set(t.prompt_id[S[f] == v]) for f in range(5)]; assert sum(map(len, b)) == len(set().union(*b)), 'rotations overlap'
    host = {_norm(x) for x in t.text}; dup = np.array([_norm(x) in host for x in p.text]); nt = pd.Series([_norm(x) for x in t.text])
    r = dict(prompts_train=int(t.prompt_id[S[0] == 0].nunique()), prompts_val=int(t.prompt_id[S[0] == 1].nunique()), prompts_test=int(t.prompt_id[S[0] == 2].nunique()), test_rows_covered=float((S == 2).any(0).mean()), val_or_test_rows_covered=float((S != 0).any(0).mean()),
             pool_rows=int(len(p)), pool_exact_host_removed=int(dup.sum()), host_duplicate_rows=int(nt.duplicated().sum()), host_duplicates_across_prompts=int((t.groupby(nt).prompt_id.nunique() > 1).sum()),
             pool_max_cos_train=float(p.max_cos_train.max()), pool_max_sim_train_prompt=float(p.max_sim_train_prompt.max()))
    return p[~dup].reset_index(drop=True), r

def cap_pool(p, cap, seed): return p.sample(frac=1, random_state=seed).groupby('y').head(cap).reset_index(drop=True)

# ---- LoRA classifier
TM = ['q_proj', 'k_proj', 'v_proj', 'o_proj', 'gate_proj', 'up_proj', 'down_proj']

def get_tok(d):
    from transformers import AutoTokenizer
    tok = AutoTokenizer.from_pretrained(d); tok.padding_side = 'right'
    if tok.pad_token is None: tok.pad_token = tok.eos_token
    return tok

def encode(tok, texts):
    eos = [tok.eos_token_id] if tok.eos_token_id is not None else []
    return [i + eos for i in tok(texts, add_special_tokens=False, truncation=True, max_length=447)['input_ids']]

def base_model(c, causal=False, multi=False):
    from transformers import AutoConfig, AutoModel, AutoModelForCausalLM
    mc = AutoConfig.from_pretrained(c['dir']); mc.use_cache = False
    if not causal and c.get('keep'):
        mc.num_hidden_layers = c['keep']
        if getattr(mc, 'layer_types', None) is not None: mc.layer_types = mc.layer_types[:c['keep']]
    kw = {}
    if multi and torch.cuda.device_count() > 1: kw = dict(device_map='auto', max_memory={i: '13GiB' for i in range(torch.cuda.device_count())})
    m = (AutoModelForCausalLM if causal else AutoModel).from_pretrained(c['dir'], config=mc, dtype=DT, **kw)
    return m if kw else m.to(dev), mc

def wrap(base, c, train=True):
    if train:
        base.gradient_checkpointing_enable(gradient_checkpointing_kwargs={'use_reentrant': False}); base.enable_input_require_grads()
    if not c.get('lora', True): return base.float() if train else base
    from peft import LoraConfig, get_peft_model
    m = get_peft_model(base, LoraConfig(r=16, lora_alpha=32, lora_dropout=.05, bias='none', target_modules=TM))
    for q in m.parameters():
        if q.requires_grad: q.data = q.data.float()
    return m

class Parts:
    def __init__(self, c, train=True, multi=False):
        base, mc = base_model(c, multi=multi); self.m = wrap(base, c, train); self.L = c['layers']; d = mc.hidden_size
        self.norms = nn.ModuleList([nn.LayerNorm(d) for _ in self.L]).to(dev).float()
        self.plain = nn.Linear(d * len(self.L), 18).to(dev).float(); self.cent = nn.Linear(d * len(self.L), 18).to(dev).float(); self.d = d
    def rep(self, tok, toks):
        b = tok.pad({'input_ids': toks}, return_tensors='pt').to(next(self.m.parameters()).device)
        with torch.autocast('cuda', dtype=DT): hs = self.m(**b, output_hidden_states=True, use_cache=False).hidden_states
        a = b['attention_mask'].unsqueeze(-1).float(); a[:, 0] = 0
        with torch.autocast('cuda', enabled=False):
            return torch.cat([n((hs[l].float().to(dev) * a.to(dev)).sum(1) / a.to(dev).sum(1)) for l, n in zip(self.L, self.norms)], -1)
    def state(self):
        return {'m': {k: v.detach().cpu() for k, v in self.m.named_parameters() if v.requires_grad}, 'norms': {k: v.cpu() for k, v in self.norms.state_dict().items()},
                'plain': {k: v.cpu() for k, v in self.plain.state_dict().items()}, 'cent': {k: v.cpu() for k, v in self.cent.state_dict().items()}}
    def load(self, s):
        mp = dict(self.m.named_parameters())
        for k, v in s['m'].items(): mp[k].data.copy_(v.to(mp[k].device))
        self.norms.load_state_dict(s['norms']); self.plain.load_state_dict(s['plain']); self.cent.load_state_dict(s['cent'])
    def free(self):
        del self.m, self.norms, self.plain, self.cent; gc.collect(); torch.cuda.empty_cache()

def triplet_plan(groups, epochs, seed):
    """same-prompt triplets; leftovers join other leftovers, so the centred loss degrades instead of crashing."""
    rng = np.random.RandomState(seed); plan = []
    s = pd.Series(np.arange(len(groups))).groupby(groups).apply(list)
    for _ in range(epochs):
        out, rest = [], []
        for m in s:
            m = list(rng.permutation(m))
            while len(m) >= 3: out.append([m.pop() for _ in range(3)])
            rest += m
        rest = list(rng.permutation(rest)); out += [rest[i:i + 3] for i in range(0, len(rest) - 2, 3)]
        plan += [out[i] for i in rng.permutation(len(out))]
    return plan[:len(plan) - len(plan) % 6]

def fit(P, tok, toks, ys, groups, epochs, lr_a, lr_h, seed, name, ck=None, class_w=None, soft=None, alpha=.5, temp=2., bt=6, ck_min=15):
    """6 triplets per optimizer step, split into microbatches of bt triplets; resumes from ck."""
    t0 = last = time.time(); plan = triplet_plan(groups, epochs, seed); total = len(plan) // 6; warm = max(1, total // 10); drop = nn.Dropout(.1)
    ad = [q for q in P.m.parameters() if q.requires_grad]; hd = list(P.norms.parameters()) + list(P.plain.parameters()) + list(P.cent.parameters())
    opt = torch.optim.AdamW([{'params': ad, 'lr': lr_a}, {'params': hd, 'lr': lr_h}], weight_decay=.01)
    sch = torch.optim.lr_scheduler.LambdaLR(opt, lambda s: (s + 1) / warm if s < warm else .5 * (1 + math.cos(math.pi * (s - warm) / max(1, total - warm))))
    sc = torch.amp.GradScaler(init_scale=256., enabled=not BF); w = None if class_w is None else torch.as_tensor(class_w, device=dev, dtype=torch.float32); start = 0
    if ck and os.path.exists(ck):
        s = torch.load(ck, map_location='cpu', weights_only=False); P.load(s['parts']); opt.load_state_dict(s['opt']); sch.load_state_dict(s['sch']); start = s['step']; log(name, 'resume at step', start, '/', total)
    P.m.train(); P.norms.train(); ls = []
    for step in range(start, total):
        chunk = plan[step * 6:(step + 1) * 6]
        for k in range(0, 6, bt):
            mb = chunk[k:k + bt]; M = len(mb); idx = [i for b in mb for i in b]
            z = P.rep(tok, [toks[i] for i in idx]); yy = torch.as_tensor(ys[idx], device=dev)
            zc = z - z.view(M, 3, -1).mean(1).repeat_interleave(3, 0)
            pl = P.plain(drop(z)); loss = nn.functional.cross_entropy(pl, yy, weight=w) + nn.functional.cross_entropy(P.cent(drop(zc)), yy, weight=w)
            if soft is not None:
                q = torch.as_tensor(soft[idx], device=dev, dtype=torch.float32)
                loss = (1 - alpha) * loss + alpha * temp ** 2 * nn.functional.kl_div(nn.functional.log_softmax(pl / temp, -1), q, reduction='batchmean')
            sc.scale(loss * M / 6).backward(); ls.append(float(loss.detach()))
        sc.unscale_(opt); torch.nn.utils.clip_grad_norm_(ad + hd, 1.); sc.step(opt); sc.update(); opt.zero_grad(set_to_none=True); sch.step()
        if (step + 1) % 100 == 0: log(name, 'step', step + 1, '/', total, 'loss %.3f' % np.mean(ls[-200:]), '%ds' % (time.time() - t0)); write_monitor(f'{name} step {step + 1}/{total}')
        if ck and time.time() - last > ck_min * 60:
            ptsave(ck, dict(parts=P.state(), opt=opt.state_dict(), sch=sch.state_dict(), step=step + 1)); last = time.time()
    log(name, 'fit done %ds' % (time.time() - t0))

@torch.inference_mode()
def score(P, tok, toks, bs, keep=True):
    """plain logits, centred-head logits, pooled features. Features are skipped on large pools."""
    P.m.eval(); P.norms.eval(); n = len(toks); a, b = np.zeros((n, 18), np.float32), np.zeros((n, 18), np.float32)
    Z = np.zeros((n, P.d * len(P.L)), np.float16) if keep else None; o = np.argsort([len(x) for x in toks], kind='stable')
    for s in range(0, n, bs):
        q = o[s:s + bs]; z = P.rep(tok, [toks[i] for i in q]); assert torch.isfinite(z).all()
        a[q] = P.plain(z).cpu().numpy(); b[q] = P.cent(z).cpu().numpy()
        if keep: Z[q] = z.cpu().numpy().astype(np.float16)
    P.m.train(); P.norms.train(); return a, b, Z

def kd_soft(teachers, texts, bs):
    """average teacher probabilities from stage 1 checkpoints, which never saw host rows, so folds stay clean."""
    out = 0
    for c in teachers:
        P = Parts(c, train=False); P.load(torch.load(Path(c['out']) / 'stage1.pt', map_location='cpu', weights_only=False)); tok = get_tok(c['dir'])
        a, _, _ = score(P, tok, encode(tok, texts), bs, keep=False); out = out + np.exp(a / 2 - np.logaddexp.reduce(a / 2, 1, keepdims=True)); P.free()
    return out / len(teachers)

def run_lora(name, c, t, p, S, bs):
    """stage 1 on pool only, shared across rotations; stage 2 on each rotation's train rows; then final on all host rows. Every finished unit is skipped on rerun."""
    D = Path(c['out']); D.mkdir(parents=True, exist_ok=True); tok = get_tok(c['dir'])
    random.seed(c['seed']); np.random.seed(c['seed']); torch.manual_seed(c['seed'])
    y = t.y.values; T = encode(tok, t.text.tolist()); bt = c.get('bt', 6); P = None
    if not (D / 'stage1.pt').exists():
        s = cap_pool(p, c['cap'], c['seed']); py = s.y.values; n = np.bincount(py, minlength=18); w = n.sum() / (18 * np.clip(n, 1, None))
        soft = None
        if c.get('teachers'):
            sf = D / 'teacher_soft.npy'
            if not sf.exists(): npsave(sf, kd_soft(c['teachers'], s.text.tolist(), bs))
            soft = np.load(sf)
        P = Parts(c); PT = encode(tok, s.text.tolist())
        fit(P, tok, PT, py, s.prompt_group.values, 1, c.get('lr_s1', 1e-4), 1e-3, c['seed'], name + '-s1', D / 'stage1.ck', w, soft, bt=bt)
        ptsave(D / 'stage1.pt', P.state()); (D / 'stage1.ck').unlink(missing_ok=True)
        a, _, _ = score(P, tok, T, bs, keep=False); npsave(D / 's1_plain.npy', a); log(name, 'stage1 host acc %.4f' % (a.argmax(1) == y).mean())
    s1 = torch.load(D / 'stage1.pt', map_location='cpu', weights_only=False)
    for f in list(range(5)) + ['final']:
        if unit_done(D, f): continue
        if P is None: P = Parts(c)
        P.load(s1); fi = np.arange(len(t)) if f == 'final' else np.where(S[f] == 0)[0]; ck = D / f'fold{f}.ck'
        fit(P, tok, [T[i] for i in fi], y[fi], t.prompt_id.values[fi], 2, c.get('lr_s2', 5e-5), 5e-4, c['seed'] + 1 + (9 if f == 'final' else f), f'{name}-s2-{f}', ck, bt=bt)
        if f == 'final':
            ptsave(D / 'final.pt', P.state()); ck.unlink(missing_ok=True); done(D / 'foldfinal.done'); break
        ho = np.where(S[f] != 0)[0]; a, _, Z = score(P, tok, [T[i] for i in ho], bs)
        tw = np.full((len(y), 18), np.nan, np.float32); tw[ho] = twin_logits(Z, P.cent.state_dict(), pair_groups(t.prompt_id.values[ho])); npsave(D / f'twin_f{f}.npy', tw)
        sub = fi[:500]; tr, _, _ = score(P, tok, [T[i] for i in sub], bs, keep=False); ck.unlink(missing_ok=True)
        save_unit(D, f, name, y, S[f], ho, a, float(bas(y[sub], tr.argmax(1))))
    if P is not None: P.free()
    return collect(D)

def pair_groups(prompts, k=2, seed=0):
    """random groups of k answers inside each prompt. Scoring on 2 answers per prompt tracked the board at r=0.91 in the forum, all 18 at r=0.13."""
    rng = np.random.RandomState(seed); g = np.zeros(len(prompts), int); n = 0
    for _, ix in pd.Series(np.arange(len(prompts))).groupby(np.asarray(prompts)):
        ix = rng.permutation(ix.values)
        for s in range(0, len(ix), k): g[ix[s:s + k]] = n; n += 1
    return g

def twin_logits(Z, cent, groups):
    """centred head on features centred inside each group. A row alone in its group adds no evidence."""
    W, b = cent['weight'].cpu().numpy(), cent['bias'].cpu().numpy(); out = np.zeros((len(Z), 18), np.float32)
    for g in np.unique(groups):
        i = np.where(groups == g)[0]
        if len(i) > 1: z = Z[i].astype(np.float32); out[i] = (z - z.mean(0)) @ W.T + b
    return out

def capped_agglo(A, cap=18, thr=.15):
    """average linkage that never merges past cap members, from the public recipes (Apache 2.0)."""
    n = len(A); A = A.astype(np.float32).copy(); np.fill_diagonal(A, -np.inf); size = np.ones(n, np.int32); alive = np.ones(n, bool); lab = np.arange(n)
    while True:
        M = np.where((size[:, None] + size[None, :] <= cap) & alive[:, None] & alive[None, :], A, -np.inf); i, j = divmod(int(np.argmax(M)), n)
        if not np.isfinite(M[i, j]) or M[i, j] < thr: return lab
        new = (size[i] * A[i] + size[j] * A[j]) / (size[i] + size[j]); A[i] = new; A[:, i] = new; A[i, i] = -np.inf; A[j] = -np.inf; A[:, j] = -np.inf
        size[i] += size[j]; alive[j] = False; lab[lab == j] = i

def test_groups(texts):
    """recover same-prompt passages at inference. Too few rows for the TF-IDF pruning means no groups."""
    try:
        X = V(sublinear_tf=True, stop_words='english', min_df=2, max_df=.05).fit_transform(texts); return capped_agglo((X @ X.T).toarray())
    except ValueError: return np.arange(len(texts))

def unit_done(D, f):
    """both files are checked: Drive can sync the marker before the data after a disconnect."""
    return (D / f'fold{f}.done').exists() and (D / ('final.pt' if f == 'final' else f'plain_f{f}.npy')).exists()

def softmax(x): e = np.exp(x - x.max(1, keepdims=True)); return e / e.sum(1, keepdims=True)
def metrics(y, L):
    """everything the monitor shows for one set of rows. Log loss uses row-standardised scores, so compare it between runs, not as a calibrated number."""
    pred = L.argmax(1); rec = recall_score(y, pred, labels=range(18), average=None, zero_division=0); Pr = softmax(N(L))
    return dict(bacc=float(bas(y, pred)), macro_f1=float(f1_score(y, pred, average='macro', zero_division=0)), acc=float((pred == y).mean()), family_acc=float((FAM[pred] == FAM[y]).mean()), log_loss=float(-np.log(Pr[np.arange(len(y)), y] + 1e-12).mean()), recall_min=float(rec.min()), recall_max=float(rec.max()))

def progress(H, current=None):
    """share of planned work done, from the files on disk, with the remaining time scaled by measured speed."""
    plan = json.load(open(H / 'plan.json')) if (H / 'plan.json').exists() else {}; tot = rem = 0; fin = 0
    for k, c in plan.items():
        D = H / 'members' / k; u = [(D / f'fold{f}.done', 1.) for f in range(5)] + ([(D / 'stage1.pt', 8.), (D / 'foldfinal.done', 1.3)] if c['neural'] else [])  # stage 1 is about 8 rotations of work
        fr = sum(w for p, w in u if p.exists()) / sum(w for _, w in u); tot += c['h']; rem += c['h'] * (1 - fr); fin += fr == 1
    R = [json.loads(x) for x in open(H / 'results.jsonl')] if (H / 'results.jsonl').exists() else []; R = [r for r in R if not r['resumed'] and r['name'] in plan]
    sp = sum(r['minutes'] for r in R) / 60 / max(sum(plan[r['name']]['h'] for r in R), 1e-9) if R else 1.; left = rem * sp + .4  # 0.4 h for the scenario, report and package cells
    return dict(pct=100 * (1 - rem / max(tot, 1e-9)), finished=fin, members=len(plan), left=left, speed=sp, measured=bool(R), eta=time.strftime('%Y-%m-%d %H:%M', time.localtime(time.time() + left * 3600)), current=current)

_shown = False
def write_monitor(current=None):
    """MONITOR.md in the run folder, rewritten every 100 training steps and every rotation. The table also updates in place in the notebook output."""
    global _shown
    if not os.environ.get('NTL_LOG'): return
    H = Path(os.environ['NTL_LOG']).parent; mf = H / 'metrics.jsonl'; plan = json.load(open(H / 'plan.json')) if (H / 'plan.json').exists() else {}; g_ = progress(H, current)
    M = pd.DataFrame(map(json.loads, open(mf))).drop_duplicates(['member', 'rotation'], keep='last') if mf.exists() else pd.DataFrame(columns=['member'])
    R = {r['name']: r for r in map(json.loads, open(H / 'results.jsonl'))} if (H / 'results.jsonl').exists() else {}
    head = f"**Progres {g_['pct']:.1f}%** | anggota selesai {g_['finished']}/{g_['members']} | sedang: {current or '-'} | sisa sekitar **{g_['left']:.1f} jam** ({'kecepatan terukur %.2fx rencana' % g_['speed'] if g_['measured'] else 'dari rencana, belum terukur'}) | perkiraan selesai **{g_['eta']}**"
    L = ['# Monitor', '', 'Diperbarui ' + time.strftime('%Y-%m-%d %H:%M:%S'), '', head, '', '| Anggota | Rotasi | Rencana (jam) | Terukur (jam) | Train | Val | Test | Test SD | Test macro-F1 | Test family | Test log loss | Recall terendah | Celah train-val | Celah val-test |', '|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|']
    for k in (plan or M.member.unique()):
        g = M[M.member == k]; h = plan[k]['h'] if plan else 0; ms = '%.2f' % (R[k]['minutes'] / 60) if k in R and not R[k]['resumed'] else '-'
        if g.empty: L.append(f'| {k} | 0/5 | {h:.2f} | {ms} | | | | | | | | | | |'); continue
        tr = g.train.mean() if g.train.notna().any() else None; v, te = g.val_bacc.mean(), g.test_bacc.mean()
        L.append(f"| {k} | {len(g)}/5 | {h:.2f} | {ms} | {'-' if tr is None else '%.4f' % tr} | {v:.4f} | {te:.4f} | {g.test_bacc.std(ddof=0):.4f} | {g.test_macro_f1.mean():.4f} | {g.test_family_acc.mean():.4f} | {g.test_log_loss.mean():.3f} | {g.test_recall_min.mean():.3f} | {'-' if tr is None else '%.4f' % (tr - v)} | {v - te:.4f} |")
    table = '\n'.join(L[2:]); lf = Path(os.environ['NTL_LOG']); L += ['', '## Log terakhir', '```'] + (lf.read_text().splitlines()[-15:] if lf.exists() else []) + ['```']
    atomic(H / 'MONITOR.md', lambda f: f.write('\n'.join(L).encode()))
    if current is None:
        try:
            from IPython.display import Markdown, display, update_display
            (update_display if _shown else display)(Markdown(table), display_id='ntl-monitor'); _shown = True
        except Exception: pass
        print(head.replace('**', ''), flush=True)

def save_unit(D, f, name, y, s, ho, a, train=None):
    """one rotation's held-out logits, in a full-length array with NaN on its train rows, so nothing can score them by accident."""
    full = np.full((len(y), 18), np.nan, np.float32); full[ho] = a; npsave(D / f'plain_f{f}.npy', full)
    mv, mt = metrics(y[s == 1], full[s == 1]), metrics(y[s == 2], full[s == 2]); info = dict(val=mv['bacc'], test=mt['bacc'], train=train); done(D / f'fold{f}.done', info)
    log(name, 'rotation', f, 'train', train, 'val %.4f test %.4f f1 %.4f family %.3f logloss %.3f' % (mv['bacc'], mt['bacc'], mt['macro_f1'], mt['family_acc'], mt['log_loss']))
    if os.environ.get('NTL_LOG'):
        row = dict(member=name, rotation=f, train=train, time=time.strftime('%Y-%m-%d %H:%M:%S'), **{f'val_{k}': v for k, v in mv.items()}, **{f'test_{k}': v for k, v in mt.items()})
        with open(Path(os.environ['NTL_LOG']).parent / 'metrics.jsonl', 'a') as fh: fh.write(json.dumps(row) + '\n')
        write_monitor()

def collect(D):
    Pm = np.stack([np.load(D / f'plain_f{f}.npy') for f in range(5)])
    if (D / 'twin_f0.npy').exists(): npsave(D / 'twin.npy', np.stack([np.load(D / f'twin_f{f}.npy') for f in range(5)]))
    npsave(D / 'oof.npy', Pm); return Pm

# ---- ATLAS: per-source likelihood, after Ko et al. arXiv:2610.19583
class Atlas:
    def __init__(self, c, train=True, multi=False, prefix=4):
        base, mc = base_model(c, causal=True, multi=multi); self.m = wrap(base, c, train); self.n = prefix
        self.pre = nn.Parameter(torch.randn(18, prefix, mc.hidden_size, device=dev) * .02)
    def tokp(self, ids, mask, cls):
        emb = self.m.get_input_embeddings()(ids); d = emb.device
        x = torch.cat([self.pre[cls].to(d).to(emb.dtype), emb], 1); am = torch.cat([torch.ones(len(ids), self.n, device=d, dtype=mask.dtype), mask], 1)
        with torch.autocast('cuda', dtype=DT): lg = self.m(inputs_embeds=x, attention_mask=am).logits[:, self.n - 1:-1]
        return torch.log_softmax(lg.float(), -1).gather(-1, ids.to(lg.device).unsqueeze(-1)).squeeze(-1).to(mask.device) * mask
    def state(self): return {'m': {k: v.detach().cpu() for k, v in self.m.named_parameters() if v.requires_grad}, 'pre': self.pre.detach().cpu()}
    def load(self, s):
        mp = dict(self.m.named_parameters())
        for k, v in s['m'].items(): mp[k].data.copy_(v.to(mp[k].device))
        self.pre.data.copy_(s['pre'].to(dev))
    def free(self): del self.m, self.pre; gc.collect(); torch.cuda.empty_cache()

def atlas_fit(A, tok, toks, ys, epochs, lr, seed, name, bs=8, ck=None, ck_min=15):
    t0 = last = time.time(); rng = np.random.RandomState(seed); plan = np.concatenate([rng.permutation(len(toks)) for _ in range(epochs)]); total = len(plan) // bs; warm = max(1, total // 10)
    params = [q for q in A.m.parameters() if q.requires_grad] + [A.pre]
    opt = torch.optim.AdamW(params, lr=lr, weight_decay=.01); sch = torch.optim.lr_scheduler.LambdaLR(opt, lambda s: (s + 1) / warm if s < warm else .5 * (1 + math.cos(math.pi * (s - warm) / max(1, total - warm))))
    sc = torch.amp.GradScaler(init_scale=256., enabled=not BF); start = 0
    if ck and os.path.exists(ck):
        s = torch.load(ck, map_location='cpu', weights_only=False); A.load(s['parts']); opt.load_state_dict(s['opt']); sch.load_state_dict(s['sch']); start = s['step']
    A.m.train(); ls = []
    for step in range(start, total):
        idx = plan[step * bs:(step + 1) * bs]; b = tok.pad({'input_ids': [toks[i] for i in idx]}, return_tensors='pt').to(dev)
        lp = A.tokp(b['input_ids'], b['attention_mask'], torch.as_tensor(ys[idx], device=dev)); loss = -lp.sum() / b['attention_mask'].sum()
        sc.scale(loss).backward(); sc.unscale_(opt); torch.nn.utils.clip_grad_norm_(params, 1.); sc.step(opt); sc.update(); opt.zero_grad(set_to_none=True); sch.step(); ls.append(float(loss.detach()))
        if (step + 1) % 200 == 0: log(name, 'step', step + 1, '/', total, 'nll %.3f' % np.mean(ls[-200:]), '%ds' % (time.time() - t0)); write_monitor(f'{name} step {step + 1}/{total}')
        if ck and time.time() - last > ck_min * 60:
            ptsave(ck, dict(parts=A.state(), opt=opt.state_dict(), sch=sch.state_dict(), step=step + 1)); last = time.time()

@torch.inference_mode()
def atlas_score(A, tok, toks, clip=1.5, bs=2, sc=6):
    """sum of clipped per-token evidence, so no single token decides. bs passages run under sc sources per step: full-vocab logits cost about 7 GB per 10 sequences."""
    A.m.eval(); out = np.zeros((len(toks), 18), np.float32); o = np.argsort([len(x) for x in toks], kind='stable'); cls = torch.arange(18, device=dev); t0 = time.time()
    for s in range(0, len(o), bs):
        q = o[s:s + bs]; b = tok.pad({'input_ids': [toks[i] for i in q]}, return_tensors='pt').to(dev); R = len(q)
        lp = torch.cat([A.tokp(b['input_ids'].repeat_interleave(len(k), 0), b['attention_mask'].repeat_interleave(len(k), 0), k.repeat(R)).view(R, len(k), -1) for k in cls.split(sc)], 1)
        ev = lp - lp.mean(1, keepdim=True); out[q] = ev.clamp(-clip, clip).sum(-1).float().cpu().numpy() / b['attention_mask'].sum(1, keepdim=True).sqrt().float().cpu().numpy()
    log('atlas scored', len(toks), 'passages', '%ds' % (time.time() - t0)); A.m.train(); return out

def run_atlas(name, c, t, p, S):
    D = Path(c['out']); D.mkdir(parents=True, exist_ok=True); tok = get_tok(c['dir']); y = t.y.values; T = encode(tok, t.text.tolist()); A = None
    if not (D / 'stage1.pt').exists():
        s = cap_pool(p, c['cap'], c['seed']); A = Atlas(c, multi=c.get('multi', False))
        atlas_fit(A, tok, encode(tok, s.text.tolist()), s.y.values, 1, 1e-4, c['seed'], name + '-s1', bs=c.get('bt', 8), ck=D / 'stage1.ck')
        ptsave(D / 'stage1.pt', A.state()); (D / 'stage1.ck').unlink(missing_ok=True)
    s1 = torch.load(D / 'stage1.pt', map_location='cpu', weights_only=False)
    for f in list(range(5)) + ['final']:
        if unit_done(D, f): continue
        if A is None: A = Atlas(c, multi=c.get('multi', False))
        A.load(s1); fi = np.arange(len(t)) if f == 'final' else np.where(S[f] == 0)[0]; ck = D / f'fold{f}.ck'
        atlas_fit(A, tok, [T[i] for i in fi], y[fi], 3, 5e-5, c['seed'] + 1 + (9 if f == 'final' else f), f'{name}-s2-{f}', bs=c.get('bt', 8), ck=ck)
        if f == 'final':
            ptsave(D / 'final.pt', A.state()); ck.unlink(missing_ok=True); done(D / 'foldfinal.done'); break
        ho = np.where(S[f] != 0)[0]; a = atlas_score(A, tok, [T[i] for i in ho], bs=c.get('sbs', 2)); ck.unlink(missing_ok=True); save_unit(D, f, name, y, S[f], ho, a)
    if A is not None: A.free()
    return collect(D)

# ---- sparse and stylometry
_w = re.compile(r"[A-Za-z]+|\d+|[^\sA-Za-z\d]")
def style_mask(s):
    out = []
    for m in _w.findall(s):
        l = m.lower()
        if not m[0].isalpha() or l in SW: out.append(m if not m[0].isalpha() else l)
        else: out.append(('C' if m[0].isupper() else 'w') + str(min(len(m) // 3, 4)) + '_' + l[-2:])
    return ' '.join(out)
def shape(s): return re.sub(r"[^\W\d_]+", lambda m: 'X' if m[0].isupper() else 'x', s)

def svc_fit_predict(tr_text, tr_y, w, te_text, C=.1):
    A = dict(sublinear_tf=True, min_df=3, dtype=np.float32, lowercase=False)
    vs = [(V(analyzer='char', ngram_range=(2, 5), max_features=400_000, **A), None), (V(analyzer='word', token_pattern=r'\S+', ngram_range=(1, 4), max_features=400_000, **A), style_mask),
          (V(analyzer='char', ngram_range=(2, 6), max_features=60_000, **A), shape)]
    X, Xt = [], []
    for v, fn in vs:
        g = fn or (lambda s: s); X.append(v.fit_transform([g(s) for s in tr_text])); Xt.append(v.transform([g(s) for s in te_text]))
    m = LinearSVC(C=C, class_weight='balanced', dual=True, max_iter=2000).fit(hstack(X, format='csr'), tr_y, sample_weight=w)
    o = np.full((len(te_text), 18), -5.); o[:, m.classes_] = m.decision_function(hstack(Xt, format='csr')); return o

_FW = frozenset("""a an the and or but if while although because as so than that which who whom whose this these those it its they them their theirs he him his she her hers we us our ours you your yours i me my mine
in on at to from with without for of by over under between through into about is are was were be been being have has had do does did can could will would shall should may might must not no nor all any some each
every both either neither other another such only also just very too more most less least here there when where why how what whether then now still yet even much many few little""".split())
def function_view(s): return ' '.join(x.lower() if (x.lower() in _FW or not x.isalnum()) else 'CONTENT' for x in re.findall(r'\w+|[^\w\s]', s))

def svc4_fit_predict(tr_text, tr_y, w, te_text, C=.5):
    """the public 4-view SVC: char 3-5, word 1-3, shape, function words. Its author measured 0.5008 prompt-grouped CV with the same pool and weight."""
    A = dict(sublinear_tf=True, min_df=2, dtype=np.float32, lowercase=False); W = dict(analyzer='word', token_pattern=r'(?u)\b\w+\b|[^\w\s]', ngram_range=(1, 3), **A); X, Xt = [], []
    for v, fn, wt in [(V(analyzer='char', ngram_range=(3, 5), max_features=250_000, **A), None, 1.), (V(max_features=180_000, **W), None, .7), (V(analyzer='char', ngram_range=(2, 6), max_features=60_000, **A), shape, .5), (V(max_features=50_000, **W), function_view, .5)]:
        g = fn or (lambda s: s); X.append(v.fit_transform([g(s) for s in tr_text]) * wt); Xt.append(v.transform([g(s) for s in te_text]) * wt)
    m = LinearSVC(C=C, class_weight='balanced', dual=True, max_iter=2000).fit(hstack(X, format='csr'), tr_y, sample_weight=w)
    o = np.full((len(te_text), 18), -5.); o[:, m.classes_] = m.decision_function(hstack(Xt, format='csr')); return o

def run_sparse(name, c, t, S, fit_predict):
    """fit_predict(train_mask, texts) -> logits. Vectorisers and trees only ever see the rotation's train rows and the pool."""
    D = Path(c['out']); D.mkdir(parents=True, exist_ok=True); y = t.y.values; txt = t.text.tolist()
    for f in range(5):
        if unit_done(D, f): continue
        a = S[f] == 0; ho = np.where(~a)[0]; sub = np.where(a)[0][:500]; o = fit_predict(a, [txt[i] for i in np.r_[ho, sub]])
        save_unit(D, f, name, y, S[f], ho, o[:len(ho)], float(bas(y[sub], o[len(ho):].argmax(1))))
    return collect(D)

def run_svc(name, c, t, p, S):
    s = cap_pool(p, c['cap'], 0); y = t.y.values; txt = np.array(t.text.tolist(), object)
    fp = svc4_fit_predict if c.get('v4') else svc_fit_predict
    return run_sparse(name, c, t, S, lambda a, x: fp(txt[a].tolist() + s.text.tolist(), np.r_[y[a], s.y], np.r_[np.ones(a.sum()), np.full(len(s), c['w'])], x))

MARKS = ['—', ' — ', '–', '-', ';', ':', ',', '’', '‘', '“', '”', '"', "'", '(', ')', '*', '!', '?', '…', '/', '%']
FW = "the of and to a in is that it as for with by on be this are not or from at which but its an can have more than their they we our you your i one these has was were when each while such between into because through only also however thus rather even yet both may might would could should must often still".split()
def stylo(s):
    n = max(len(s.split()), 1); ws = re.findall(r"[A-Za-z']+", s); low = [w.lower() for w in ws]; S = [x for x in re.split(r'(?<=[.!?])\s+', s) if x]; sl = [len(x.split()) for x in S] or [0]; wl = [len(w) for w in ws] or [0]
    d = {f'm{i}': s.count(m) / n for i, m in enumerate(MARKS)}; d.update({f'f{w}': low.count(w) / n for w in FW})
    d.update(n=n, sents=len(S), sl_m=np.mean(sl), sl_s=np.std(sl), sl_max=max(sl), wl_m=np.mean(wl), wl_s=np.std(wl), ttr=len(set(low)) / max(len(low), 1), cap=sum(w[0].isupper() for w in ws) / max(len(ws), 1),
             notx=len(re.findall(r"\bnot\b[^.]{0,40}\bbut\b", s.lower())) / n, emd_sp=len(re.findall(r'\s—\s', s)) / n, emd_ns=len(re.findall(r'\S—\S', s)) / n, dig=sum(ch.isdigit() for ch in s) / n, ly=sum(w.endswith('ly') for w in low) / n, ing=sum(w.endswith('ing') for w in low) / n)
    return d
def lgb_fit_predict(tr_text, tr_y, te_text):
    import lightgbm as lgb
    X = pd.DataFrame([stylo(s) for s in tr_text]); Xt = pd.DataFrame([stylo(s) for s in te_text])
    m = lgb.LGBMClassifier(n_estimators=400, learning_rate=.03, num_leaves=15, subsample=.8, subsample_freq=1, colsample_bytree=.4, min_child_samples=10, reg_lambda=2, verbose=-1).fit(X, tr_y)
    p = np.zeros((len(Xt), 18)); p[:, m.classes_] = m.predict_proba(Xt); return np.log(p + 1e-4).astype(np.float32)
def run_lgb(name, c, t, S):
    y = t.y.values; txt = np.array(t.text.tolist(), object)
    return run_sparse(name, c, t, S, lambda a, x: lgb_fit_predict(txt[a].tolist(), y[a], x))

# ---- stacking and post-processing
def N(L): return (L - L.mean(1, keepdims=True)) / (L.std(1, keepdims=True) + 1e-8)
def fit_weights(Ls, y, l2=1e-3):
    """non-negative weight per member, multinomial log loss on row-standardised scores."""
    k = len(Ls); X = np.stack([N(l) for l in Ls]); r = np.arange(len(y))
    def f(w):
        s = np.tensordot(w, X, 1); s = s - s.max(1, keepdims=True); ls = np.log(np.exp(s).sum(1)); pr = np.exp(s - ls[:, None])
        g = (X[:, r, y] - (X * pr[None]).sum(2)).mean(1); return -(s[r, y] - ls).mean() + l2 * w @ w, -g + 2 * l2 * w
    return minimize(f, np.ones(k) / k, jac=True, method='L-BFGS-B', bounds=[(0, None)] * k).x
def blend(Ls, w): return np.tensordot(w, np.stack([N(l) for l in Ls]), 1)
def select_stack(Ls, y, gain=.005):
    """forward selection then weights, on the rows given. The gain is about two rows of a 400-row validation block, so noise cannot add members."""
    sc = [bas(y, l.argmax(1)) for l in Ls]; ch = [int(np.argmax(sc))]; best = sc[ch[0]]
    while len(ch) < len(Ls):
        c = {i: bas(y, blend([Ls[j] for j in ch + [i]], fit_weights([Ls[j] for j in ch + [i]], y)).argmax(1)) for i in range(len(Ls)) if i not in ch}; i = max(c, key=c.get)
        if c[i] < best + gain: break
        ch.append(i); best = c[i]
    return ch, fit_weights([Ls[j] for j in ch], y)

def mix_bacc(Pr, y, rho, seed=0, n=20):
    """balanced accuracy under resampled class mixes, because the hidden mix is not uniform and a balanced fold flatters Sinkhorn."""
    rng = np.random.RandomState(seed); out = []
    for _ in range(n):
        pri = rng.dirichlet(np.full(18, 5.)); pick = np.concatenate([rng.choice(np.where(y == c)[0], max(1, int(pri[c] * 1800))) for c in range(18) if (y == c).any()])
        Q = Pr[pick]; Q = Q if rho is None else soft_sinkhorn(Q, rho); out.append(bas(y[pick], Q.argmax(1)))
    return float(np.mean(out))

def post_fit(Sc, Lt, Tw, y, typo, twin, sib, sink):
    """typography, twin, sibling and Sinkhorn strengths, chosen on validation rows only. Each stays off unless it clears a margin."""
    def pick(fn, grid, margin=.005):
        c = {g: bas(y, fn(g).argmax(1)) for g in grid}; b = max(c, key=c.get); return b if c[b] >= bas(y, fn(0.).argmax(1)) + margin else 0.
    lam = pick(lambda l: Sc + l * Lt, (.25, .5, 1.)) if typo else 0.; tw = pick(lambda l: Sc + lam * Lt + l * Tw, (.25, .5, 1.)) if twin else 0.; X = Sc + lam * Lt + tw * Tw
    al = pick(lambda a: sib(X, a) if a else X, (.08,), 0.) if sib else 0.; rho = None  # fixed strength: a wider grid overfit validation and lost 0.0024 on test
    if sink:
        Pr = softmax(sib(X, al) if al else X); c = {r: mix_bacc(Pr, y, r) for r in (0., .35, 1.)}; b = max(c, key=c.get)
        if c[b] > mix_bacc(Pr, y, None) + .003: rho = b
    return lam, tw, al, rho

def prompt_ci(y, pred, prompts, mask, n=500, seed=0):
    """90% interval from resampling whole prompts, since rows of one prompt are not independent."""
    idx = [g.values for _, g in pd.Series(np.where(mask)[0]).groupby(prompts[mask])]; rng = np.random.RandomState(seed); out = []
    for _ in range(n):
        r = np.concatenate([idx[i] for i in rng.randint(len(idx), size=len(idx))]); out.append(bas(y[r], pred[r]))
    return np.percentile(out, [5, 95]).tolist()

def eval_scenario(Ls, y, txt, prompts, S, typo=False, sink=False, Ts=None, sib=False):
    """each rotation chooses members, weights and post-processing from its own validation rows, then scores its test rows once.
    Ls: one (5, n, 18) array per member, Ts the same for twin evidence. The submission config comes from all validation rows together."""
    txt = np.array(txt, object); prompts = np.asarray(prompts); rots = []; pred = np.full(len(y), -1); Lv, Tw, Yv, Tv = [[] for _ in Ls], [[] for _ in Ls], [], []; Lte = np.zeros((len(y), 18)); Sb = []; Ts = Ts or [np.zeros_like(l) for l in Ls]; n0 = 0
    for f in range(5):
        v, te, tr = S[f] == 1, S[f] == 2, S[f] == 0; ch, w = select_stack([l[f][v] for l in Ls], y[v]); sub = lambda A, m: blend([A[j][f][m] for j in ch], w); fitted = sibling_fit(txt[tr], y[tr], prompts[tr]) if sib else None
        Sv, St, Twv, Twt = sub(Ls, v), sub(Ls, te), sub(Ts, v), sub(Ts, te); Ltv = typo_loglik(txt[tr], y[tr], txt[v]) if typo else np.zeros_like(Sv); Ltt = typo_loglik(txt[tr], y[tr], txt[te]) if typo else np.zeros_like(St)
        lam, tw, al, rho = post_fit(Sv, Ltv, Twv, y[v], typo, tw_on(Twv), (lambda X, a: sibling_apply(X, fitted, txt[v], a)) if sib else None, sink)
        Xv, Xt = Sv + lam * Ltv + tw * Twv, St + lam * Ltt + tw * Twt
        if al: Xv, Xt = sibling_apply(Xv, fitted, txt[v], al), sibling_apply(Xt, fitted, txt[te], al)
        Pt = softmax(Xt); pred[te] = Pt.argmax(1); Lte[te] = Xt
        rots.append(dict(val=float(bas(y[v], Xv.argmax(1))), test=float(bas(y[te], Pt.argmax(1))), test_mix=mix_bacc(Pt, y[te], rho), n_members=len(ch), lam=lam, twin=tw, sib=al, rho=rho))
        for i, l in enumerate(Ls): Lv[i].append(l[f][v]); Tw[i].append(Ts[i][f][v])
        Yv.append(y[v]); Tv.append(Ltv); Sb.append((n0, n0 + int(v.sum()), fitted, txt[v])); n0 += int(v.sum())
    Lv = [np.concatenate(x) for x in Lv]; Tw = [np.concatenate(x) for x in Tw]; Yv = np.concatenate(Yv); ch, w = select_stack(Lv, Yv); Sc = blend([Lv[j] for j in ch], w); Twc = blend([Tw[j] for j in ch], w)
    lam, tw, al, rho = post_fit(Sc, np.concatenate(Tv), Twc, Yv, typo, tw_on(Twc), (lambda X, a: np.concatenate([sibling_apply(X[a0:b0], fi, tx, a) for a0, b0, fi, tx in Sb])) if sib else None, sink)
    te = [r['test'] for r in rots]; m = pred >= 0
    return dict(val=float(np.mean([r['val'] for r in rots])), test=float(np.mean(te)), test_sd=float(np.std(te)), test_worst=float(min(te)), test_mix=float(np.mean([r['test_mix'] for r in rots])), test_pooled=float(bas(y[m], pred[m])), ci=prompt_ci(y, pred, prompts, m), rotations=rots, metrics=metrics(y[m], Lte[m]),
                recall={LABELS[c]: float((pred[m & (y == c)] == c).mean()) for c in range(18)}, confused=pd.Series([f'{LABELS[a]} -> {LABELS[b]}' for a, b in zip(y[m], pred[m]) if a != b]).value_counts().head(8).to_dict(),
                chosen=ch, weights=[float(x) for x in w], typo=lam, twin=tw, sib=al, rho=rho)

def tw_on(T): return bool(np.abs(T).max() > 0)

def typo_loglik(tr_text, tr_y, te_text, marks=MARKS):
    X = np.array([[m in s for m in marks] for s in tr_text], float); Xt = np.array([[m in s for m in marks] for s in te_text], float); tr_y = np.asarray(tr_y)
    p = np.stack([(X[tr_y == c].sum(0) + .5) / ((tr_y == c).sum() + 1) for c in range(18)])
    return Xt @ np.log(p).T + (1 - Xt) @ np.log(1 - p).T

def soft_sinkhorn(P, rho=.35, it=50):
    """pull test marginals part way to uniform; the host says the test mix is not uniform, so never force it."""
    tgt = (1 - rho) * P.mean(0) + rho / 18; P = P.copy()
    for _ in range(it): P *= tgt / P.mean(0); P /= P.sum(1, keepdims=True)
    return P

# ---- sibling residual, after Roman Tamrazov's V40A: style features rerank models inside a family; the family's total stays fixed
_MK = [',', '.', ';', ':', '!', '?', '—', '–', '-', '’', '‘', '“', '”', '"', "'", '(', ')', '[', ']', '{', '}', '*', '`', '•', '…', '/', '\\', '\n', '\n\n', '\n-', '\n1.', '\n2.', '##', '```', '**', '> ', '\t', ' = ', ' e.g.', ' i.e.', 'However,', 'Overall,', 'In conclusion', 'Therefore,', 'Moreover,', 'First,', 'Finally,', ' - ', ': ', ' ; ', '  ']
_WD = """the and but that which with into from for you your our we I it its they their there this these those however therefore moreover although because perhaps might would could should like such just very also not if or as so by of to in on at is are be was were have has had may must all any each every many some more most only even still then when where why how what who""".split()
@lru_cache(maxsize=20000)
def _sib_row(t):
    s = re.findall(r"[A-Za-z]+(?:[’'][A-Za-z]+)?", t); lo = [z.lower() for z in s]; n = max(len(s), 1); nt = max(len(t), 1); ln = np.array([len(z) for z in s] or [0]); sl = np.array([len(re.findall(r"[A-Za-z]+", z)) for z in re.split(r'(?<=[.?!])\s+', t) if z.strip()] or [0])
    b = [np.log1p(n), np.log1p(nt), nt / n, len(set(lo)) / n, ln.mean(), ln.std(), sl.mean(), sl.std(), sl.max(), (ln >= 8).mean(), sum(c.isupper() for c in t) / nt, sum(c.isdigit() for c in t) / nt, sum(ord(c) > 127 for c in t) / nt]
    return np.array(b + [min(t.count(m) / n, 3) for m in _MK] + [lo.count(w.lower()) / n for w in _WD], np.float32)
def _sib_x(texts): return np.stack([_sib_row(str(x)) for x in texts])

def sibling_fit(tr_text, tr_y, tr_groups):
    """one style model per family, with a reliability from grouped out-of-fold predictions. A family at chance gets reliability 0."""
    X = _sib_x(tr_text); tr_y = np.asarray(tr_y); tr_groups = np.asarray(tr_groups); out = []
    for fam, C in (('claude', .003), ('gemini', .003), ('gpt', .003), ('glm', .03)):
        cols = np.flatnonzero(FAM == fam); keep = np.isin(tr_y, cols)
        if len(np.unique(tr_y[keep])) < 2 or len(np.unique(tr_groups[keep])) < 5: continue
        y_ = np.searchsorted(cols, tr_y[keep]); mk = lambda: make_pipeline(StandardScaler(), LogisticRegression(C=C, max_iter=400, class_weight='balanced')); oof = np.zeros(len(y_), int)
        for a, b in GroupKFold(5).split(X[keep], y_, tr_groups[keep]): oof[b] = mk().fit(X[keep][a], y_[a]).predict(X[keep][b])
        rel = float(np.clip((bas(y_, oof) - 1 / len(cols)) / .15, 0, 1))
        if rel > 0: out.append((cols, mk().fit(X[keep], y_), rel))
    return out

def sibling_apply(L, fitted, te_text, alpha):
    """mix style probabilities into disputed rows of each family, leaving the family's total unchanged."""
    out = np.asarray(L, np.float64).copy(); Xq = _sib_x(te_text)
    for cols, m, rel in fitted:
        old = out[:, cols]; p = softmax(old); top = np.sort(p, 1); st = (alpha * rel * np.clip((.65 - (top[:, -1] - top[:, -2])) / .65, 0, 1))[:, None]
        out[:, cols] = logsumexp(old, axis=1, keepdims=True) + np.log(np.maximum((1 - st) * p + st * np.maximum(m.predict_proba(Xq), 1e-8), 1e-12))
    return out

def predict_texts(texts, cfg, exps, t, p, bs, dir_of, final_of):
    """the inference path: the check in the notebook and the Kaggle submission run this same code."""
    out, twins = [], []; G = test_groups(texts) if cfg.get('twin') else None
    for k in cfg['members']:
        c = exps[k]; tw = np.zeros((len(texts), 18), np.float32)
        if c['kind'] == 'svc':
            s = cap_pool(p, c['cap'], 0); o = (svc4_fit_predict if c.get('v4') else svc_fit_predict)(t.text.tolist() + s.text.tolist(), np.r_[t.y, s.y], np.r_[np.ones(len(t)), np.full(len(s), c['w'])], texts)
        elif c['kind'] == 'lgb': o = lgb_fit_predict(t.text.tolist(), t.y.values, texts)
        else:
            c = {**c, 'dir': dir_of(k)}; tok = get_tok(c['dir']); st = torch.load(final_of(k), map_location='cpu', weights_only=False)
            if c['kind'] == 'atlas':
                M = Atlas(c, train=False, multi=True); M.load(st); o = atlas_score(M, tok, encode(tok, texts), bs=1 if bs <= 8 else 2); M.free()
            else:
                M = Parts(c, train=False, multi=True); M.load(st); o, _, Z = score(M, tok, encode(tok, texts), bs, keep=G is not None); M.free()
                if G is not None: tw = twin_logits(Z, st['cent'], G); del Z
        out.append(o); twins.append(tw); log(k, 'scored')
    w = np.array(cfg['weights']); L = blend(out, w)
    if cfg['typo']: L = L + cfg['typo'] * typo_loglik(t.text.tolist(), t.y.values, texts)
    if cfg.get('twin'): L = L + cfg['twin'] * blend(twins, w)
    if cfg.get('sib'): L = sibling_apply(L, sibling_fit(t.text.tolist(), t.y.values, t.prompt_id.values), texts, cfg['sib'])
    Pr = softmax(L)
    if cfg['rho'] is not None and len(texts) >= 200: Pr = soft_sinkhorn(Pr, cfg['rho'])
    return Pr

# ---- 4-view SVC on full data, 70/15/15, same functions as the A100 notebook
os.environ['NTL_LOG'] = 'run.log'
t = load_train(glob.glob('/kaggle/input/**/name-that-llm/train.csv', recursive=True)[0]); p = load_pool(glob.glob('/kaggle/input/**/ntl_open_pool.parquet', recursive=True)[0]); S = make_splits(t); p, LEAK = leak_checks(t, S, p); log(LEAK)
t0 = time.time(); run_svc('svc4_p190k', dict(out='members/svc4_p190k', cap=20000, w=.35, v4=True), t, p, S); log('svc4_p190k minutes', round((time.time() - t0) / 60, 1))
