import re, numpy as np, pandas as pd
from pathlib import Path
from sklearn.model_selection import GroupKFold
from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS as SW
from sklearn.metrics import balanced_accuracy_score as bas
ROOT = Path('.'); Path('oof').mkdir(exist_ok=True)
import glob
TRAIN = glob.glob('/kaggle/input/**/name-that-llm/train.csv', recursive=True)[0]
POOL = glob.glob('/kaggle/input/**/ntl_open_pool.parquet', recursive=True)[0]
LABELS = sorted("""gpt-5.5 gpt-5.6-luna gpt-5.6-sol gpt-5.6-terra gpt-6-astra gemini-3.1-pro-preview gemini-3.6-flash
gemini-3.7-flash gemini-3.8-flash claude-fable-5 claude-opus-4-6 claude-opus-4-8 claude-opus-5 claude-sonnet-5
qwen3.8-max glm-5.3 glm-5.3-flash kimi-k3""".split())
L2I = {m: i for i, m in enumerate(LABELS)}
FAM = np.array([re.split(r'[-.\d]', m)[0] for m in LABELS])

def train():
    t = pd.read_csv(TRAIN); t['y'] = t.model.map(L2I)
    # every prompt lands in one fold; fixed so all experiments are comparable
    pr = pd.Series(t.prompt_id.unique()).sample(frac=1, random_state=42).tolist()
    t['fold'] = t.prompt_id.map({p: i % 5 for i, p in enumerate(pr)})
    return t

def pool(n=None, seed=0, drop_flags=True):
    p = pd.read_parquet(POOL, columns=['text','model','prompt_group','flag_kb_proxy','flag_gemini37_routing_risk','style_score','n_words'])
    if drop_flags: p = p[~p.flag_gemini37_routing_risk]
    p['y'] = p.model.map(L2I)
    if n:  # class-balanced subsample
        p = p.sample(frac=1, random_state=seed).groupby('y').head(n//18)
    return p.reset_index(drop=True)

def report(name, P, t, **kw):
    """P = OOF scores (N,18). Plain balanced acc, per fold spread, family acc, and per-class recall extremes."""
    pred = P.argmax(1)
    folds = [bas(t.y[t.fold==f], pred[t.fold==f]) for f in range(5)]
    famacc = (FAM[pred]==FAM[t.y]).mean()
    rec = [(pred[t.y==c]==c).mean() for c in range(18)]
    s = dict(name=name, bacc=round(bas(t.y,pred),4), fold_sd=round(np.std(folds),4), fam=round(famacc,3), rec_min=round(min(rec),2), rec_max=round(max(rec),2), **kw)
    print(s, flush=True); np.save(ROOT/f'oof/{name}.npy', P)
    with open(ROOT/'results.jsonl','a') as f: f.write(pd.Series(s).to_json()+'\n')
    return s

_w = re.compile(r"[A-Za-z]+|\d+|[^\sA-Za-z\d]")
def style_mask(s):
    """topic-blind view: keep stopwords and punctuation, reduce content words to shape + suffix."""
    out = []
    for m in _w.findall(s):
        l = m.lower()
        if not m[0].isalpha() or l in SW: out.append(m if not m[0].isalpha() else l)
        else: out.append(('C' if m[0].isupper() else 'w') + str(min(len(m)//3,4)) + '_' + l[-2:])
    return ' '.join(out)

from scipy.sparse import vstack, hstack
from sklearn.feature_extraction.text import TfidfVectorizer as V
from sklearn.svm import LinearSVC
t = train()
A = dict(sublinear_tf=True, min_df=3, max_features=400_000, dtype=np.float32, strip_accents=None, lowercase=False)
def mk(v):
    return {'word': (V(analyzer='word', token_pattern=r"\S+", ngram_range=(1,2), **A), None),
            'char': (V(analyzer='char', ngram_range=(2,5), **A), None),
            'style': (V(analyzer='word', token_pattern=r"\S+", ngram_range=(1,4), **A), style_mask),
            'shape': (V(analyzer='char', ngram_range=(2,6), **{**A, 'max_features': 60_000}), lambda s: re.sub(r"[^\W\d_]+", lambda m: 'X' if m[0].isupper() else 'x', s))}[v]
for name, views, pool_n, pool_w, C in [
    ('csh_p100k', ['char','style','shape'], 100000, .35, .1),
    ('csh_p190k', ['char','style','shape'], 190000, .35, .1),
    ('csh_p100k_w1', ['char','style','shape'], 100000, 1., .1),
]:
    p = pool(pool_n)
    P = np.zeros((len(t),18), np.float32)
    for f in range(5):
        tr = t[t.fold!=f]; va = t[t.fold==f]
        ptxt = p.text.tolist() if p is not None else []
        Xtr, Xva = [], []
        for v in views:
            vec, fn = mk(v); g = fn or (lambda s: s)
            A1 = vec.fit_transform([g(s) for s in tr.text.tolist()+ptxt]); A2 = vec.transform([g(s) for s in va.text])
            Xtr.append(A1); Xva.append(A2)
        Xtr, Xva = hstack(Xtr, format='csr'), hstack(Xva, format='csr')
        y = np.r_[tr.y, p.y] if p is not None else tr.y.values
        w = np.r_[np.ones(len(tr)), np.full(len(p), pool_w)] if p is not None else None
        m = LinearSVC(C=C, class_weight='balanced', dual=True, max_iter=2000).fit(Xtr, y, sample_weight=w)
        P[t.fold==f] = m.decision_function(Xva); print(f, bas(va.y, P[t.fold==f].argmax(1)), flush=True)
    report(name, P, t, views=','.join(views), pool_n=pool_n, pool_w=pool_w, C=C)
