"""E23: metadata, tensor-header and tiny-model CPU checks for V3 loaders.

Never loads a backbone checkpoint or uses CUDA. Run in the V3 Docker image to
check actual package compatibility. Passing this probe is NOT a real GPU dryrun.
"""
import hashlib
import importlib.metadata
import json
import os
import re
import time
from pathlib import Path

import numpy as np
import torch
from safetensors import safe_open
from transformers import AutoConfig,AutoModel

torch.set_num_threads(2)
LABELS=sorted('''gpt-5.5 gpt-5.6-luna gpt-5.6-sol gpt-5.6-terra gpt-6-astra
gemini-3.1-pro-preview gemini-3.6-flash gemini-3.7-flash gemini-3.8-flash
claude-fable-5 claude-opus-4-6 claude-opus-4-8 claude-opus-5 claude-sonnet-5
qwen3.8-max glm-5.3 glm-5.3-flash kimi-k3'''.split())
LAYERS=[2,4,6,8,12,16,20,24]
Q25_REFERENCE={'reference_url': 'https://www.kaggle.com/code/dhruvtibarewal/name-that-llm-fully-reproducible', 'reference_notebook_sha256': '2ede3d05656504d629efb4087c90a5180cf575e115868c7aec36fb86977bfa46', 'adapter_prefix': 'q25_14v5', 'model_type': 'qwen2', 'hidden_size': 5120, 'keep': 32, 'layers': [3, 5, 8, 11, 16, 21, 27, 32], 'max_len': 384, 'eos_id': None, 'no_final_norm': False, 'reference_fields': {'name': 'qwen25_14b', 'keep': 32, 'layers': [3, 5, 8, 11, 16, 21, 27, 32], 'w': 2.0, 'bs': 8, 'max_len': 384, 'twin': 0.35}, 'label_order': ['claude-fable-5', 'claude-opus-4-6', 'claude-opus-4-8', 'claude-opus-5', 'claude-sonnet-5', 'gemini-3.1-pro-preview', 'gemini-3.6-flash', 'gemini-3.7-flash', 'gemini-3.8-flash', 'glm-5.3', 'glm-5.3-flash', 'gpt-5.5', 'gpt-5.6-luna', 'gpt-5.6-sol', 'gpt-5.6-terra', 'gpt-6-astra', 'kimi-k3', 'qwen3.8-max']}
KAGGLE=bool(os.getenv('KAGGLE_KERNEL_RUN_TYPE'))
ROOT=Path(__file__).resolve().parents[2]
OUT=Path.cwd() if KAGGLE else ROOT/'research/experiments/e23_checkpoint_preflight'


def sha(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for b in iter(lambda:f.read(2**20),b''):h.update(b)
    return h.hexdigest()


def json_file(path):return json.loads(path.read_text())


def tiny_model(config,keep):
    c=AutoConfig.for_model(config['model_type'],**{k:v for k,v in config.items() if k!='model_type'})
    c.hidden_size=32;c.intermediate_size=64;c.num_hidden_layers=keep
    c.num_attention_heads=4;c.num_key_value_heads=2;c.head_dim=8
    c.vocab_size=128;c.pad_token_id=0;c.bos_token_id=1;c.eos_token_id=2
    if hasattr(c,'layer_types'):c.layer_types=c.layer_types[:keep]
    c.reference_compile=False
    return AutoModel.from_config(c,attn_implementation='sdpa',trust_remote_code=False).cpu().eval()


def head_summary(folder,hidden,layers):
    tensor_path=folder/'heads.pt'
    if tensor_path.exists():
        H=torch.load(tensor_path,map_location='cpu',weights_only=True)
        shapes={k:list(v.shape) for k,v in H.items()}
        finite=all(torch.isfinite(v).all().item() for v in H.values())
    else:
        tensor_path=folder/'heads.safetensors'
        with safe_open(str(tensor_path),framework='pt',device='cpu') as f:
            shapes={k:f.get_slice(k).get_shape() for k in f.keys()}
        finite=None  # Header audit only for this file.
    required={f'norms.{i}.{part}':[hidden] for i in range(len(layers)) for part in ['weight','bias']}
    required.update({f'{head}.{part}':([18,hidden*len(layers)] if part=='weight' else [18])
                     for head in ['plain','centered'] for part in ['weight','bias']})
    mismatches={k:dict(expected=v,actual=shapes.get(k)) for k,v in required.items() if shapes.get(k)!=v}
    return dict(file=tensor_path.name,sha256=sha(tensor_path),finite=finite,
                shapes=shapes,format_mismatches=mismatches)


def adapter_summary(folder,base,keep,layers):
    adp=folder/'adapter' if (folder/'adapter/adapter_config.json').exists() else folder
    config=json_file(adp/'adapter_config.json')
    result=dict(folder=str(folder),adapter_config=config,head=head_summary(folder,base['hidden_size'],layers))
    meta=folder/'meta.json'
    result['labels_verified']=meta.exists() and set(json_file(meta).get('labels',[]))==set(LABELS)
    weight=adp/'adapter_model.safetensors'
    if not weight.exists():
        result['state_header_audited']=False
        return result
    model=tiny_model(base,keep)
    names=set(dict(model.named_modules()))
    del model
    unresolved=[];indices=set();pairs=0;shape_mismatches=[]
    dim=base['hidden_size'];head_dim=base.get('head_dim',dim//base['num_attention_heads'])
    mapping={'q_proj':(base['num_attention_heads']*head_dim,dim),
        'k_proj':(base.get('num_key_value_heads',base['num_attention_heads'])*head_dim,dim),
        'v_proj':(base.get('num_key_value_heads',base['num_attention_heads'])*head_dim,dim),
        'o_proj':(dim,base['num_attention_heads']*head_dim),
        'gate_proj':(base['intermediate_size'],dim),'up_proj':(base['intermediate_size'],dim),
        'down_proj':(dim,base['intermediate_size'])}
    with safe_open(str(weight),framework='pt',device='cpu') as f:
        keys=set(f.keys())
        for key in sorted(keys):
            if '.lora_A.' not in key:continue
            name=key.replace('base_model.model.','',1).split('.lora_A.')[0]
            # Replicate the exact path resolution used by the submitted loader.
            if name not in names and 'model.'+name in names:name='model.'+name
            if name not in names:unresolved.append(name)
            match=re.search(r'layers\.(\d+)\.',name)
            if match:indices.add(int(match.group(1)))
            bkey=key.replace('.lora_A.','.lora_B.')
            if bkey not in keys:
                shape_mismatches.append(dict(key=key,error='missing_B'));continue
            A,B=f.get_slice(key).get_shape(),f.get_slice(bkey).get_shape()
            expected=mapping.get(name.rsplit('.',1)[-1])
            if expected and (A[1]!=expected[1] or B[0]!=expected[0] or A[0]!=B[1]):
                shape_mismatches.append(dict(key=key,A=A,B=B,expected_weight=list(expected)))
            pairs+=1
    result.update(state_header_audited=True,adapter_layer_indices=sorted(indices),
        adapter_pair_count=pairs,unresolved_loader_modules=unresolved,shape_mismatches=shape_mismatches,
        source_keep=keep,source_layers=layers)
    return result


def run():
    begin=time.perf_counter();OUT.mkdir(parents=True,exist_ok=True)
    report=dict(versions={k:importlib.metadata.version(k) for k in ['torch','transformers','safetensors','numpy']},
                cuda_available=torch.cuda.is_available(),device_used='cpu',checks={},
                source_sha256=sha(Path(__file__)),real_gpu_dryrun=False,submission_eligible=False)
    local=ROOT/'data/preflight'
    if (local/'enc_v5/meta.json').exists() and not KAGGLE:
        enc=local/'enc_v5';qfolders=[local/'q25_v5/q25_14v5'];base25=None;base14=None
    else:
        enc=next(p.parent for p in Path('/kaggle/input').rglob('meta.json')
                 if (p.parent/'encoder/config.json').exists() and json_file(p.parent/'encoder/config.json').get('model_type')=='modernbert')
        qfolders=[p.parent for p in Path('/kaggle/input').rglob('heads.pt') if p.parent.name.startswith('q25_14v5')]
        configs=[(p,json_file(p)) for p in Path('/kaggle/input').rglob('config.json')]
        base25=next(c for p,c in configs if c.get('model_type')=='qwen2' and c.get('hidden_size')==5120)
        base14=next(c for p,c in configs if c.get('model_type')=='qwen3' and c.get('hidden_size')==5120)
    meta=json_file(enc/'meta.json');ec=json_file(enc/'encoder/config.json')
    with safe_open(str(enc/'head.safetensors'),framework='pt',device='cpu') as f:
        shapes={k:f.get_slice(k).get_shape() for k in f.keys()}
    assert set(meta['labels'])==set(LABELS) and len(meta['labels'])==18
    assert shapes['weight']==[18,ec['hidden_size']] and shapes['bias']==[18]
    assert meta['pool']=='mean_last' and meta['max_len']==384
    tiny=ec.copy();tiny['num_hidden_layers']=2;tiny['layer_types']=tiny['layer_types'][:2]
    model=tiny_model(tiny,2)
    ids=torch.tensor([[1,4,5,6,7,0],[1,8,9,0,0,0]])
    mask=(ids!=0).long()
    with torch.inference_mode():
        states=model(input_ids=ids,attention_mask=mask).last_hidden_state
        pooled=(states*mask.unsqueeze(-1)).sum(1)/mask.sum(1,keepdim=True)
    assert pooled.shape==(2,32) and torch.isfinite(pooled).all()
    del model
    report['checks']['modernbert']=dict(meta=meta,config_sha256=sha(enc/'encoder/config.json'),
        head_sha256=sha(enc/'head.safetensors'),head_shapes=shapes,
        tiny_cpu_forward_explicit_sdpa_reference_compile_false=True,
        actual_backbone_loaded=False,original_gpu_backend_defaults_tested=False)
    report['checks']['q25']=[]
    for folder in qfolders:
        if base25 is None:
            r=dict(folder=str(folder),head=head_summary(folder,5120,LAYERS),
                   adapter_config=json_file(folder/'adapter_config.json'),state_header_audited=False)
        else:r=adapter_summary(folder,base25,27,LAYERS)
        report['checks']['q25'].append(r)
    if KAGGLE:
        report['checks']['q25_reference_contract']=Q25_REFERENCE
        corrected=[adapter_summary(p,base25,Q25_REFERENCE['keep'],Q25_REFERENCE['layers']) for p in qfolders]
        assert len(corrected)==6
        assert all(len(r['unresolved_loader_modules'])==35 for r in report['checks']['q25'])
        assert all(not r['unresolved_loader_modules'] and not r['shape_mismatches']
                   and not r['head']['format_mismatches'] and r['head']['finite'] for r in corrected)
        report['checks']['q25_corrected_contract']=corrected
        report['checks']['q25_corrected_contract_passed']=True
    if KAGGLE:
        baseline=[p for p in Path('/kaggle/input').rglob('meta.json') if p.parent.name=='lora_qwen3_14b']
        assert len(baseline)==1, [str(p) for p in baseline]
        c=json_file(baseline[0])['cfg']
        variants=[p.parent for p in Path('/kaggle/input').rglob('heads.safetensors')
                  if any(slug in str(p) for slug in ['ntl-q14-lora-v5d-orig','ntl-q14-lora-v5d-aug'])]
        report['checks']['n14b_source_cfg']=c
        report['checks']['v5d_in_n14b_group']=[adapter_summary(p,base14,c['keep'],c['layers']) for p in variants]
    report['elapsed_s']=time.perf_counter()-begin
    report['limitation']='Tensor-header/name/shape checks and tiny CPU API smoke only; no backbone weights, '
    report['limitation']+='real CUDA memory/dtype/attention, hidden-run exception or attribution quality verified.'
    (OUT/'preflight_report.json').write_text(json.dumps(report,indent=2))
    print(json.dumps(report,indent=2),flush=True)


if __name__=='__main__':run()
