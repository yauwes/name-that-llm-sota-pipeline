"""Convert our two-stage final.pt into the public l24 adapter layout, then build a fork that adds them as members.
usage: build_own.py convert | build_own.py nb <public-notebook-dir> <slug> [smoke]"""
import json, sys
from pathlib import Path
import numpy as np, pandas as pd, torch
from safetensors.torch import save_file

def convert():
    labels = sorted(pd.read_csv('data/train.csv').model.unique())
    for tag in ('q8', 'll8'):
        s = torch.load(f'kernels/twostage/out_full/out_{tag}/final.pt', map_location='cpu'); d = Path(f'kernels/own/ds/own_{tag}'); (d / 'adapter').mkdir(parents=True, exist_ok=True)
        save_file({k[2:]: v.float().contiguous() for k, v in s.items() if k.startswith('m.')}, d / 'adapter/adapter_model.safetensors')
        json.dump(dict(r=16, lora_alpha=32), open(d / 'adapter/adapter_config.json', 'w')); json.dump(dict(labels=labels), open(d / 'meta.json', 'w'))
        H = {f'norms.{k}': v for k, v in s['norms'].items()} | {f'plain.{k}': v for k, v in s['plain'].items()} | {f'centered.{k}': v for k, v in s['cent'].items()}
        torch.save(H, d / 'heads.pt'); assert H['plain.weight'].shape == (18, 32768) and H['norms.7.weight'].shape == (4096,); print(tag, len(s), 'ok')
    json.dump(dict(title='ntl-own-adapters', id='ajikajadeh/ntl-own-adapters', licenses=[dict(name='CC0-1.0')]), open('kernels/own/ds/dataset-metadata.json', 'w'))

SPEC = """_eos = lambda b: AutoTokenizer.from_pretrained(b).eos_token_id
OWN = [{"name": "q8own", "type": "l24", "path": B8, "adapters": [adir('own_q8')], "keep": 24, "layers": L, "w": 1.0, "bs": 12, "max_len": 448, "twin": 0.35, "dp": True, "eos_id": _eos(B8)},
       {"name": "ll8own", "type": "l24", "path": BL, "adapters": [adir('own_ll8')], "keep": 24, "layers": L, "w": 1.0, "bs": 12, "max_len": 448, "twin": 0.35, "dp": True, "eos_id": _eos(BL)}]
"""
def nb(src, slug, smoke):
    m = json.load(open(f'{src}/kernel-metadata.json')); n = json.load(open(f"{src}/{m['code_file'].split('/')[-1]}")); c = n['cells'][-1]; s = ''.join(c['source'])
    assert s.count('import pandas as pd\nATLAS_BUDGET') == 1
    s = s.replace('import pandas as pd\nATLAS_BUDGET', 'from transformers import AutoTokenizer\n' + SPEC + ('MODELS = OWN\n' if smoke else 'MODELS += OWN\n') + 'import pandas as pd\nATLAS_BUDGET')
    if smoke:  # only the l24 path on the 3 visible rows; infer.py's in-sample check then asserts each adapter reproduces its fit
        s = s.replace('if FAST_COMMIT:   # fork', 'if False:   # fork')
        for k, v in (("'--tfidf_w', '0.25'", "'--tfidf_w', '0'"), ("'--distort_w', '0.10'", "'--distort_w', '0'"), ("'--svc_w', '12'", "'--svc_w', '0'"), ("'--atlas_w', '0.20'", "'--atlas_w', '0'"), ("'--comp_w', '0.15'", "'--comp_w', '0'")):
            assert k in s, k; s = s.replace(k, v)
    c['source'] = s.splitlines(True); d = Path(f'kernels/own/{"smoke" if smoke else "ds_nb"}/{slug}'); d.mkdir(parents=True, exist_ok=True); json.dump(n, open(d / 'nb.ipynb', 'w'))
    m.pop('id_no', None); m.update(id=f'ajikajadeh/{slug}', title=slug, code_file='nb.ipynb', is_private=True); m['dataset_sources'] = m['dataset_sources'] + ['ajikajadeh/ntl-own-adapters']; json.dump(m, open(d / 'kernel-metadata.json', 'w')); print(d)

if __name__ == '__main__':
    convert() if sys.argv[1] == 'convert' else nb(sys.argv[2], sys.argv[3], len(sys.argv) > 4)
