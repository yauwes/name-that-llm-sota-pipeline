# E9: frozen reader test. Same text, same pooling as stage 1, no training. Does a larger reader carry more authorship signal than 8B?
import subprocess, sys
subprocess.run([sys.executable, '-m', 'pip', 'install', '-q', '-U', 'transformers>=5.8', 'accelerate', 'safetensors'], check=True)
import gc, glob, json, os, re, time, numpy as np, pandas as pd, torch
from accelerate import dispatch_model, init_empty_weights
from accelerate.utils import set_module_tensor_to_device
from huggingface_hub import hf_hub_download
from safetensors import safe_open
from transformers import AutoConfig, AutoModel, AutoTokenizer
print('gpus', torch.cuda.device_count(), [torch.cuda.get_device_name(i) for i in range(torch.cuda.device_count())], flush=True)
L = (16, 24, 27); os.environ['PYTORCH_CUDA_ALLOC_CONF'] = 'expandable_segments:True'
data = next(p for p in ['/kaggle/input/competitions/name-that-llm', '/kaggle/input/name-that-llm'] if os.path.exists(p + '/train.csv'))
t = pd.read_csv(data + '/train.csv'); p = pd.read_parquet(glob.glob('/kaggle/input/**/ntl_open_pool.parquet', recursive=True)[0])
p = p[~p.flag_gemini37_routing_risk & p.n_words.between(30, 300)].sample(frac=1, random_state=0).groupby('model').head(200).reset_index(drop=True)
texts = t.text.tolist() + p.text.tolist(); np.save('pool_model.npy', p.model.values.astype(str)); np.save('train_id.npy', t.id.values.astype(str)); print('rows', len(t), len(p), flush=True)

def load_q27(keep=28, repo='Qwen/Qwen3.8-27B'):
    """Only the kept text layers, one shard at a time: the full model is 55 GB, two T4 hold 30 GB."""
    c = AutoConfig.from_pretrained(repo).text_config; c.num_hidden_layers, c.layer_types, c.use_cache = keep, c.layer_types[:keep], False
    with init_empty_weights(): m = AutoModel.from_config(c)
    w = json.load(open(hf_hub_download(repo, 'model.safetensors.index.json')))['weight_map']; pre = 'model.language_model.'
    def want(k):
        if not k.startswith(pre): return False
        n = re.match(r'layers\.(\d+)\.', k[len(pre):]); return n is None or int(n[1]) < keep
    dev = lambda s: 0 if not s.startswith('layers.') or int(s.split('.')[1]) < 12 else 1
    for sh in sorted({v for k, v in w.items() if want(k)}):
        f = hf_hub_download(repo, sh)
        with safe_open(f, 'pt') as g:
            for k in g.keys():
                if want(k): set_module_tensor_to_device(m, k[len(pre):], dev(k[len(pre):]), value=g.get_tensor(k).to(torch.float16))
        os.remove(os.path.realpath(f)); print('shard', sh, flush=True)
    dm = {'embed_tokens': 0, 'rotary_emb': 0, 'norm': 0}; dm.update({f'layers.{i}': dev(f'layers.{i}.') for i in range(keep)})
    return dispatch_model(m.eval(), device_map=dm), AutoTokenizer.from_pretrained(repo)

def load_q8():
    for f in sorted(glob.glob('/kaggle/input/**/config.json', recursive=True)):
        j = json.load(open(f))
        if j.get('model_type') == 'qwen3' and j.get('hidden_size') == 4096 and j.get('num_hidden_layers') == 36: d = os.path.dirname(f); break
    c = AutoConfig.from_pretrained(d); c.num_hidden_layers, c.use_cache = 28, False
    if getattr(c, 'layer_types', None) is not None: c.layer_types = c.layer_types[:28]
    return AutoModel.from_pretrained(d, config=c, dtype=torch.float16).to('cuda:0').eval(), AutoTokenizer.from_pretrained(d)

@torch.no_grad()
def extract(name, m, tok):
    tok.padding_side = 'right'; tok.pad_token = tok.pad_token or tok.eos_token; t0 = time.time()
    ids = [i + [tok.eos_token_id] for i in tok(texts, add_special_tokens=False, truncation=True, max_length=447)['input_ids']]
    o = np.argsort([len(i) for i in ids]); out = {l: np.zeros((len(ids), m.config.hidden_size), np.float16) for l in L}
    s, k = 0, 0
    while s < len(o):
        BS = 8 if len(ids[o[min(s + 7, len(o) - 1)]]) < 250 else 4; j = o[s:s + BS]; s += BS; k += 1; b = tok.pad({'input_ids': [ids[i] for i in j]}, return_tensors='pt').to('cuda:0')
        with torch.autocast('cuda', dtype=torch.float16): hs = m(**b, output_hidden_states=True, use_cache=False).hidden_states
        for l in L:
            a = b['attention_mask'].unsqueeze(-1).float().to(hs[l].device); a[:, 0] = 0; r = ((hs[l].float() * a).sum(1) / a.sum(1)).cpu().numpy(); assert np.isfinite(r).all(), (name, l, s); out[l][j] = r
        if k % 100 == 1: print(name, s, round(time.time() - t0), 'gb', [round(torch.cuda.max_memory_allocated(i) / 2**30, 1) for i in range(torch.cuda.device_count())], flush=True)
    for l in L: np.save(f'{name}_l{l}.npy', out[l])
    print(name, 'done min', round((time.time() - t0) / 60, 1), flush=True)

for name, load in (('q8', load_q8),):  # q27 features came from version 2
    m, tok = load(); extract(name, m, tok); del m; gc.collect(); torch.cuda.empty_cache()
