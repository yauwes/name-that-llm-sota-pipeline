# E11: stage 2 of ntl-twostage-train refit with sentence crops of host passages as extra host rows (1 epoch over originals + 2 crops).
# Stage 1 is loaded from that kernel's output, so model, folds and seeds match its oof_plain.npy exactly; only stage 2 data and epochs change.
import glob, json, os, pathlib, subprocess, sys, time
import numpy as np, pandas as pd
SMOKE = False
S1_BUDGET = 6.3 * 3600  # 1.3 s/triplet on a T4: stage 1 stops here so all folds finish inside the 12 h limit
VARIANTS = {1: dict(tag='ll8', seed=12, cap=3000, hs=4096, nl=32, mt='llama', keep=24, layers=[2, 4, 6, 8, 12, 16, 20, 24])}
if not SMOKE: VARIANTS[0] = dict(tag='q8', seed=11, cap=3000, hs=4096, nl=36, mt='qwen3', keep=24, layers=[2, 4, 6, 8, 12, 16, 20, 24])
WORKER = r'''
import json, math, os, random, sys, time
import importlib.util as _iu
_fs = _iu.find_spec
_iu.find_spec = lambda name, *a, **k: None if name.split('.')[0] == 'torchao' else _fs(name, *a, **k)
import numpy as np, pandas as pd, torch
from torch import nn
from transformers import AutoConfig, AutoModel, AutoTokenizer
from peft import LoraConfig, get_peft_model
import peft.import_utils as _pi
_pi.is_torchao_available = lambda *a, **k: False
c = json.loads(sys.argv[1]); dev = torch.device('cuda:0'); L = c['layers']; OUT = f"out_{c['tag']}"; os.makedirs(OUT, exist_ok=True)
t = pd.read_csv(c['train_csv']); LABELS = sorted(t.model.unique()); y = t.model.map({l: i for i, l in enumerate(LABELS)}).values
pr = pd.Series(t.prompt_id.unique()).sample(frac=1, random_state=42).tolist()
fold = t.prompt_id.map({p: i % 5 for i, p in enumerate(pr)}).values
if c['smoke']: t = t.head(90); y = y[:90]; fold = fold[:90]
import re
def crops(s):
    ss = [x for x in re.split(r'(?<=[.!?])\s+', s) if x]
    if len(ss) < 3: return []
    k = max(2, round(.6 * len(ss))); return [' '.join(ss[:k]), ' '.join(ss[-k:])]
CR = [crops(s) for s in t.text]
tok = AutoTokenizer.from_pretrained(c['model_dir']); tok.padding_side = 'right'
if tok.pad_token is None: tok.pad_token = tok.eos_token
def enc(tx): return [i + [tok.eos_token_id] for i in tok(tx, add_special_tokens=False, truncation=True, max_length=447)['input_ids']]
T = enc(t.text.tolist()); CT = [enc(x) if x else [] for x in CR]

def triplets(groups, rng, accum):
    """same-prompt chunks of 3; leftovers join any other leftovers, so the centred loss degrades instead of crashing."""
    s = pd.Series(np.arange(len(groups))).groupby(groups).apply(list); out, rest = [], []
    for m in s:
        m = list(rng.permutation(m))
        while len(m) >= 3: out.append([m.pop() for _ in range(3)])
        rest += m
    rest = list(rng.permutation(rest)); out += [rest[i:i+3] for i in range(0, len(rest)-2, 3)]
    out = [out[i] for i in rng.permutation(len(out))]
    return out[:len(out) - len(out) % accum]

def build():
    mc = AutoConfig.from_pretrained(c['model_dir']); mc.num_hidden_layers, mc.use_cache = c['keep'], False
    if getattr(mc, 'layer_types', None) is not None: mc.layer_types = mc.layer_types[:c['keep']]
    base = AutoModel.from_pretrained(c['model_dir'], config=mc, dtype=torch.float16).to(dev)
    base.gradient_checkpointing_enable(gradient_checkpointing_kwargs={'use_reentrant': False}); base.enable_input_require_grads()
    m = get_peft_model(base, LoraConfig(r=16, lora_alpha=32, lora_dropout=.05, bias='none', target_modules=['q_proj','k_proj','v_proj','o_proj','gate_proj','up_proj','down_proj']))
    for q in m.parameters():
        if q.requires_grad: q.data = q.data.float()
    norms = nn.ModuleList([nn.LayerNorm(c['hs']) for _ in L]).to(dev).float(); plain = nn.Linear(c['hs']*len(L), 18).to(dev).float(); cent = nn.Linear(c['hs']*len(L), 18).to(dev).float()
    return m, norms, plain, cent

def rep(m, norms, toks):
    b = tok.pad({'input_ids': toks}, return_tensors='pt').to(dev)
    with torch.autocast('cuda', dtype=torch.float16): hs = m(**b, output_hidden_states=True, use_cache=False).hidden_states
    a = b['attention_mask'].unsqueeze(-1).float(); a[:, 0] = 0
    with torch.autocast('cuda', enabled=False): return torch.cat([n((hs[l].float()*a).sum(1)/a.sum(1)) for l, n in zip(L, norms)], -1)

def fit(parts, toks, ys, groups, epochs, lr_a, lr_h, weight, seed, name, budget=1e9):
    m, norms, plain, cent = parts; t0 = time.time(); rng = np.random.RandomState(seed); drop = nn.Dropout(.1); accum = 6
    ad = [q for q in m.parameters() if q.requires_grad]; hd = list(norms.parameters())+list(plain.parameters())+list(cent.parameters())
    opt = torch.optim.AdamW([{'params': ad, 'lr': lr_a}, {'params': hd, 'lr': lr_h}], weight_decay=.01)
    plan = [triplets(groups, rng, accum) for _ in range(epochs)]; total = sum(map(len, plan))//accum; warm = max(1, total//10)
    sch = torch.optim.lr_scheduler.LambdaLR(opt, lambda s: (s+1)/warm if s < warm else .5*(1+math.cos(math.pi*(s-warm)/max(1, total-warm))))
    sc = torch.amp.GradScaler(init_scale=256.); w = None if weight is None else torch.as_tensor(weight, device=dev, dtype=torch.float32)
    m.train(); norms.train(); step = 0; ls = []
    for e, B in enumerate(plan):
        for i, b in enumerate(B):
            if time.time()-t0 > budget: print(name, 'budget stop at step', step, '/', total, flush=True); break
            z = rep(m, norms, [toks[j] for j in b]); yy = torch.as_tensor(ys[b], device=dev)
            loss = nn.functional.cross_entropy(plain(drop(z)), yy, weight=w) + nn.functional.cross_entropy(cent(drop(z - z.mean(0, keepdim=True))), yy, weight=w)
            sc.scale(loss/accum).backward(); ls.append(float(loss.detach()))
            if (i+1) % accum == 0:
                sc.unscale_(opt); torch.nn.utils.clip_grad_norm_(ad+hd, 1.); sc.step(opt); sc.update(); opt.zero_grad(set_to_none=True); sch.step(); step += 1
                if step % 100 == 0: print(name, 'ep', e, 'step', step, '/', total, 'loss %.3f' % np.mean(ls[-600:]), '%ds' % (time.time()-t0), flush=True)
    print(name, 'fit done', '%ds' % (time.time()-t0), flush=True)

@torch.inference_mode()
def feats(parts, toks):
    m, norms, *_ = parts; m.eval(); norms.eval(); Z = np.zeros((len(toks), c['hs']*len(L)), np.float32); o = np.argsort([len(x) for x in toks], kind='stable')
    for s in range(0, len(o), 6): q = o[s:s+6]; Z[q] = rep(m, norms, [toks[i] for i in q]).cpu().numpy()
    assert np.isfinite(Z).all(); return Z

def state(parts):
    m, norms, plain, cent = parts
    return {**{'m.'+k: v.cpu() for k, v in m.named_parameters() if v.requires_grad}, 'norms': {k: v.cpu() for k, v in norms.state_dict().items()}, 'plain': {k: v.cpu() for k, v in plain.state_dict().items()}, 'cent': {k: v.cpu() for k, v in cent.state_dict().items()}}
def load(parts, s):
    m, norms, plain, cent = parts; mp = dict(m.named_parameters())
    for k, v in s.items():
        if k.startswith('m.'): mp[k[2:]].data.copy_(v.to(dev))
    norms.load_state_dict(s['norms']); plain.load_state_dict(s['plain']); cent.load_state_dict(s['cent'])
def head_scores(parts, Z):
    with torch.inference_mode(): return parts[2](torch.as_tensor(Z, device=dev)).cpu().numpy(), parts[3](torch.as_tensor(Z, device=dev)).cpu().numpy()

random.seed(c['seed']); np.random.seed(c['seed']); torch.manual_seed(c['seed'])
parts = build(); s1 = torch.load(c['stage1'], map_location='cpu', weights_only=False); load(parts, s1)
oof_p, oof_c = np.zeros((len(t), 18), np.float32), np.zeros((len(t), 18), np.float32); T0 = time.time()
for f in range(5):
    t0 = time.time(); load(parts, s1); fi = np.where(fold != f)[0]
    xs, ys, gs = [T[i] for i in fi], list(y[fi]), list(t.prompt_id.values[fi])
    for i in fi:
        for x in CT[i]: xs.append(x); ys.append(y[i]); gs.append(t.prompt_id.values[i])
    print(c['tag'], 'fold', f, 'stage2 rows', len(fi), '+ crops', len(xs) - len(fi), flush=True)
    fit(parts, xs, np.array(ys), np.array(gs), 1, 5e-5, 5e-4, None, c['seed'] + 1 + f, f"{c['tag']}-s2c-{f}")
    va = np.where(fold == f)[0]; Z = feats(parts, [T[i] for i in va]); oof_p[va], oof_c[va] = head_scores(parts, Z)
    np.save(f'{OUT}/oof_plain_crop.npy', oof_p); np.save(f'{OUT}/oof_center_crop.npy', oof_c)
    el = time.time() - T0; print(c['tag'], 'fold', f, 'acc %.4f' % (oof_p[va].argmax(1) == y[va]).mean(), '%ds' % (time.time() - t0), 'ETA %.0f min' % (el / (f + 1) * (4 - f) / 60), flush=True)
print(c['tag'], 'OOF acc %.4f' % (oof_p.argmax(1) == y).mean(), flush=True)
'''
open('worker.py', 'w').write(WORKER)
data = next(p for p in ['/kaggle/input/competitions/name-that-llm', '/kaggle/input/name-that-llm'] if os.path.exists(p+'/train.csv'))
def base(mt, hs, nl):
    for f in sorted(glob.glob('/kaggle/input/**/config.json', recursive=True)):
        j = json.load(open(f))
        if j.get('model_type') == mt and j.get('hidden_size') == hs and j.get('num_hidden_layers') == nl: return os.path.dirname(f)
    raise FileNotFoundError((hs, nl))
pl = None
S1 = {v['tag']: glob.glob(f"/kaggle/input/**/out_{v['tag']}/stage1.pt", recursive=True)[0] for v in VARIANTS.values()}
print(S1)
ps = []
for g, v in VARIANTS.items():
    c = dict(train_csv=data+'/train.csv', pool=pl, stage1=S1[v['tag']], model_dir=base(v['mt'], v['hs'], v['nl']), smoke=SMOKE, s1_budget=S1_BUDGET, **v)
    ps.append(subprocess.Popen([sys.executable, 'worker.py', json.dumps(c)], env=dict(os.environ, CUDA_VISIBLE_DEVICES=str(g), PYTORCH_CUDA_ALLOC_CONF='expandable_segments:True'), stdout=open(f'w{g}.log', 'w'), stderr=subprocess.STDOUT))
for g, p in zip(VARIANTS, ps):
    p.wait(); print('worker', g, 'rc', p.returncode); print(open(f'w{g}.log').read()[-3000:])
