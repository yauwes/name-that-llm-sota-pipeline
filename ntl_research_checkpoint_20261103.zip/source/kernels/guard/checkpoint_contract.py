"""Cheap LoRA layer/head ABI checks before loading a GPU backbone.

Passing these checks does not establish model quality, base-weight identity,
numerical parity, attention compatibility or full GPU runtime correctness.
"""
import json
import re
from pathlib import Path


class CheckpointContractError(ValueError):
    pass


def require(condition,message):
    if not condition:raise CheckpointContractError(message)


def validate_l24_spec(spec,labels):
    from safetensors import safe_open
    keep=int(spec['keep']);layers=list(spec['layers'])
    cfg=json.loads((Path(spec['path'])/'config.json').read_text())
    cfg=cfg.get('text_config',cfg)
    hidden=int(cfg['hidden_size'])
    require(0<keep<=int(cfg['num_hidden_layers']),'Invalid backbone depth')
    require(layers and min(layers)>=0 and max(layers)<=keep,'Readout exceeds instantiated backbone depth')
    contract=spec.get('checkpoint_contract',{})
    actual=dict(keep=keep,layers=layers,max_len=spec.get('max_len',384),
                eos_id=spec.get('eos_id'),no_final_norm=bool(spec.get('no_final_norm',False)),
                model_type=cfg['model_type'],hidden_size=hidden,label_order=list(labels))
    for key in actual:
        if key in contract:
            require(actual[key]==contract[key],f'{spec["name"]}: declared {key} contract differs: {actual[key]} != {contract[key]}')
    folders=spec.get('adapters') or [spec.get('adapter')]
    require(all(folders),'No adapter paths declared')
    result=[]
    for folder in map(Path,folders):
        adp=folder/'adapter' if (folder/'adapter/adapter_config.json').exists() else folder
        weight=adp/'adapter_model.safetensors'
        require(weight.is_file(),f'Missing adapter state: {weight}')
        with safe_open(str(weight),framework='pt',device='cpu') as f:
            keys=set(f.keys());indices=set();count=0
            for key in keys:
                if '.lora_A.' not in key:continue
                b=key.replace('.lora_A.','.lora_B.')
                require(b in keys,f'Missing LoRA B for {key}')
                A,B=f.get_slice(key).get_shape(),f.get_slice(b).get_shape()
                require(len(A)==len(B)==2 and A[0]==B[1],f'Invalid low-rank factor shapes: {key}')
                match=re.search(r'(?:^|\.)layers\.(\d+)\.',key)
                if match:indices.add(int(match.group(1)))
                count+=1
        require(count>0 and indices,'No decoder LoRA layer targets found')
        require(max(indices)<keep,f'{spec["name"]}: adapter targets layer {max(indices)} but keep={keep}; at least {max(indices)+1} layers required')
        pt=folder/'heads.pt'
        if pt.exists():
            import torch
            state=torch.load(pt,map_location='cpu',weights_only=True)
            shapes={k:list(v.shape) for k,v in state.items()}
        else:
            with safe_open(str(folder/'heads.safetensors'),framework='pt',device='cpu') as f:
                shapes={k:f.get_slice(k).get_shape() for k in f.keys()}
        required={f'norms.{i}.{part}':[hidden] for i in range(len(layers)) for part in ['weight','bias']}
        required.update({f'{head}.{part}':([len(labels),hidden*len(layers)] if part=='weight' else [len(labels)])
                         for head in ['plain','centered'] for part in ['weight','bias']})
        for key,shape in required.items():
            require(shapes.get(key)==shape,f'Head shape mismatch {folder}/{key}: {shapes.get(key)} != {shape}')
        meta=folder/'meta.json';label_metadata=False
        if meta.exists():
            m=json.loads(meta.read_text());label_metadata='labels' in m
            if label_metadata:
                require(len(m['labels'])==len(labels) and set(m['labels'])==set(labels),'Checkpoint labels do not match current task')
            training=m.get('cfg',m)
            for key in ['keep','layers','max_len','eos_id','no_final_norm']:
                if key in training:require(training[key]==actual[key],f'{folder}: training metadata differs for {key}')
        result.append(dict(folder=str(folder),layer_indices=sorted(indices),factor_pairs=count,
                           label_order_metadata_present=label_metadata,layer_and_head_contract_passed=True))
    return result


def self_check():
    import tempfile
    import torch
    from safetensors.torch import save_file
    with tempfile.TemporaryDirectory(prefix='ntl_contract_') as temp:
        root=Path(temp);base=root/'base';ad=root/'adapter';base.mkdir();ad.mkdir()
        (base/'config.json').write_text(json.dumps(dict(model_type='qwen2',hidden_size=4,num_hidden_layers=40)))
        save_file({'base_model.model.layers.31.self_attn.q_proj.lora_A.weight':torch.zeros(2,4),
                   'base_model.model.layers.31.self_attn.q_proj.lora_B.weight':torch.zeros(4,2)},str(ad/'adapter_model.safetensors'))
        readout=[3,5,8,11,16,21,27,32]
        state={f'norms.{i}.{part}':torch.zeros(4) for i in range(8) for part in ['weight','bias']}
        state.update({f'{head}.{part}':torch.zeros((18,32) if part=='weight' else (18,))
                      for head in ['plain','centered'] for part in ['weight','bias']})
        torch.save(state,ad/'heads.pt')
        spec=dict(name='fixture',path=str(base),adapters=[str(ad)],keep=27,layers=[2,4,6,8,12,16,20,24])
        try:validate_l24_spec(spec,list(range(18)))
        except CheckpointContractError as error:assert 'at least 32' in str(error)
        else:raise AssertionError('27-layer regression was not blocked')
        spec.update(keep=32,layers=readout,checkpoint_contract=dict(keep=32,layers=readout))
        assert validate_l24_spec(spec,list(range(18)))[0]['layer_and_head_contract_passed']
        spec['layers']=[2,4,6,8,12,16,20,24]
        try:validate_l24_spec(spec,list(range(18)))
        except CheckpointContractError as error:assert 'layers' in str(error)
        else:raise AssertionError('Same-sized but wrong readout layout was not blocked')
    print('27-vs32 depth and same-shape wrong readout regression: OK')


if __name__=='__main__':self_check()
