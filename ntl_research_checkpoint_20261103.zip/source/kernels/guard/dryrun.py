"""Make a dry-run copy of a submission notebook: the commit run then executes the full hidden-test path on N pool passages.
The 3-row public test lets most forks skip every model on commit, so code that only runs on the hidden rerun is first executed
at scoring time (how 57901383 died). Push the copy, wait for COMPLETE, read its DRYRUN line, and only then submit the original.

usage: python kernels/guard/dryrun.py kernels/sub/<kernel_dir> [n_rows]   -> writes kernels/sub/<kernel_dir>-dryrun
"""
import json, sys
from pathlib import Path

COMP = '/kaggle/input/competitions/name-that-llm'
FAKE = '/kaggle/working/fake_comp'
SETUP = '''# DRY RUN from kernels/guard/dryrun.py: rehearses the hidden rerun on {n} pool passages. Never submit this version.
import os, glob, shutil, time, pandas as pd, torch
assert torch.cuda.device_count() > 0, 'image has no CUDA: the rerun would fail too'
_src = next(p for p in ['{comp}', '/kaggle/input/name-that-llm'] if os.path.exists(p + '/train.csv'))
os.makedirs('{fake}', exist_ok=True); shutil.copy(_src + '/train.csv', '{fake}/train.csv')
_pool = glob.glob('/kaggle/input/**/ntl_open_pool.parquet', recursive=True)
_t = (pd.read_parquet(_pool[0], columns=['text', 'model']) if _pool else pd.read_csv(_src + '/train.csv')).sample({n}, random_state=0)
_t.insert(0, 'id', [f'dry{{i:06d}}' for i in range(len(_t))]); _t[['id', 'text']].to_csv('{fake}/test.csv', index=False); _DRY_TRUTH = _t
pd.DataFrame({{'id': _t.id, 'model': 'gpt-5.5'}}).to_parquet('{fake}/sample_submission.parquet', index=False)
_DRY_T0 = time.time(); print('DRYRUN fake test', len(_t), 'rows from', 'pool' if _pool else 'train', flush=True)
'''
CHECK = '''import pandas as pd, time
from sklearn.metrics import balanced_accuracy_score
_s = pd.read_parquet('/kaggle/working/submission.parquet'); _t = pd.read_csv('{fake}/test.csv')
assert list(_s.columns) == ['id', 'model'] and _s.id.is_unique and set(_s.id) == set(_t.id) and _s.model.notna().all()
assert _s.model.isin(sorted(pd.read_csv('{fake}/train.csv').model.unique())).all()
_m = _DRY_TRUTH.set_index('id').loc[_s.id]
print(f'DRYRUN OK rows {{len(_s)}} | {{time.time() - _DRY_T0:.0f}}s after setup | predicted labels {{_s.model.nunique()}} | '
      f'bacc on pool passages {{balanced_accuracy_score(_m.model, _s.model.values):.3f}} (pool is not host data, format and runtime check only)', flush=True)
'''

def main(src, n=400):
    src = Path(src); dst = src.with_name(src.name + '-dryrun'); dst.mkdir(exist_ok=True)
    meta = json.loads((src / 'kernel-metadata.json').read_text()); nb = json.loads((src / meta['code_file']).read_text())
    hits = 0
    for c in nb['cells']:
        if c['cell_type'] == 'code':
            s = ''.join(c['source']); hits += s.count(COMP); c['source'] = s.replace(COMP, FAKE).splitlines(True); c['outputs'] = []; c['execution_count'] = None
    assert hits, f'{COMP} not found: this notebook resolves its data another way, patch it by hand'
    cell = lambda s: dict(cell_type='code', metadata={}, execution_count=None, outputs=[], source=s.splitlines(True))
    nb['cells'] = [cell(SETUP.format(n=n, comp=COMP, fake=FAKE))] + nb['cells'] + [cell(CHECK.format(fake=FAKE))]
    meta.update(id=meta['id'] + '-dryrun', title=meta['title'] + '-dryrun', is_private=True); meta.pop('id_no', None)
    (dst / meta['code_file']).write_text(json.dumps(nb, indent=1, ensure_ascii=False)); (dst / 'kernel-metadata.json').write_text(json.dumps(meta, indent=1))
    print(dst, f'{hits} data paths redirected, {len(nb["cells"])} cells')

if __name__ == '__main__':
    main(sys.argv[1], int(sys.argv[2]) if len(sys.argv) > 2 else 400)
