"""Build an UNVALIDATED correctness repair; never execute inference or submit.

The public author's inference reference establishes layer/readout ABI, not the
quality of our multi-member ensemble. Keep all weights and other members fixed.
"""
import ast
import copy
import hashlib
import json
from pathlib import Path

import nbformat

from audit_apex_failure import DEST as GUARDED, ROOT, simulate
from checkpoint_contract import self_check

DEST=ROOT/'notebook/ntl_apex_v3_contract_fixed_UNVALIDATED.ipynb'
OUT=ROOT/'research/experiments/e23_checkpoint_preflight'


def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def run():
    self_check()
    reference=json.loads((OUT/'q25_reference_contract.json').read_text())
    nb=nbformat.read(GUARDED,as_version=4)
    infer=next(c for c in nb.cells if c.cell_type=='code' and c.source.startswith('%%writefile infer.py\n'))
    tree=ast.parse(infer.source.split('\n',1)[1])
    labels=ast.literal_eval(next(n.value for n in tree.body if isinstance(n,ast.Assign)
                               and any(isinstance(t,ast.Name) and t.id=='LABELS' for t in n.targets)))
    # Checked against the inference LABELS literal in the immutable author notebook.
    assert labels==sorted(labels) and len(labels)==18
    contract={k:reference[k] for k in ['keep','layers','max_len','eos_id','no_final_norm','model_type','hidden_size']}
    contract['label_order']=labels
    reference['label_order']=labels
    (OUT/'q25_reference_contract.json').write_text(json.dumps(reference,indent=2))
    last=nb.cells[-1]
    original=last.source
    target=next(line for line in original.splitlines() if 'MODELS.append({"name": "q25_14v5"' in line)
    fixed=target.replace('"keep": 27, "layers": L',
                         '"keep": 32, "layers": [3, 5, 8, 11, 16, 21, 27, 32]')
    assert fixed!=target
    fixed=fixed.removesuffix('})')+', "checkpoint_contract": '+repr(contract)+'})'
    last.source=original.replace(target,fixed)
    # Only this dict changes in the orchestration cell. No ensemble weight tuning.
    assert last.source.replace(fixed,target)==original
    hook="    adapters = spec.get('adapters') or [spec['adapter']]\n"
    assert infer.source.count(hook)==1
    infer.source=infer.source.replace(hook,
        "    if 'checkpoint_contract' in spec:\n"
        "        from checkpoint_contract import validate_l24_spec\n"
        "        validate_l24_spec(spec, LABELS)\n"+hook)
    module=(ROOT/'kernels/guard/checkpoint_contract.py').read_text()
    nb.cells.insert(nb.cells.index(infer),nbformat.v4.new_code_cell('%%writefile checkpoint_contract.py\n'+module))
    nb.cells[0].source='''# Apex V3 contract repair — UNVALIDATED, DO NOT SUBMIT

Historical champion V1: public balanced accuracy **0.665**. Original V3: **0.055**.
Qwen2.5-v5 now uses keep32 and readout [3,5,8,11,16,21,27,32], as declared in
the checkpoint author's inference reference. A CPU preflight rejects depth,
declared readout, head-shape and label-order incompatibilities before loading
this GPU backbone. Fatal main-inference errors propagate instead of writing a
constant fallback. Other member specs and ensemble weights are unchanged.

This is a correctness repair, not a validated accuracy improvement. No real
CUDA full-branch dryrun, 4000-row resource benchmark, or paired quality gain has
been established. Subsequent inherited historical claims are unverified for
this artifact. Do not submit until those gates pass.
'''
    nb.metadata['ntl_validation']=dict(status='UNVALIDATED',submission_eligible=False,
        requires_gpu_dryrun=True,quality_gain_measured=False,repair_scope='q25_v5 layer/readout ABI + fail-closed main inference')
    nb.metadata.setdefault('kaggle',{})['title']='Apex V3 Contract Fixed UNVALIDATED'
    generated=[]
    for cell in nb.cells:
        if cell.cell_type!='code':continue
        cell.outputs=[];cell.execution_count=None
        if cell.source.startswith('%%writefile '):
            header,body=cell.source.split('\n',1)
            compile(body,header,'exec');generated.append(header.split()[-1])
    compile(last.source,'contract_fixed_final_cell','exec')
    simulation=simulate(last.source)
    assert simulation['raises'] and not simulation['writes_submission']
    nb.nbformat_minor=5
    for index,cell in enumerate(nb.cells):
        cell['id']=hashlib.sha256(f'{index}:{cell.cell_type}:{cell.source}'.encode()).hexdigest()[:12]
    nbformat.validate(nb)
    nbformat.write(nb,DEST)
    report=dict(reference=reference,source_guarded_sha256=digest(GUARDED),
        repaired_notebook=str(DEST.relative_to(ROOT)),repaired_sha256=digest(DEST),
        original_q25_spec_line=target.strip(),fixed_q25_spec_line=fixed.strip(),
        ensemble_weight_unchanged=1.5,non_q25_model_specs_unchanged=True,
        preflight_before_backbone_load=True,generated_modules_compile=generated,
        fatal_failure_simulation=simulation,submission_eligible=False,
        limitation='Layer/readout ABI and failure-handling repair only. Hidden exception sequence, '
                   'full CUDA inference, memory/time and accuracy are not established.')
    (OUT/'repair_report.json').write_text(json.dumps(report,indent=2))
    print(json.dumps(report,indent=2))


if __name__=='__main__':run()
