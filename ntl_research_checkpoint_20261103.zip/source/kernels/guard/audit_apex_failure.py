"""Reproduce V3's constant fallback on synthetic IDs, without loading models.

Only the inspected final FAST_COMMIT branch is executed. Its working paths are
redirected into a temporary fixture and subprocess.run is replaced by a stub
that raises. No inference script, downloaded package, or network call executes.
Build a guarded notebook copy for future GPU dryrun, NOT for immediate submit.
"""
import ast
import copy
import hashlib
import json
import tempfile
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pandas as pd
from sklearn.metrics import balanced_accuracy_score

ROOT=Path(__file__).resolve().parents[2]
ARCHIVE=ROOT/'research/checkpoints/failed_apex_v3'
SOURCE=ARCHIVE/'ntl-apex-i-sota-contender.ipynb'
DEST=ROOT/'notebook/ntl_apex_v3_guarded_UNVALIDATED.ipynb'


def simulate(cell):
    tree=ast.parse(cell)
    node=next(n for n in tree.body if isinstance(n,ast.If) and isinstance(n.test,ast.Name)
              and n.test.id=='FAST_COMMIT')
    with tempfile.TemporaryDirectory(prefix='ntl_guard_') as tmp:
        base=Path(tmp);work=base/'working';work.mkdir();data=base/'data';data.mkdir()
        pd.DataFrame({'id':[f'synthetic_{i}' for i in range(400)],'text':['synthetic fixture']*400}).to_csv(data/'test.csv',index=False)
        class Paths(ast.NodeTransformer):
            def visit_Constant(self,n):
                if isinstance(n.value,str) and n.value.startswith('/kaggle/working/'):
                    return ast.copy_location(ast.Constant(str(work/n.value.removeprefix('/kaggle/working/'))),n)
                return n
        body=ast.fix_missing_locations(Paths().visit(copy.deepcopy(node)))
        def fail(*args,**kwargs):raise RuntimeError('synthetic mandatory inference failure')
        scope=dict(FAST_COMMIT=False,subprocess=SimpleNamespace(run=fail),cmd=['NOT_EXECUTED'],
                   DATA=str(data),pd=pd,os=__import__('os'))
        raised=False
        try:exec(compile(ast.Module(body=[body],type_ignores=[]),'<inspected_final_branch>','exec'),scope)
        except RuntimeError:raised=True
        path=work/'submission.parquet'
        if path.exists():
            pred=pd.read_parquet(path)
            assert len(pred)==400 and pred.model.nunique()==1
            synthetic_y=np.arange(400)%18
            return dict(raises=raised,writes_submission=True,unique_labels=1,
                        synthetic_balanced_accuracy=float(balanced_accuracy_score(synthetic_y,np.zeros(400,int))))
        return dict(raises=raised,writes_submission=False)


def run():
    nb=json.loads(SOURCE.read_text())
    last=nb['cells'][-1]
    original=''.join(last['source'])
    assert 'MAIN_INFERENCE_FALLBACK:' in original
    start=original.index('else:\n    try:\n        subprocess.run(cmd, check=True)')
    stop=original.index('submission = pd.read_parquet',start)
    repaired=original[:start]+'else:\n    subprocess.run(cmd, check=True)\n'+original[stop:]
    repaired+='''
_expected = pd.read_csv(os.path.join(DATA, 'test.csv'))['id'].astype(str)
assert submission['id'].astype(str).is_unique
assert set(submission['id'].astype(str)) == set(_expected), 'Submission IDs do not match current test'
_valid_labels = set(pd.read_csv(os.path.join(DATA, 'train.csv'))['model'].unique())
assert submission['model'].isin(_valid_labels).all(), 'Invalid source-model label'
if not FAST_COMMIT and len(submission) >= 50:
    assert submission['model'].nunique() > 1, 'Quality gate: constant prediction on full rerun'
'''
    compile(repaired,'guarded_final_cell','exec')
    old,new=simulate(original),simulate(repaired)
    assert old['writes_submission'] and not old['raises']
    assert new['raises'] and not new['writes_submission']
    last['source']=repaired.splitlines(True)
    for cell in nb['cells']:
        if cell['cell_type']=='code':cell['outputs']=[];cell['execution_count']=None
    nb['cells'].insert(0,dict(cell_type='markdown',metadata={},source=[
        '# Guarded V3 — UNVALIDATED, DO NOT SUBMIT\n',
        'Correctness repair only. Historical V3 scored0.055; champion V1 remains0.665.\n',
        'Mandatory inference exceptions now propagate; constant full-rerun predictions and ID/label mismatches are blocked.\n',
        'All generated Python files passed syntax compilation. No real CUDA400-row dryrun, resource benchmark or CV improvement has been verified.\n']))
    nb.setdefault('metadata',{}).setdefault('kaggle',{})['title']='Apex V3 Guarded UNVALIDATED'
    nb['metadata']['ntl_validation']=dict(status='UNVALIDATED',submission_eligible=False,requires_gpu_dryrun=True)
    DEST.write_text(json.dumps(nb,indent=1,ensure_ascii=False))
    result=dict(submission=57930534,official_public_score=.055,champion_public_score=.665,
        original_sha256=hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
        original_failure_simulation=old,guarded_failure_simulation=new,
        guarded_notebook=str(DEST.relative_to(ROOT)),guarded_sha256=hashlib.sha256(DEST.read_bytes()).hexdigest(),
        conclusion='A fatal exception is demonstrably swallowed into constant gpt-5.5 predictions in V3. '
                   'Near-chance LB is consistent with this path; actual hidden exception/logs are unavailable, '
                   'so its occurrence and underlying model-loading/runtime cause remain unverified.',
        submission_eligible=False,required_next='Real full-branch GPU dryrun, inspect mandatory inference logs, '
                                               'then paired quality validation. Do not submit guarded V3 merely because syntax is valid.')
    (ARCHIVE/'failure_regression.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(result,indent=2))


if __name__=='__main__':run()
