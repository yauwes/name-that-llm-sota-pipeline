# Checkpoint riset Name That LLM — 3 November 2026

Mulai dari [readme agen](source/readme.md) dan [notebook laporan ter-eksekusi](source/notebook/ntl_session_20261103.ipynb). Snapshot ini menambahkan audit dan eksperimen CPU E15–E17 tanpa menimpa pipeline utama repo.

- Skor resmi terbaik yang dikonfirmasi:0,665. Submission57930534 masih pending pada snapshot. Target0,99 belum tercapai.
- E16: cabang SVC0,5006 menjadi0,5242; E17 menunjukkan fusion tanpa projection sudah0,5223. Tambahan projection belum terkonfirmasi. Ini bukan skor ensemble champion/LB.
- Tidak ada submission baru atau runtime GPU/TPU baru dari rangkaian E15–E17. GPU akunajikajadeh habis; TPU tersedia20jam pada snapshot. E14 yang sudah berjalan tetap dibiarkan menyelesaikan batch.
- Raw competition data, OOF per-ID, feature arrays, credentials, dan full LLM weights tidak disertakan. Referensi durable training outputs/hash tersedia di source/research/checkpoints/. Notebook lama disimpan tanpa output; notebook laporan sesi ini hanya menampilkan agregat.

Untuk reproduksi lokal:masuk ke folder source, pasang competition train dan cache yang disebut manifest, gunakan environment.json, lalu jalankan script di research/experiments/. Tidak semua input cache lama bisa direkonstruksi; pembatasan provenance dijelaskan secara eksplisit di readme. Semua skor baru memakai prompt-disjoint rotations; hasil bukan evaluasi eksternal yang sepenuhnya buta.
